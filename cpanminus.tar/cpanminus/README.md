# cpanminus Cookbook
installs cpanminus client

# recipes
default - installs cpanminus client





