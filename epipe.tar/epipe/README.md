# E-pipe Chef Cookbook

This cookbook installs ePipe, a daemon process that synchronizes metadata from HopsFS to Elasticsearch.
