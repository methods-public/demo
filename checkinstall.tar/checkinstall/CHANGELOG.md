# CHANGELOG for checkinstall

This file is used to list changes made in each version of checkinstall.

1.0.2
-----
- Add make options parameter

1.0.1
-----
- Change the way directory structure is being created

1.0.0
-----
- Initial release of checkinstall cookbook
