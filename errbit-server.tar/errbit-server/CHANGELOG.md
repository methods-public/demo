errbit-server CHANGELOG
=======================

This file is used to list changes made in each version of the errbit-server cookbook.

1.2.1
-----
- [kwhrtsk] - Update contributors

1.2.0
-----
- [JustinAiken] - Allow config of monit service name.
- [kwhrtsk] - Change deploy provider to `deploy_revision` from `timestamped_deploy`

1.1.0
-----
- [kwhrtsk] - Default disable shallow clone.
- [kwhrtsk] - Use `monit_wrapper` instead of `service_factory` for unicorn service management.
- [kwhrtsk] - Change default revision to d533719 (master HEAD on Aug 23, 2015)

1.0.4
-----
- [kwhrtsk] - Add license to README.

1.0.3
-----
- [kwhrtsk] - Add sample Vagrantfile.

1.0.2
-----
- [kwhrtsk] - Fix bootstrap bug.

1.0.1
-----
- [kwhrtsk] - Remove workaround for https://github.com/fnichol/chef-rbenv

1.0.0
-----
- [kwhrtsk] - Use rbenv community cookbook instead of https://github.com/fnichol/chef-rbenv

0.1.0
-----
- [kwhrtsk] - Initial release of errbit-server

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
