# Contributing
Please reach out to us at toolbox@cloudpassage.com before making a pull request.
We will only accept PRs against the develop branch.

All changes must have ample testing and pass rubocop and foodcritic linting.
