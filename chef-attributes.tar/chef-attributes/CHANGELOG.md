# chef-attributes Cookbook CHANGELOG

## v0.1.0 (2018-03-19)

- Initial Cookbook creation
