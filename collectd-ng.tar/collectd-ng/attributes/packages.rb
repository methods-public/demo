default["collectd"]["packages"] = [ "collectd" ]
