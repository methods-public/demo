# cpanel CHANGELOG


## 0.1.5
- [Vassilis Aretakis] - Add documentation for cpanel

## 0.1.4
- [Vassilis Aretakis] - Initial release of cpanel
