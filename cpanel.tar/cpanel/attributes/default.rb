default['cpanel']['manage_features']['whmcs'] = false
default['cpanel']['manage_features']['features'] = false
default['cpanel']['manage_features']['packages'] = false
default['cpanel']['manage_features']['clamav'] = false

