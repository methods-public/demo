default[:drupal_make][:drush] = {
    :user => 'root',
    :group => 'root',
    :version => '7.x',
    :install_path => '/usr/local/bin/drush',
    :composer_command => 'composer'
}