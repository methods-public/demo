maintainer       "Eugenio Marzo"
maintainer_email "eugenio.marzo@fao.org"
license          "All rights reserved"
description      "Installs/Configures cgroups"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
