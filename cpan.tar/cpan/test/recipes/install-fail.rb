cpan_client 'Math::Currency' do
    install_type 'cpan_module'
    user 'root'
    group 'root'
    action 'install'
end

