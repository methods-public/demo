include_recipe 'test::bootstrap'
include_recipe 'test::reload-index'
#include_recipe 'test::install-fail'
