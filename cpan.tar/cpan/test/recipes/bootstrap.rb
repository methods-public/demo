package 'make'

include_recipe 'cpan::bootstrap'
