# dotnetcore-cookbook - Roadmap

This document describes the current status and the upcoming milestones of the dotnetcore-cookbook project.

#### Milestone Summary

| Status | Milestone | Goals | ETA |
| :---: | :--- | :---: | :---: |
| 🚀 | **Match support of all supported platforms for .NET Core** | n/a | Mid Nov 2016 |
| 🚀 | **Full service deployment with supervisor and nginx configuration under `dotnet` resource** | n/a | End Nov 2016 |

A more granular table of feature progress coming soon. 
