#
# Cookbook Name:: dotnetcore
# Recipe:: default
#
# Copyright (C) 2016 Andrew Cornies
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'dotnetcore::_platform'