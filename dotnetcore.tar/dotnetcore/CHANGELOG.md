# 1.1.3

Bug fix for Windows installer

# 1.1.2

Add support for Red Hat 7.1 and later

# 1.1.1

Added more platforms Ubuntu 16.04, CentOS 7.1, Oracle 7.1, Amazon

# 1.1.0

Minor update to dotnetcore package attributes, tested with ASP.NET Core RC2 (preview).

# 1.0.0

Initial release of dotnetcore-cookbook
