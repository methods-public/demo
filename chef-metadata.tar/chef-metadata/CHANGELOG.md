chef-metadata CHANGELOG
====================

0.1.0
-----
- Sander Botman - Initial release of chef-metadata cookbook

0.1.1
- Sander Botman - Minor bugfixes
