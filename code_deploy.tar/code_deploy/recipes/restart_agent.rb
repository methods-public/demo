code_deploy_agent 'codedeploy-agent' do
  action :restart
end
