# develop

# 1.0.0
  * Switch out yum dependency for more flexible and up-to-date yum-epel.

# 0.2.0
  * Default domain to the FQDN of the system. This is more consistent with other cookbooks defaults.

# 0.1.1
  * Don't do an immediate restart - other resources might need to be processed before the restart takes place

# 0.1.0
  * First release
