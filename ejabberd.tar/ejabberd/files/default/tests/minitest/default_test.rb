require File.expand_path('../support/helpers', __FILE__)

describe 'ejabberd::default' do

  include Helpers::Ejabberd_cookbook

  # Example spec tests can be found at http://git.io/Fahwsw
  it 'runs no tests by default' do
  end

end
