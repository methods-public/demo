default['ejabberd']['jabber_domain'] = node['fqdn']
