# Changelog for co-cloudmonkey

This file is used to list changes made in each version of co-cloudmonkey.

## 0.3.1
- pdion891 - update license date.
           - update for cloudmonkey 5.3.0 support.

## 0.3.0 - 2013-11-26
- pdion891 - update apache license.

## 0.2.0
- pdion891 - Add autoconfiguration of /root/.cloudmonkey/config from CHEF data in the envionment.

## 0.1.0

* Initial release of co-cloudmonkey

