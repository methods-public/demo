default['drone']['version'] = '0.8'
default['drone']['vault']['bag'] = 'vault_drone'
