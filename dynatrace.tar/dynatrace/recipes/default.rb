#
# Cookbook Name:: dynatrace
# Recipes:: default
#
# Copyright 2015, Dynatrace
#

include_recipe 'dynatrace::server'
