# 0.9.8 needs
- [ ] install mysql connector
- [ ] setup mysql database from config
- [ ] start zookeeper-server service
- [ ] start server service
- [ ] execute `load-defaults.sh`
- [ ] start provisioner service
- [ ] execute for provisioner `setup.sh`
- [ ] start ui service
