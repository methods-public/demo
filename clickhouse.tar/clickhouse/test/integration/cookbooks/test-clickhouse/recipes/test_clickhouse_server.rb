clickhouse_server_service 'clickhouse server instance' do
  service_name 'clickhouse-server-test'
end
