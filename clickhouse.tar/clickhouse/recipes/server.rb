clickhouse_server_service 'clickhouse server instance' do
end
