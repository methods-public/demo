flower CHANGELOG
================

This file is used to list changes made in each version of the flower cookbook.

1.0.4
-----
- Fixed the README so Supermarket parses it right.

1.0.3
-----
- Changed attribute keys to strings instead of symbols.

1.0.2
-----
- Downgraded stove until the [metadata nonsense](https://github.com/opscode/chef/pull/2345) is sorted out.

1.0.1
-----
- First release with stove. Tagging conventions messed things up.

1.0.0
-----
- Initial release of flower
