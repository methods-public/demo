1. Open issue.
2. Submit PR
3. Be sure to adjust dependencies, metadata and readme accordingly if required.
4. Please leave version bumps for releases and not on individual commits.