module EtcdCookbook
  module EtcdHelpers
    module Base
      require 'shellwords'
    end
  end
end
