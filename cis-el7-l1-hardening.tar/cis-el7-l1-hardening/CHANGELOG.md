# cis-el7-l1-hardening Cookbook CHANGELOG

This file is used to list changes made in each version of the cis-el7-l1-hardening cookbook.

## 0.7.1 (2017-10-29)

- Improve the quality of the cookbook score with updated metadata fields and license.
