# Changelog

## 0.1.3 2017-02-04

- Fix windows driver executable must be set

## 0.1.2 2017-02-04

- Fix macosx rootless issue

## 0.1.1 2017-02-04

- Fix macosx create directory

## 0.1.0 2017-02-04

- Initial beta release
