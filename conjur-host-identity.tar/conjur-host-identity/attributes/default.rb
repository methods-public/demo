default['conjur'] ||= {}
  
default['conjur']['configuration_file'] = '/etc/conjur.conf'
default['conjur']['configuration']['netrc_path'] = '/etc/conjur.identity'
