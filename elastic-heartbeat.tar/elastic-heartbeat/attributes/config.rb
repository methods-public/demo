
default['heartbeat']['config']['heartbeat.monitors'] = []

# Logging Output attributes
# default['heartbeat']['config']['logging.to_files'] = true
# default['heartbeat']['config']['logging.files']['rotateeverybytes'] = 10485760
# default['heartbeat']['config']['logging.level'] = 'info'
#
# default['heartbeat']['config']['output']['file']['path'] = '/tmp/heartbeat'
# default['heartbeat']['config']['output']['file']['filename'] = 'heartbeat'
# default['heartbeat']['config']['output']['file']['rotate_every_kb'] = 1_000
# default['heartbeat']['config']['output']['file']['number_of_files'] = 7
