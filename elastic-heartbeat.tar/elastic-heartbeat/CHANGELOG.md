# elastic-heartbeat CHANGELOG

This file is used to list changes made in each version of the elastic-heartbeat cookbook.

0.1.1
-----

- Virender Khatri - updated Kitchen Travis

- Virender Khatri - added yum-plugin-versionlock::default recipe deps

- Virender Khatri - added amazon platform family support

- Virender Khatri - update default heatbeat version to 6.2.3

- brianvans - remove some unused attributes and update README

- brianvans - use optional elastic_beats_repo cookbook for managing repo

- brianvans - support heartbeat 6.x 6.2.3 version change

0.1.0
-----

- Virender Khatri - Initial release of elastic-heartbeat

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
