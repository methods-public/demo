#
# Cookbook Name:: upgrade_system
# Attributes:: upgrade system
#
# Copyright 2016, dynatrace
#

# Operating system will be upgraded when installing server/collector/agent if ['upgrade']['system'] = 'yes'
default['upgrade']['system'] = 'yes'
