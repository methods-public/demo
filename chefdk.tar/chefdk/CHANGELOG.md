# Change Log

## [v1.1.0] (2017-02-04)

- Added CHANGELOG
- Resolved [1][1]
- Updated README
- Added Travis.yml
- Added Rakefile
- Added Gemfile
- Added travis badge

## [v1.0.1] (2017-02-03)

- Inital release


[1]: https://github.com/jjasghar/chefdk-cookbook/issues/1
