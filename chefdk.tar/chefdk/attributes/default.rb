# Change this to the channel you'd like to watch :stable, :current, :unstable
default['chefdk']['channel'] = :current

# Change this to version you'd like to install
default['chefdk']['version'] = :latest
