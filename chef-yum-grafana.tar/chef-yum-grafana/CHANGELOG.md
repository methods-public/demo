yum-grafana CHANGELOG
=====================

This file is used to list changes made in each version of the yum-grafana cookbook.

1.0.0
-----
- Initial public release of yum-grafana
