## Release 0.1.4 2015/5/13
* Fixed issue with log guard receiving bool instead of String
* Updated readme to show how to get around timing issues


## Release 0.1.3 2015/5/11
* Removed gem resource
* Fixed readme example
* Minor fix to log resources in artifact resource
* Fixed download\_path to display the location of the downloaded artifact

## Release 0.1.2 2016/5/10
* Version bump for more minor format changes

## Release 0.1.1 2016/5/10
* Added support information to metadata.rb
* Corrected README and changelog

## Release 0.1.0 2016/5/10
* Initial commit
