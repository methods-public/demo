Set up users and directories for testing the fileutils resource.
Use the fileutils resource.
