node['device-mapper']['packages'].each do |p|
  package p
end
