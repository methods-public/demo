## 0.1.0

* Enhancement: [#1][]: Migrate device-mapper handling from chef-docker devicemapper recipe

[#1]: https://github.com/bflad/chef-device-mapper/issues/1
