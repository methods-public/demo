default['elasticsearch']['plugins'] = {}
# default['elasticsearch']['plugins']['kopf']['install_name'] = 'lmenezes/elasticsearch-kopf'
# default['elasticsearch']['plugins']['bigdesk']['install_name'] = 'lukas-vlcek/bigdesk'
