co-cloudstack CHANGELOG
=======================

This file is used to list changes made in each version of the co-cloudstack cookbook.
2.0.3
-----
- Pierre-Luc - Add mysql-conf to configure mysql-server tunings required by CloudStack.

2.0.2
-----
- Pierre-Luc - change way of generating APIkeys by querying CloudStack API instead of enabling integration api port.

2.0.0
-----
- Pierre-Luc - add support for CS 4.3

1.0.0
-----
- Pierre-Luc - add vhd-util recipe
- Update license headers
- Update dependencies for opscode cookbooks

0.1.2
-----
- Pierre-Luc - remove use of databag and use attributes instead.

0.1.0
-----
- Pierre-Luc - Initial release of co-cloudstack

