Test the chef_ca resource.
Actually add a fake cert to the installed chef cacerts.pem file
