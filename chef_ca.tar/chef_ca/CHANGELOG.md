Change log for chef_ca

0.1.0
- Initial version
