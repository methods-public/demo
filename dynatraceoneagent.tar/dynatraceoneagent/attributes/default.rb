#
# Cookbook Name:: dynatrace
# Attributes:: default
#
# The Dynatrace download_link.
default['download_link'] = 'https://{tenant_id}.live.dynatrace.com/installer/oneagent/unix/latest/{token_id}'
