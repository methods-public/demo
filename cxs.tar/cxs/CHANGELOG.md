# cxs CHANGELOG

This file is used to list changes made in each version of the cxs cookbook.

## 0.5.0
- [Vassilis Aretakis] - Initial release of cxs support installation,removal and basic configuration

