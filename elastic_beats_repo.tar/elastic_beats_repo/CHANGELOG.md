elastic_beats_repo CHANGELOG
==================

1.2.0
-----

- Virender Khatri - corrected apt cookbook version dependency


1.1.0
-----

- Virender Khatri - added apt cookbook version dependency

- Virender Khatri - updated kitchen inspec tests


1.0.0
-----

- Virender Khatri - first commit
