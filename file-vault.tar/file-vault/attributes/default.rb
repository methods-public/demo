#
# Cookbook Name:: file-vault
# Attributes:: default
#

# Default data-bag to use for files
default['file-vault']['bag'] = 'file-vault'

# List of files to be deployed
default['file-vault']['files'] = []
