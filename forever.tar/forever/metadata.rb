name             "forever"
maintainer       "David Radcliffe"
maintainer_email "david@trabian.com"
license          "MIT"
description      "Chef cookbook for running node apps using forever."
long_description "See README.md"
version          "0.1.1"

supports "redhat"
supports "centos"

depends "npm"