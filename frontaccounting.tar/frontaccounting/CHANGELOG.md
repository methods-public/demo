# 1.0.1

Some minor bug fixes. Removed reference to a proprietary data bag; some files were created with wrong extensions.

# 1.0.0

Initial release of frontaccounting
