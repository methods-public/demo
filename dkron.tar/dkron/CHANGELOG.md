# dkron cookbook changelog

## v0.3.4 (2016-12-29)
  * bump default version to 0.9.2
  * relaxed dependency constraints to not step on any toes

## v0.3.3 (2016-09-29)
  * bump default version to 0.9.1

## v0.3.2 (2016-08-24)
  * bump default version to 0.9.0

## v0.3.1 (2016-08-01)
  * bump default version to 0.7.3
  * kitchen test on CentOS 7.2

## v0.3.0 (2016-04-11)
  * bump default version to 0.7.0
  * added issues_url to metadata.rb
  * bump ark dependency to 1.0

## v0.2.3 (2016-02-25)
  * bump default version to 0.6.4
  * improve tests

## v0.2.2 (2015-12-29)
  * bump default version to 0.6.3

## v0.2.1 (2015-12-23)
  * bump default version to 0.6.2

## v0.2.0 (2015-12-21)
  * add Berkshelf support and be more strict about dependencies
  * simplify server/agent configuration
  * bump default version to 0.6.1

## v0.1.1 (2015-12-15)
  * fix tag configuration

## v0.1.0
  * Initial release
