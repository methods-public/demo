## 2016-03-17 (v1.0.0)
### Summary
Initial release.

#### Features
- Install dependencies.
- Optionally install Postfix.
- Install Gitlab CE Omnibus edition.
- Manage main config.
