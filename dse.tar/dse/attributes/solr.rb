default['solr']['max_heap_size'] = '14G'
default['solr']['heap_newsize']	= '2400M'
