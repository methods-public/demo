# Datastax agent config options
default['datastax-agent']['enabled'] = false
default['datastax-agent']['version'] = '4.1.1-1'
default['datastax-agent']['conf_dir'] = '/var/lib/datastax-agent/conf'
default['datastax-agent']['opscenter-ip'] = nil
default['datastax-agent']['use_ssl'] = nil
