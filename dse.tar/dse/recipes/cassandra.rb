# this recipe exists in case we need to call from a wrapper cookbook
include_recipe 'dse::default'
