# by default install, configure and run dse cassandra
include_recipe 'dse::service'
