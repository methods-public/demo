# chocolatey_config Cookbook CHANGELOG

This file is used to list changes made in each version of the chocolatey_config cookbook.

1.0.0 (2018-05-01)

- Initial release
