# `git_better` CHANGELOG

This file is used to list changes made in each version of the `git_better` cookbook.


## `1.0.4`
- Added the missing `git_minor_version` method from `chef-client@12.0.0`.

## `1.0.3`
- Removed faulty use of `use_inline_resources` method, which is only available if inherting from the `Chef::Provider::LWRPBase` core class.

## `1.0.2`
- Refactored to LWRP within `libraries` sub-directory.

## `1.0.1`
- Copy-and-paste for glory!

## `1.0.0`
- Initial release of the `git_better` cookbook!

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
