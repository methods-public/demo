default['github-users']['dotfiles_repository'] = 'dotfiles'
default['github-users']['dotfiles_branch'] = 'master'
default['github-users']['dotfiles_temporary_dir'] = 'temp_dotfiles'
