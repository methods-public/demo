github-users CHANGELOG
======================

This file is used to list changes made in each version of the github-users cookbook.

0.1.0
-----
- satetsu888 - Initial release of github-users

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
