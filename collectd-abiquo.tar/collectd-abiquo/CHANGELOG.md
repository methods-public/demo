CHANGELOG
=========

## 0.2.0

* Fix cookbook metadata to include the recipes.
* Credentials are stored in a data bag.

## 0.1.0

* Use OAuth to authenticate to the Abiquo API.
* Enable cpu, memory, disk and interface plugins by default.
* Initial release.
