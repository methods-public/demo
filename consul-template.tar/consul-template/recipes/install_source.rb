#
# Cookbook Name:: consul-template
# Recipe:: install_source
#
# Copyright (C) 2014
#
#
#

raise 'Installation from source code has been removed for the time being.'
