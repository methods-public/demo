#
# Cookbook Name:: consul-template
# Recipe:: install_windows_source
#
# Copyright (C) 2016
#
#
#

raise 'Installation from source code is not yet supported for Windows operating system. Use binary instead.'
