# 0.2

Init systems choosing behavior changed, now better catches different platforms and init systems
Fixes in tests. Suse-Leap, Debian 8 and Ubuntu 16 added to kitchen tests, Fedora support temporary removed due to lack of time.

# 0.1.5

Readme changes.


# 0.1.4

Added more init scripts. 
The cookbook now officially supports the latest versions of debian, ubuntu, and centos.
Support for suse has been added, but is untested, so use with caution.
Support for fedora and other systemd platforms is existent, but incomplete.

The current systemd script doesn't work yet. 
If someone knows what I'm doing wrong, please contribute! :)


# 0.1.1

Added support for redhat based distros
Cleaned up some of the legalese


# 0.1.0

Initial release of mailcatcher
