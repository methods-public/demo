# v1.3.0 (2018-04-10)

* `git` cookbook dependency removed
* `source_url` and `issues_url` corrected
* Chef client 13.x and 14.x are the only supported versions at the moment

# v1.2.2 (2018-04-10)

* Rakefile added to simplify releases
* Documentation clean up
* Redundant files removed

# v1.2.1 (2016-05-10)

* Version constraint removed from `git` cookbook

# v1.2.0 (2015-05-04)

* Underscores replaced with dashes in all attributes
* Default revision set to `1.2-dev`
* Berkshelf API endpoint is deprecated, hence it was replaced with Chef
  Supermarket

# v1.1.1 (2014-06-18)

* CQ UNIX Toolkit version bumped to 1.1.1

# v1.1.0 (2014-06-17)

* CQ UNIX Toolkit version bumped to 1.1.0
* Berkshelf 3 compatibility
* Foodcritic fixes

# v1.0.0 (2014-06-06)

* First public release of the cookbook
* Supports installation of the latest stable version of CQ Unix Toolkit (1.0.0)
