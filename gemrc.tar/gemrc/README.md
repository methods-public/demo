chef-gemrc
==========

Configures rubygems to skip RI and RDoc installation.