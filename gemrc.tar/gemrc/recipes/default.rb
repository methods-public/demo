template "/root/.gemrc" do
  source 'gemrc.erb'
end
