# dbfoxbix CHANGELOG

This file is used to list changes made in each version of the dbforbix cookbook.

## 0.5.0 (2018-03-14)
- Update for public release and newer dbforbix source

## 0.1.0 (2017-03-06)
- Initial release of dbforbix
