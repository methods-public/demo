# moombot CHANGELOG

This file is used to list changes made in each version of the moombot cookbook.

## 1.0.0
- Initial public release of moombot

## 0.1.0
- PoC / Development of moombot
