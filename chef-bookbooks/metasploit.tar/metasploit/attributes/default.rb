default['metasploit']['url'] = "https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb"

#For testing
default['metasploit']['msfconsole'] = '/usr/bin/msfconsole'
