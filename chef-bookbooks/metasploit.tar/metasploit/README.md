# metasploit

This cookbook installs Metasploit on Unix/Linux systems.

