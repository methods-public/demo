openssh-lpk-cookbook
====================
![Release](http://img.shields.io/github/release/johnbellone/openssh-lpk-cookbook.svg)
[![Build Status](http://img.shields.io/travis/johnbellone/openssh-lpk-cookbook.svg)][4]
[![Code Coverage](http://img.shields.io/coveralls/johnbellone/openssh-lpk-cookbook.svg)][5]

## Supported Platforms
- CentOS 6.4, 7.0
- RHEL 6.4, 7.0
- Amazon Linux
- Ubuntu 14.04

## Authors
Created and maintained by [John Bellone][1] [@johnbellone][2]
(<jbellone@bloomberg.net>) and a growing community of
[contributors][3].

[1]: https://github.com/johnbellone
[2]: https://twitter.com/johnbellone
[3]: https://github.com/johnbellone/jumper-cookbook/graphs/contributors
[4]: http://travis-ci.org/johnbellone/consul-cookbook
[5]: https://coveralls.io/r/johnbellone/consul-cookbook
