# 0.1.2

- add floating IP address to loopback interface at compile time
- reload Ohai hints to make attributes available to later run_list items
- add attribute metadata

# 0.1.1

- metadata fixup

# 0.1.0

Initial release of os_floating_lo

- initial support for floating IPv4 addresses
- initial serverspec tests
