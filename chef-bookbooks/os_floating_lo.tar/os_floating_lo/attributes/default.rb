default['os_floating_lo']['device'] = 'lo:0'
default['os_floating_lo']['mask'] = '255.255.255.255'
