default['traefik']['config'] = { entryPoints: { http: { address: ':80' } } }
default['traefik']['config_file'] = '/etc/traefik/traefik.toml'
