
include_recipe "traefik::install_#{node['traefik']['install']['install_method']}"
