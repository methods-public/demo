# traefik
[![Build Status](https://travis-ci.org/redguide/traefik.svg?branch=master)](https://travis-ci.org/redguide/traefik)

TODO: Enter the cookbook description here.
