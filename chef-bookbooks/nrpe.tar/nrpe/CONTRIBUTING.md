If you would like to contribute, please open a pull request here on
Github.

Please do not modify the version number in the metadata.rb. Also please
do not update the CHANGELOG.md. Not all changes to the cookbook may 
be merged and released in the same versions. I will handle the version 
updates during the release process.

If your change adds new attributes, data bags, or other features
please document how to use the change in the cookbook's README.md file.
Otherwise no one will know how to use your work.
