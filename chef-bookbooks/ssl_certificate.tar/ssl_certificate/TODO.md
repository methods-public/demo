TODO
====

* [ ] Add `key_passphrase` parameter.
* [ ] Fix CentOS `7` support.
* [ ] Generate a CSR.
* [ ] Manage certificate expiration.
* [ ] Add `:delete` action.
* [ ] why-run support.
* [ ] Check generated certificate data in ChefSpec unit tests.
* [ ] Add RSpec library unit tests.
* [ ] Integrate with test coverage.
