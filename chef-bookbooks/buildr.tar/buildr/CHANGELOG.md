# CHANGELOG for buildr

This file is used to list changes made in each version of buildr.

## 1.0.0:

* Initial release of buildr

