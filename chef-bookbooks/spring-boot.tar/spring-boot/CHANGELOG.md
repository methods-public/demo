spring-boot CHANGELOG
====

## 1.0.0
- [JonsJava](https://github.com/jonsjava)
- Cleaned up recipes, added new features that Chef now expects, broke example recipes into fake cookbook.
- [goblin23](https://github.com/goblin23)
- Converted LWRP into a custom ressource
- Removed dependency to the java cookbook
## 1.1.0
- [Khorchammar](https://github.com/Khorchammar)
- Added jmx configuration

## 1.1.1
- [JonsJava](https://github.com/jonsjava)
- Very minor tweak to the README.md to ensure that the Multi-Dimensional array is Cookstyle-compliant. (spaces before closing `}`)
## 1.1.2
- [frank-carnovale] Set current working directory in service definition template
