# redhat-cookbook

Wrapper cookbook which configures RHEL systems.
