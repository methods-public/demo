#
# Cookbook: redhat
# License: Apache 2.0
#
# Copyright 2014-2016, Bloomberg Finance L.P.
#

default['redhat']['enable_epel'] = false
