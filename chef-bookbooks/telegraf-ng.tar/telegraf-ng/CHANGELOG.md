# telegraf-ng CHANGELOG

This file is used to list changes made in each version of the telegraf cookbook.

0.0.2
-----

- Virender Khatri - fix toml require at compile time

- Virender Khatri - added yum version pinning

- Virender Khatri - added apt package options

- Virender Khatri - set default version to 1.0.0

0.0.1
-----

- Virender Khatri - Initial release of telegraf-ng

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
