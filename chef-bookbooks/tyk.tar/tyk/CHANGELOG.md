tyk CHANGELOG
=============

This file is used to list changes made in each version of the tyk cookbook.

0.2.1 (2016-05-19)
------------------
- Tyk 2 config enhacements (Thanks to Gaelan D'costa)
- Make Foodcritic pass



0.2.0 (2016-05-12)
------------------
- Add rake tests, Rubocop tests currently fail
- Add support for Tyk 2.0 (Thanks to Gaelan D'costa)
- Bump dependencies to latest versions

0.1.2
-----
- Fix configuration attributes for dashboard

0.1.1
-----
- Fix service reload, on some platforms it is not available, so use restart instead. 

0.1.0
-----
- Initial release of tyk cookbook
