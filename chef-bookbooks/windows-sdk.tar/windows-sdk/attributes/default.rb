default['windows-sdk']['install_path'] = nil
