#
# Cookbook Name:: windows-sdk
# Recipe:: default
#
# Copyright (c) 2015 Chef Software, All Rights Reserved.

