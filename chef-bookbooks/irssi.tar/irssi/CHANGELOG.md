irssi Cookbook CHANGELOG
========================
This file lists the changes made in each version of the irssi cookbook.

## v0.2.0:

* Adding support for RHEL-like distros and Fedora

## v0.1.1:

* Current public release.
