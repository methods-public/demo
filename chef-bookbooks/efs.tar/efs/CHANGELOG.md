# efs CHANGELOG

## 1.0.1
- [mattlqx] - Fix resource not converging if fstab line exists but not mounted.

## 1.0.0
- [mattlqx] - Moved implementation to library, wrappered by resource and recipe.

## 0.1.5
- [mattlqx] - Gate more metadata for older Chef 11 delivery.

## 0.1.4
- [mattlqx] - Add supporting docs recommended by Supermarket.

## 0.1.3
- [mattlqx] - Add unit tests
- [mattlqx] - Relocate `ruby_block` logic to library function
- [mattlqx] - Add Travis CI

## 0.1.2
- [mattlqx] - Metadata tweaks

## 0.1.0
- [mattlqx] - Initial release of efs

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
