## Testing

### Test Kitchen

Set the `EFS_TEST_FSID` environment variable and run `kitchen test` with correct attributes to setup EC2 instances with the `kitchen-ec2` driver.

### RSpec

Rspec unit tests can be run by simply running `rspec`.
