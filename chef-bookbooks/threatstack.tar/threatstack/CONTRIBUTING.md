1. Fork the repository using Github.
2. Checkout a named feature branch created from the master branch.
3. Write tests using chefspec as appropriate.
4. Complete modifications or corrections.
5. Run the tests, ensuring they all pass. (See TESTING.md)
6. Submit a Pull Request to the master branch using Github.
