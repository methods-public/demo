override['nginx']['repo_source'] = 'nginx'
override['php-fpm']['user'] = 'nginx'
override['php-fpm']['group'] = 'nginx'
