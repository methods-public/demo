# Changes

* **BREAKING** Get this cookbook out of the business of installing Zookeeper
* **BREAKING** Rearrange the attribute hierarchy to clarify which attributes are common
    - Mainly this means moving the `zk` and `log_dir` attributes to places where they are obviously shared between masters and agents
* **BREAKING** Drop support for CentOS
* **BREAKING** Switch to Java 8
* Clean up the handling of /etc/mesos* config files
    - Put common files in common locations.
    - Use generic templates for files that are similar between master and agent, etc.
    - Fix a situation wherein /etc/default/mesos and /etc/mesos/zk are written twice if `et_mesos_slave` and `et_singularity` are running on the same node
* Add support for Ubuntu 16.04/SystemD

# Fixes

* **MAYBE BREAKING** Start and enable master and slave services automatically
    - I'm not entirely sure why this wasn't being done before but it seems to work in testing...
* `reload` doesn't actually do anything in mesos service scripts. Replace it with restart only.
