et_mesos CHANGELOG
This is the Changelog for the et_mesos cookbook.

## [Unreleased][unreleased]

### Changes

### Fixes

## v6.0.1 - (2017-02-03)

## Fixes

* Set ulimit with attributes instead of hardcoding (new default: 65535)

## v6.0.0 - (2016-09-15)

## Changes

* Add a CHANGELOG!
* **BREAKING:** Bump Mesos to 0.28.2
