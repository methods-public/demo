2.0.1 (2016-11-18)
-----

    * Add support for Chef >= 12.14.60

2.0.0 (2016-05-13)
-----

    * Add support for systemd using poise-service

1.0.1 (2015-03-16)
-----

    * Fix travis client.pem encryption

1.0.0 (2015-03-10)
-----

    * First release
