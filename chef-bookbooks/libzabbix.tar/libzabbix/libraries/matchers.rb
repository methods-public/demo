if defined?(ChefSpec)
end
