chef_gem 'zabbixapi' do
  action :install
  version '~> 2.4.2'
end
