# Original Author:: Nacer Laradji (<nacer.laradji@gmail.com>)
# Cookbook Name:: libzabbix
# Recipe:: default
#
# Copyright 2011, Efactures
#
# Apache 2.0
#
