default['dns']['master'] = ''
default['dns']['zones'] = []
default['dns']['rndc_key'] = ''
