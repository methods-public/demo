rackspace_nginx_php CHANGELOG
==================

1.0.0
-----
- Release as v1.0.0
- Dropped support for PHP 5.4
- Updated unit tests

0.0.5
-----
- Support for CentOS 6.7 instead of 6.6

0.0.4
-----
- Fix for rubocop tests

0.0.3
-----
- Improvements on integration tests

0.0.2
-----
- Pinned upstream cookbook versions
- Added 'supports' statements to metadata
- Various improvements and clean up on tests

0.0.1
-----
- First version
