default["ruby-install"]["git_url"] = "https://github.com/postmodern/ruby-install.git"
default["ruby-install"]["git_ref"] = "v0.5.0"
default["ruby-install"]["install_path"] = nil
default["ruby-install"]["rubies"] = []
