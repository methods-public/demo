# Changelog

## 4.0.1 2017-12-07

- Fix #3 Using cookbook-specific function names to avoid conflicts
- Use cookstyle gem

## 4.0.0 2017-03-17

- Rename sensitive attribute to confidential to be Chef 13 compatible

## 3.0.0 2017-02-03

- Remove default recipe 
- Merge domain attribute into username

## 2.2.0 2017-01-01

- Add AutoLogonCount support 

## 2.1.0 2016-12-31

- Add enable/disable resource

## 2.0.0 2015-09-22

- Merge remove recipe into default recipe

## 1.0.1 2015-07-28

- Fix #1 WARN: Cloning resource attributes from prior resource (CHEF-3694)

## 1.0.0 2015-05-20

- Initial release
