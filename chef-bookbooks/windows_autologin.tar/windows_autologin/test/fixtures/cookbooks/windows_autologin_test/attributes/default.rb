default['windows_autologin_test']['username'] = 'Administrator'
default['windows_autologin_test']['password'] = 'password'
