windows_autologin node['windows_autologin_test']['username'] do
  action :disable
end
