If you would like to contribute, please do one of the following:

1) For simple changes, please use pull requests.

2) Use branches for more complex changes, longer topics, and so on. In general, if the changes are within a single topic, using a pull request is just fine.

3) Run kitchen tests for all variants listed in `kitchen list`.

4) Once you are ready to publish your changes:
   Update the metadata.rb and push your changes.
   Create a tag "New release x.x.x" for release cycle.
   Share/Upload the new cookbook version at Chef supermarket

