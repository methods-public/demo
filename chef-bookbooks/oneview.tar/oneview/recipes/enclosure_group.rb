# (c) Copyright 2016 Hewlett Packard Enterprise Development LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.

# my_client = {
#   url: 'https://10.101.41.146',
#   user: 'administrator',
#   password: 'serveradmin',
#   ssl_enabled: false,
#   api_version: 500
# }

my_client = {
  url: 'https://16.124.133.232',
  user: ENV['ONEVIEWSDK_USER'],
  password: 'ecosystem',
  ssl_enabled: false,
  api_version: 500
}

oneview_enclosure_group 'Eg2' do
  data(
    stackingMode: 'Enclosure',
    interconnectBayMappingCount: 8
  )
  logical_interconnect_groups ['e10_encl_group logical interconnect group']
  client my_client
  action :create
end

# The set_script action is only available for C7000.
oneview_enclosure_group 'Eg2' do
  client my_client
  api_variant 'C7000'
  script '#TEST COMMAND'
  action :set_script
end

oneview_enclosure_group 'Eg2' do
  client my_client
  action :delete
end
