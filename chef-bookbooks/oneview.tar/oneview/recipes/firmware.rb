# (c) Copyright 2016 Hewlett Packard Enterprise Development LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.

my_client = {
  url: 'https://10.101.41.146',
  user: 'administrator',
  password: 'serveradmin',
  ssl_enabled: false,
  api_version: 500
}

firmware_list = ['/oneview/bundles/custom-spp-c7000.iso', '/oneview/bundles/hp-firmware-a1b08f8a6b-HPGH-1.1.i386.rpm', 'CustomSPP', 'CustomSPP2']
# firmware_list = ['/oneview/bundles/custom-spp-synergy.iso', '/oneview/bundles/hp-firmware-a1b08f8a6b-HPGH-1.1.i386.rpm', 'CustomSPP', 'CustomSPP2']

# Example: Upload a firmware bundle
oneview_firmware '/oneview/bundles/custom-spp-c7000.iso' do
  client my_client
end

# Example: Upload a firmware bundle
oneview_firmware '/oneview/bundles/hp-firmware-a1b08f8a6b-HPGH-1.1.i386.rpm' do
  client my_client
end

# Example: Create a custom spp
# Uses spp_name and hotfixes_names
oneview_firmware 'CustomSPP' do
  client my_client
  spp_name 'version 2 2016 11 18'
  # spp_name 'thunderbird 2016 11 18'
  hotfixes_names [
    'Supplemental Update / Online ROM Flash Component for Linux - MB1000GCWCV, MB2000GCWDA, MB3000GCWDB, and MB4000GCWDC Drives'
  ]
  action :create_custom_spp
end

# Example: Create a custom spp
# Uses spp_file and hotfixes_files as reference
oneview_firmware 'CustomSPP2' do
  client my_client
  spp_file '/oneview/bundles/custom-spp-c7000.iso'
  hotfixes_files ['/oneview/bundles/hp-firmware-a1b08f8a6b-HPGH-1.1.i386.rpm']
  action :create_custom_spp
end

# Example: Remove firmwares
firmware_list.each do |fw|
  oneview_firmware "#{fw}" do
    client my_client
    action :remove
  end
end
