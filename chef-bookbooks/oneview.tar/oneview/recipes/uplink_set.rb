# (c) Copyright 2016 Hewlett Packard Enterprise Development LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed
# under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, either express or implied. See the License for the
# specific language governing permissions and limitations under the License.

# NOTE: This recipe requires:
# - Ethernet Networks: Ethernet1, Ethernet2
# - FC Network: FCNetwork1
# - FCoE Network: FCoENetwork1
# - Logical Interconnect: LogicalInterconnect1
# - Enclosure: MyEnclosure

my_client = {
  url: 'https://16.124.133.232',
  user: ENV['ONEVIEWSDK_USER'],
  password: 'ecosystem',
  ssl_enabled: false,
  api_version: 500
}
# OneviewSDK::ServerHardwareType.find_by(my_client, name: 'BL460c Gen8 1').first || raise('HW Type not found!')
# port = uplink.get_unassigned_ports.first

# Example: creates or updates an uplink set
# The Ethernet, FC, FCoE and Native Networks, as well as the associated Logical Interconnect,
# could be more conveniently declared by their names outside the data hash, as in the following
# example (URIs will not be accepted in this case). Notice that you can also declare an Enclosure
# within the locationEntries parameter by the Enclosure name instead of its URI.
# The portConfigInfos parameter is optional, as OneView creates it for you)
oneview_uplink_set 'UplinkSet1' do
  client my_client
  data(
    nativeNetworkUri: nil,
    reachability: 'Reachable',
    manualLoginRedistributionState: 'NotSupported',
    connectionMode: 'Auto',
    lacpTimer: 'Short',
    networkType: 'Ethernet',
    description: nil,
    # portConfigInfos:
    # [
    #   desiredSpeed: 'Auto',
    #   location:
    #   {
    #     locationEntries:
    #     [
    #       { value: '/rest/enclosures/0000000000A66101', type: 'Enclosure' }
    #     ]
    #   }
    # ]
  )
  logical_interconnect 'e10-e10_encl_group logical interconnect group' # Name of the associated logical interconnect
  networks ['ChefEthernet2'] # Array of strings containing the name of the associated ethernet networks (can be empty - [])
  # fc_networks ['FCNetwork1'] # Array of strings containing the name of the associated fc networks (can be empty - [])
  # fcoe_networks ['FCoENetwork1'] # Array of strings containing the name of the associated fcoe networks (can be empty - [])
  native_network nil # Name of the native network (can be nil)
end

# Example: creates an uplink set if it does not exist yet
oneview_uplink_set 'UplinkSet1' do
  client my_client
  data(
    reachability: 'Reachable',
    manualLoginRedistributionState: 'NotSupported',
    connectionMode: 'Auto',
    lacpTimer: 'Short',
    networkType: 'Ethernet',
    ethernetNetworkType: 'Tagged',
    description: nil
  )
  action :create_if_missing
end

# Example: deletes an uplink set
oneview_uplink_set 'UplinkSet1' do
  client my_client
  action :delete
end
