## 0.1.0 (July 12, 2016)
  - Initial version of the cookbook. Check `README.md`.
