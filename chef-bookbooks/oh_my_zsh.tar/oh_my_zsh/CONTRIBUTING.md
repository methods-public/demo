I am very happy to accept this PRs or work on issues to extend the usage of this cookbook.

Just use the [issue queue](https://github.com/EugenMayer/chef-oh_my_zsh/issues) or even better, create pull requests for what you like to improve.