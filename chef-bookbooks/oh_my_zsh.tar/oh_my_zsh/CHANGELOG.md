# Changelog

## 0.1.4
 - fix login usage for owner/group in ark being nil
 
## 0.1.2
 - missing name for ark
 - fix permissions of oh_my_zsh folder
 
## 0.1.2
 - fix clone resource issue
 
## 0.1.1
 - remove update and make ensure the the "update" and the default. The old ensure is now called create
 - Fix README layout
 
## 0.1.0
 - Initial release
 - added optional support for .zshrc.chef.local and .zshrc.user.local to be able to easily customize the zsh configuration, aliases or similar
 - merged https://github.com/lxmx/chef-oh-my-zsh/pull/1 - support for :locale and export locale
 - merged https://github.com/lxmx/chef-oh-my-zsh/pull/2 - smaller gliches fixed
