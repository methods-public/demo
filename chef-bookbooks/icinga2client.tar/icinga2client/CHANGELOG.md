icinga2client CHANGELOG
==================

1.0.0
-----

- Virender Khatri - first commit
