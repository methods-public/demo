# Cookbook Name:: op5_manage
# Recipe:: default


include_recipe 'op5_manage::node'
