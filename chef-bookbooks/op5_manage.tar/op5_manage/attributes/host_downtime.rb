# Cookbook Name:: op5_manage
# Attributes:: host_downtime


default['op5_manage']['host_downtimes'] = {}

# Attributes for Test Kitchen are defined in .kitchen.yml