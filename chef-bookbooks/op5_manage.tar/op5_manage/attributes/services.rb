# Cookbook Name:: op5_manage
# Attributes:: service


default['op5_manage']['services'] = {}

# Attributes for Test Kitchen are defined in .kitchen.yml
