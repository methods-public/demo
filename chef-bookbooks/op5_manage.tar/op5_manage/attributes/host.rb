# Cookbook Name:: op5_manage
# Attributes:: host


default['op5_manage']['hosts'] = {}

# Attributes for Test Kitchen are defined in .kitchen.yml
