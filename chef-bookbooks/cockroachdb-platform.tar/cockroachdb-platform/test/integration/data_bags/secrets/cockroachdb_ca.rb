# rubocop:disable all
{"id"=>"cockroachdb-ca",
 "crt"=>
  {"encrypted_data"=>
    "SujhhET31oiihaAkvSi2RdIXY8p8tcrC0Me3aCHgEY7dbPeuFPB4GEmpX/+P\n" +
    "3m7ZpUzQkBh9k9/TM7vp1Hhlz586ZOBm0DkDVekDDKwc/iF3j7MxnNeJFyCK\n" +
    "jPffoZLX0EBNJgJLOjoUhae7m2QUPJGWYOeKRVtvYGv+rSGSUsfeQUlnP2Ix\n" +
    "rTXe1VGIGKTThTlu9nBrMPJNZXsHnm7tziZEJjSOdqRQySSfFjhUD0vAtsk8\n" +
    "1CMUHqFJa4YROqfyx4oE53pXgbMOCorhmoQGennZi0n+/diUutocQYhPgGP9\n" +
    "wD0xPl5yGfY4zj6Sf3Lx2kmTHVTUtMQkyEvy3sF/d2nyQ/7qrKnTj62a0k0e\n" +
    "jWa+uPUq0jXudusuyK649VCkcTR6FeCfQTQS1n1Y6GtyXSeYZeoCO1aNOkYf\n" +
    "K7szYDfKu/OlzPPju0qCLSZu61ixhf3J1fZIZpSiBb8eprxe00raLpow6XDo\n" +
    "zAUreedJjyRuaXcFjQTKMCA6SSdTV+KeSOLu+eqGbmPeO8UVqwkoYm6HjfKn\n" +
    "VoMxcyt6MCT782PsXRjADZX6K9Sy/mJ0UFiLhZag7V4fYBdR5DAQZZpYHa2D\n" +
    "QdihxpTjOJUu0IxcRvL3J2HekERExt0l1sNwrk+zx01rsQQRreQHIr8TCjl2\n" +
    "AJ7/QquXNmnKV4WiazHkqjoWp8TeAZOM9VF7lVEhDFJKVRH9B6UiJyg0yi5E\n" +
    "mZV/ieWSMnFqOjCsvmkJ5zsg31/0PUtQjhf4KS5a3ofrD1wVvoLuMsEhKZEd\n" +
    "4X0ttjEHDPkIM6H7qrVnoNrAFOpVMJd43P1R34YD8auCG7gO7oeRUXwtDRhl\n" +
    "FVnXmcVacj+wOdTRbYlCsk+95kPquYMU3ZUKXD+HiCCbvaa2Ko1M2QwZNIXc\n" +
    "6U+M27Tx3nLo4ItW+QgCKXy6Pf6gTgi+Xxy+Rbn0vhA+GDOvnUO45/l8LtFp\n" +
    "RSWdaGbX+UkGHK34IQz77iegh2itPqBOjjlWnz3b8DpyzWGXfwJfPdW/Kelt\n" +
    "xSI9FukMVtvg7y/JmqjSiF80KBUuRJZlpvoI3EtBzR7focXYW6Xq2M2t8hKp\n" +
    "TlWzgDigOyL6FuoGEIccVd4jzoc15TlgfTkcbtU3Vp+4AKMq5hNISbr0fwOR\n" +
    "e4F1ZSIWeXi0usueJc2Px3x5ev6RAJiz/ENcjvMd7gr8ozdA77+R9gzFPODa\n" +
    "eJNCmRSFS8Kmdxyy6GNn1byxLldBnlAYqlS0X/NEF3Vj3bGJ7+6emyI2x1Cm\n" +
    "wM2b+7gQW63jXOp4FiNG423lxvklM3Y4e2iLJD6GjhFVSyCkjBIJrf2mVD9Z\n" +
    "/M1SFaxfnL9N8/GVdGlV7f/cn4c0z62jSvqXD5g0SG3/b4TsfGa1UG8BiQAq\n" +
    "/cYO5EgbBn4aaWHARnhAEwl99qoWd+k1tmDg6idxZ945DZ4gYUpB7k2rD48W\n" +
    "x6V+/XLUoliiyB0wMc1E/O8SxA5GAs+2jzYFttu/o8w9U/wofwqf+p0FUNBn\n" +
    "/uVVBD/pGCGK1Y6LyHe17utha7fbuYbA\n",
   "iv"=>"ura5zbO/ANzG/HiW\n",
   "auth_tag"=>"idWlFeA/Sq8USYHdtbDnCg==\n",
   "version"=>3,
   "cipher"=>"aes-256-gcm"},
 "key"=>
  {"encrypted_data"=>
    "yjMqzEb1r8l6uZ4d/BrGqYUM+EwfOYc2FPmf3c7inqQotupUfPPp5C77WLyP\n" +
    "svm6HsRy9ANVa25mM3uF/bmbdO8RhoT0U0TAEW1i/AULISqyuQPsV8eTSfQD\n" +
    "Pi4bPGdDU1PqgH0QJxDSfOVzve3yr2TSgsYjwGTMv+ia1vhPbHHVgf294R5+\n" +
    "E5Fc43g3B8XUdhytELAJDpDcu4hoNDJRNCrxrldXkjsaSh+CvSA1caymS9zM\n" +
    "t0Y4ixL3XLXLB3feqDZkY3+NHl2hc55P29WcPKc10xIGRZcpPam0N7/wrHEM\n" +
    "RvdSPq9gMTNHTUD05Jcmxo0tAS/CJZaJRsrxH5wbigdXo0rDvQuqOON7EKWt\n" +
    "M89QMd7VeIrXXbnATtZh23YKDQdtPStM6rdaSVQ1ioTf+s5BttSRJRLmS7NW\n" +
    "+gkceM6THhV23P39fwzVuxGpvd/uX8+ZKJ6sIVBGXbHv/Nz/QmB6RACqTRQb\n" +
    "G/tfSnGHqGzQ74f8VCe85Ag9DBMvwg20qOKEGOc8yZH6USYAfLWP/8I1Zsbt\n" +
    "RhRtGWoWqc4iTRt9njVLOEf0U6oO/U3wENB4sKDdK29oLfeDqXnYpxyQvWxX\n" +
    "7DNVeMW2GUwpLGVipKyFBNWl0VpPy2OeL5oRJvUP8sFI7deb5gObYPBSPit0\n" +
    "hb5Oiw3nhmUTOB7Md3tLlyNJO8kH8uWt3S0zXALe0ojIxX2t80SPInExinSI\n" +
    "JHgCPG/AT6euxsC/HX31XO9qXpAnfnGkU8fsFiKUUg6HbF9xSZo4xUqvYhW2\n" +
    "vrQCc0dPE7K652BiiSYTh6iiWCga5kbb8caSbbGbkeFZMbnFJ/1hM0o+RKEb\n" +
    "i/rwYo00MOXdvKnmjNpfxiJu7fyQ7ZNS/ok1QIj4QdpFb6bqhY262dwl5hxl\n" +
    "5gEuc/KIlsLFs5xNzReUEeg6bkoF0P48q9RNhIkFb028/2jnpkFsbEZ8Yv5M\n" +
    "2KGP6jA22yEO0I48fMuVijai2BvX8rB5YfEQGg/HiglkfgOdhAdk8TMySj/x\n" +
    "ADhqWt1ziYWY5t7cNUba8zdCWbOG7+5XPB2+rMfnIPBQbTnndVVfQMtnjLkz\n" +
    "ihZdDBZ0lawUedliFRpJjHi7+0vYzeX0+jJriCbJVPUBIfZ7RnjexpjELIU6\n" +
    "Ll96htizqUBTB9BrBjk3cmmLOcLFhN/akP91P7cHZrJj+QUaoWGDKsUlA+Nm\n" +
    "riGMjmrW8cr6uMAmotll0laxSlhXpBQbZPB7gGIa23gzgYWutiJj+wJVF4Wy\n" +
    "aStInRC1u0tmLYXC17dnPj7ZNZm1cjuRu2ELLHRRcUKYLURdCmzitIQxXbop\n" +
    "r5lh2dN6yzKxLRnkGgRhJVE49I164OkxbMWZ5QUN9iZEoIcLqMuUoFsQCZ2Q\n" +
    "SSuVxOBScWvN4eYWhUAc08BNWYUoYCgjMOaDKz4K0Rzd7JwtjVGWZIR0BTCD\n" +
    "D80xng4gpah+ryWYn2C+AHT1a+90aI4CuaOchQhTz2XJNWAdZg/G17TucE67\n" +
    "mkQq3hlH6wsYoQPCK+c1oIz/0T5i+bgNwQUvY4OEK/EUFU1qVqcYPdexla96\n" +
    "a6OQIlkarOU5q9DgM1b32aSDf8wFO+lBcJeKzXdEHkk6wmZVKN7NvzthOBxY\n" +
    "XRSdiciWY5y2C/Ca9DwdaMEAmeOeR6wzUP6neA8orW8OfPi1O6o7SC4lsH1M\n" +
    "vmozI2BmZN7WFBwlhEeqx/4CadlJPGFJ03ybFNkKYF+LXFTbhdk+hlyfoVxO\n" +
    "XpaAZb+0TCjdaCpwWAG87c7joHPpV65Gw6vsyrjb8rslzH2A5XwV9Yk2TQfS\n" +
    "Qdnfe98PaVfGlikrwOBzqrWJUf2g3g6tZSe6Px/uwckNiCN2BBJZCfqGSrSQ\n" +
    "USXVLycTykq54oB9USmVmIlywZI2+BGf4yxvJewsUU4RfzDtFXM22L5Okf1S\n" +
    "AZu/14cyUF9n1zjrzTFVfYkDkeMRTt5JosDTDzDrO2fsGejYfmJoMXPwSRZS\n" +
    "LrfzolOjxViTUGJLWSoGyWMjaFqB0rECHPis0V0DkU3GVERaIe2EorhTiie+\n" +
    "ILR/piFwor0VwkCwS40BHQAI/ztvcOH/GwTpeSpheW/Zee+bKL4HGF8dA1sR\n" +
    "DTm6e3gJf7AhpN/WEPyhqwrnuDwL2qrR9waKQPKDZnyfBEmx3yacn0eyZJCx\n" +
    "6KsxtqxdHGz1gA91q4/ycmGeS070+kfr32QcXVNb6NTt8osUVJQbC9PWuG7L\n" +
    "1+w04euUeMBmDAnKqZW7ssfAIxupKp60vs8kLxeZtSAGmTjUoTP0pt2DhLGt\n" +
    "yEDJZls0E5nO2U8=\n",
   "iv"=>"vc0tUPsQ2swvmCVy\n",
   "auth_tag"=>"KpFk02DGAqTnGBCR1tTrBg==\n",
   "version"=>3,
   "cipher"=>"aes-256-gcm"}}
