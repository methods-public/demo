default['scanner-nmap']['scan']['output']   = :xml
default['scanner-nmap']['scan']['filename'] = '/tmp/nmap_scan.xml'
default['scanner-nmap']['scan']['options']  = '-Pn -A'
default['scanner-nmap']['scan']['target']   = '127.0.0.1'
