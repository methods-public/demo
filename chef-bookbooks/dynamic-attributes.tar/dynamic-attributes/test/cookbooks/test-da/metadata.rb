name 'test-da'
maintainer 'Make.org'
maintainer_email 'sre@make.org'
license 'Apache-2.0'
description 'Test Dynamic Attributes Cookbook'
long_description 'Test Dynamic Attributes Cookbook'

version '1.0.0'

chef_version '>= 12.0'

depends 'dynamic-attributes'
