
# frozen_string_literal: true

include_recipe 'confluent::_install'
