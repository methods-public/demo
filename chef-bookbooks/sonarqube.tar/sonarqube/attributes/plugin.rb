default['sonarqube']['plugin']['mirror'] = 'https://sonarsource.bintray.com/Distribution'

default['sonarqube']['plugin']['dir'] = "/opt/sonarqube-#{node['sonarqube']['version']}/extensions/plugins"
