default['sonarqube']['scanner']['mirror'] = 'https://sonarsource.bintray.com/Distribution/sonar-scanner-cli'
default['sonarqube']['scanner']['version'] = '2.5'
default['sonarqube']['scanner']['checksum'] = 'e2ec5f4b73aa7911f10518e304db3af0146a4347b8d06fc1d4a36b8baec0d8cc'

default['sonarqube']['scanner']['host']['username'] = nil
default['sonarqube']['scanner']['host']['password'] = nil
default['sonarqube']['scanner']['host']['url'] = 'http://localhost:9000'
