# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## 2.0
### Features
- A complete rewrite using the [collectd cookbook][0] custom resources for
  configuring individual plugins.

[Unreleased]: https://github.com/johnbellone/collectd_plugins-cookbook/compare/v2.0.2...HEAD
[0]: https://github.com/bloomberg/collectd_plugins-cookbook
