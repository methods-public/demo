default['unbound']['remote_control']['enable'] = 'no'
default['unbound']['remote_control']['interface'] = '127.0.0.1'
default['unbound']['remote_control']['port'] = '953'

# default['unbound']['dnssec'] - disabled by default, future todo
