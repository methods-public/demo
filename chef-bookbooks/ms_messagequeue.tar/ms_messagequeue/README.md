Description
===========

This cookbook installs the Microsoft Message Queueing service

Requirements
============

Windows cookbook

Attributes
==========

None

Usage
=====

Apply the cookbook to your runlist
