default['docker-machine']['release'] = '0.13.0'
default['docker-machine']['command_path'] = '/usr/local/bin/docker-machine'
default['docker-machine']['group'] = 'docker'
