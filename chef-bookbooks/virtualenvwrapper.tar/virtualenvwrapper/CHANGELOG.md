# 0.1.1

* Fixed metadata typo for supported platforms.

# 0.1.0

* Initial release of virtualenvwrapper
