name             'virtualenvwrapper'
maintainer       'Patrick Ayoup'
maintainer_email 'patrick.ayoup@gmail.com'
license          'MIT'
description      'Installs/Configures virtualenv'
long_description 'Installs/Configures virtualenv'
supports         'centos', "= 6.5"
version          '0.1.1'

depends 'python', '~> 1.4.6'
