v0.0.2
------

* Follow redirects while downloading installer

