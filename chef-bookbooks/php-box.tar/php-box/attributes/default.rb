#
# Cookbook Name:: php-box
# Attributes:: default
#
# Copyright 2013, Sergey Storchay
#
# Licensed under MIT:
# http://raw.github.com/r8/chef-php-box/master/LICENSE.txt

default["php-box"]["install_globally"] = true
default["php-box"]["prefix"] = "/usr/local"
