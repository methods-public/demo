# Changelog

## 3.1.0

- Support for Mac OS X

## 3.0.0

- Support for Sikulix 1.1.0 

## 2.0.3

- GitHub issues link invalid

## 2.0.2

- No X11 DISPLAY

## 2.0.1

- Change license from All Rights Reserved to MIT

## 2.0.0

- Add ubuntu support
- Remove support for JRuby Addons and Remote Server
- Refactor attribute names

## 1.0.0
  
- Add support for Remote Server
- Refactor Setup attribute names
- Place guard on Setup to run only once
- Fix memory bug with Setup

## 0.1.0

- Initial release using sikulix v1.1.0 nightly builds
