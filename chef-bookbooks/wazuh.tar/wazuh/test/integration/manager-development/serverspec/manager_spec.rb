require 'spec_helper'
require 'common_ossec_tests'
require 'common_manager_tests'
