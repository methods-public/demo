## v0.0.9
Amazon Linux OS included in repository.rb
## v0.0.8
Fixed bugs in ossec_to_xml #4 Thanks @smith3v
## v0.0.1

* Initial/current release
