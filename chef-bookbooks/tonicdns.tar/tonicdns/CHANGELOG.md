# 1.0.4
* getting md5 hash of user password moved to library

# 1.0.3
* fixed tests to run against serverspec v2

# 1.0.2
* added support for centos7 and debian6

# 1.0.1
* fixed converge error if deployed on top of poweradmin cookbook
* fixed critical php5 dependency
* fixed foodcritic FC002 warning
* fixed apache port selection
* added serverspec tests
* added travis-ci integration

# 1.0.0
Initial release of tonicdns
