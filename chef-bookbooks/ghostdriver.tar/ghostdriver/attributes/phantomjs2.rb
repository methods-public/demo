node.override['phantomjs2']['version'] = '1.9.8'
