# Changelog

## 1.1.0 2016-09-26

- Use phantomjs2
- Use phantomjs v1.9.8

## 1.0.1 2015-09-15

- Update metadata description

## 1.0.0 2015-07-28

- Initial release
