nexus3 'nexus' do
  action :install
end
