# Changelog

## 3.0.0 2017-03-17

- Rename sensitive attribute to confidential to be Chef 13 compatible

## 2.0.0 2017-02-03

- Remove default recipe 

## 1.1.0 2017-01-02

- Add run resource

## 1.0.4 2016-12-21

- Fix #6 WARN: node.set is deprecated and will be removed in Chef 14
- Fix #5 NoMethodError when password is nil on non-windows platform

## 1.0.3 2015-11-10

- Fix #3 Cannot handle percent character in password

## 1.0.2 2015-07-28

- Fix #2 Multiple rdp_local directories are created under C:\Users 

## 1.0.1 2015-07-27

- Fix #1 Cannot create directory due to insufficient permissions

## 1.0.0 2015-07-28

- Initial release
