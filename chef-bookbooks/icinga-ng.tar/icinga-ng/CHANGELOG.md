# 0.1.7
* Fixed issue with missing cgis.

# 0.1.6
* Fixed permissions for External Command Interface.
* Fixed build of icinga with Checkinstall in Debian 6/7 os.

# 0.1.5
* Rewrited common recipe to user Checkinstall instead of make.

# 0.1.4
* Added common recipe for debian/rhel recipes.
* Added CentOS 6 support.

# 0.1.3
* Fixed small issues.
* Removed hardcoded lines.

# 0.1.2
* Added Debian 7 support.
* Added Ubuntu 12 support.
* Added possibility to change icinga admin name.

# 0.1.0
* Initial release of icinga-ng
