TODO
====

* [ ] Fix Chef 13 support.
* [ ] Cache cookies by username in API::HTTP library.
* [ ] Add update action to resources.
* [ ] Use kitchen-dokken for integration tests.
