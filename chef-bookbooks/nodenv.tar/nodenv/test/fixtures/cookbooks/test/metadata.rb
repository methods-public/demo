name 'test'
version '0.1.4'

depends 'nodenv'
depends 'apt'
