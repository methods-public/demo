## v0.0.5

  Update RPM urls

## v0.0.4

  Update RPM urls

## v0.0.3

  Fix minor typos and syntax errors
  Allow ignore_failure true, if rhn_setup_gnome or something is missing
  Fix redhat-release package name for platform_version 6

## v0.0.2

  Initial version of el2centos conversion recipe, enjoy!
