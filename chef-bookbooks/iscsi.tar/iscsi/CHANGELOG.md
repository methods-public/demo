v1.0.0
------

  * Remove el-sysctl, to be deprecated
  * Add sysctl cookbook, change attributes, update documentation
  * Add EL6 support
  * Add Chefspec
  * Add Rubocop
  * Add BATS
  * Add Kitchen
  * Remove minitest

v0.0.6
------

  * Add Kurt Garloff's rescan-scsi-bus scipt
  * Re-factor recipe to comply with foodcritic
  * Add attribute tests
