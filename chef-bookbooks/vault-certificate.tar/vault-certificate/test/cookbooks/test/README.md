This cookbook is used with [test-kitchen](http://kitchen.ci/) to test the parent, [vault_certificate](https://supermarket.chef.io/cookbooks/vault_certificate) cookbook.
