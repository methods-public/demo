# Recipes

The examples beginning with 'examples~' are ready to be run for creating GCP
resources.

The examples beginning with 'tests~' are not meant to be run without the
end-to-end test runner included with the Magic Module code generator.
