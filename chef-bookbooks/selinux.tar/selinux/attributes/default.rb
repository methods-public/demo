default['selinux']['status'] = 'enforcing'
default['selinux']['booleans'] = {}
