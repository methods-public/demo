# selinux Cookbook CHANGELOG
This file is used to list changes made in each version of the selinux cookbook.

## 2.1.0 (2017-09-15)

- Simplify Travis config and fix ChefDK 2.0 failures
- Use bento slugs in Kitchen
- Remove maintainer files
- More cleanup of the maintainer files
- Speed up install with multi-package install

## 2.0.3 (2017-06-13)

- Fix boolean check within default recipe

## 2.0.2 (2017-06-05)

- Permissive guard should grep for permissive not just disabled

## 2.0.1 (2017-05-30)

- Remove class_eval usage

## 2.0.0 (2017-05-15)

- Deprecate debian family support 
- Make default for rhel family use setenforce regardless of whether a temporary change or not. Eliminates the requirement for a required reboot to effect change in the running system.

## 1.0.4 (2017-04-17)

- Switch to local delivery for testing
- Use the standard apache license string
- Updates for early Chef 12 and Chef 13 compatibility
- Update and add copyright blocks to the various files

## 1.0.3 (2017-03-14)

- Fix requirement in metadata to reflect need for Chef 12.7 as using action_class in state resource.

## 1.0.2 (2017-03-01)

- Remove setools* packages from install resource (utility to analyze and query policies, monitor and report audit logs, and manage file context). Future versions of this cookbook that might use this need to handle package install on Oracle Linux as not available in default repo.

## 1.0.1 (2017-02-26)

- Fix logic error in the permissive state change

## 1.0.0 (2017-02-26)

- **BREAKING CHANGE** `node['selinux']['state']` is now `node['selinux']['status']` to meet Chef 13 requirements.
- Update to current cookbook engineering standards
- Rewrite LWRP to 12.5 resources
- Resolved cookstyle errors
- Update package information for debian based on https://debian-handbook.info/browse/stable/sect.selinux.html
 - selinux-activate looks like it's required to ACTUALLY activate selinux on non-RHEL systems. This seems like it could be destructive if unexpected.
- Add property temporary to allow for switching between permissive and enabled
- Add install resource

v0.9.0 (2015-02-22)
-------------------
- Initial Debian / Ubuntu support
- Various bug fixes

v0.8.0 (2014-04-23)
-------------------
- [COOK-4528] - Fix selinux directory permissions
- [COOK-4562] - Basic support for Ubuntu/Debian


v0.7.2 (2014-03-24)
-------------------
handling minimal installs


v0.7.0 (2014-02-27)
-------------------
[COOK-4218] Support setting SELinux boolean values


v0.6.2
------
- Fixing bug introduced in 0.6.0 
- adding basic test-kitchen coverage


v0.6.0
------
- [COOK-760] - selinux enforce/permit/disable based on attribute


v0.5.6
------
- [COOK-2124] - enforcing recipe fails if selinux is disabled

v0.5.4
------
- [COOK-1277] - disabled recipe fails on systems w/o selinux installed

v0.5.2
------
- [COOK-789] - fix dangling commas causing syntax error on some rubies

v0.5.0
------
- [COOK-678] - add the selinux cookbook to the repository
- Use main selinux config file (/etc/selinux/config)
- Use getenforce instead of selinuxenabled for enforcing and permissive
