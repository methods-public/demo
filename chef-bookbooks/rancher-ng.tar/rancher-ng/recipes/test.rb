docker_service 'default' do
  action %i[create start]
end
