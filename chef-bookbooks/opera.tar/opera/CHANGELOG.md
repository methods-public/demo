# Changelog

## 1.1.0 

- Fix FC052: Metadata uses the unimplemented "suggests" keyword
- Update metadata source_url and issues_url

## 1.0.0 

- Support windows

## 0.1.0

- Initial release
