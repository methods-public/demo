default['opera']['track'] = 'stable' # or 'beta'
default['opera']['url'] = 'http://net.geo.opera.com/opera/'

default['opera']['apt_uri'] = 'http://deb.opera.com/opera-stable/'
default['opera']['apt_key'] = 'http://deb.opera.com/archive.key'
