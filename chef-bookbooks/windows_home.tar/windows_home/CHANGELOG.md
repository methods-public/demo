# Changelog

## 2.0.0 - 2017-03-17

- Rename sensitive attribute to confidential to be Chef 13 compatible

## 1.1.0 - 2017-01-02

- Add sensitive attribute
- Use use_inline_resources 

## 1.0.0 - 2015-03-28

- Initial release (ported over from windows_desktop)
