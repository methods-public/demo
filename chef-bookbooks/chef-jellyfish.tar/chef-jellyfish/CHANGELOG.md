chef-jellyfish CHANGELOG
===================

This file is used to list changes made in each version of the chef-jellyfish cookbook.

1.0.0
-----
- Tom McGonagle - Initial release of chef-jellyfish cookboook.