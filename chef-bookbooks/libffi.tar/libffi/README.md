# libffi-cookbook
Chef cookbook to install [libffi](https://sourceware.org/libffi/).
