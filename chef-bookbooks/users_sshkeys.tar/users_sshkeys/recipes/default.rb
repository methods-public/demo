#
# Cookbook Name:: users_sshkeys
# Recipe:: default
#

# Empty default recipe for including LWRPs.
