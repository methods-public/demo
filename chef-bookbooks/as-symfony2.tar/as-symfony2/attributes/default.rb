
default['symfony2']['version'] = ''
default['symfony2']['develop'] = false
default['symfony2']['path'] = '/var/www/app'
default['symfony2']['maintenance']['hostip'] = '192.168.33.1'
default['symfony2']['maintenance']['user'] = 'vagrant'
default['symfony2']['maintenance']['group'] = 'vagrant'
default['symfony2']['execute_user'] = 'apache'
default['symfony2']['execute_group'] = 'apache'
default['symfony2']['acl'] = true
