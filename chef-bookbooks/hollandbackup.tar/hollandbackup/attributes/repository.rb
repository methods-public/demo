#
# Cookbook Name:: hollandbackup
# Attributes:: repository
#
# Copyright (c) 2016, David Joos
#

default['hollandbackup']['repository']['distro'] = 'xUbuntu_12.04'
