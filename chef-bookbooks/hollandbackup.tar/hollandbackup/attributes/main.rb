#
# Cookbook Name:: hollandbackup
# Attributes:: main
#
# Copyright (c) 2016, David Joos
#

default['hollandbackup']['main']['plugin_dirs'] = nil
default['hollandbackup']['main']['backup_directory'] = nil
default['hollandbackup']['main']['backupsets'] = nil
default['hollandbackup']['main']['umask'] = nil
default['hollandbackup']['main']['path'] = nil
default['hollandbackup']['main']['filename'] = nil
default['hollandbackup']['main']['level'] = nil
