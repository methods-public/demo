#
# Cookbook Name:: hollandbackup
# Attributes:: backupsets
#
# Copyright (c) 2016, David Joos
#

default['hollandbackup']['backupsets'] = {}
