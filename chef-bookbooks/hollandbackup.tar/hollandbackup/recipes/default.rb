#
# Cookbook Name:: hollandbackup
# Recipe:: default
#
# Copyright (c) 2016, David Joos
#

include_recipe 'hollandbackup::repository'
