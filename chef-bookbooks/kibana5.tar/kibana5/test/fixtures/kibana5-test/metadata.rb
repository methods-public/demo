name 'kibana5-test'
description 'Testing cookbook kibana5'
version '0.1.0'

depends 'java'
depends 'elasticsearch', '< 4.0'
depends 'nginx'
depends 'kibana5'
