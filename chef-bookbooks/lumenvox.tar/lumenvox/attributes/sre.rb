default['lumenvox']['sre']['version']           = nil
default['lumenvox']['sre']['logging_verbosity'] = 1
default['lumenvox']['sre']['language_packs']    = []
