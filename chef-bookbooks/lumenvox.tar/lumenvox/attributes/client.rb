default['lumenvox']['client']['license_servers']      = ['127.0.0.1:7569']
default['lumenvox']['client']['sre_servers']          = ['127.0.0.1:5730']
default['lumenvox']['client']['tts_servers']          = ['127.0.0.1:7579']
default['lumenvox']['client']['default_tts_language'] = 'default'
default['lumenvox']['client']['default_tts_gender']   = 'default'
default['lumenvox']['client']['default_tts_voice']    = 'default'
default['lumenvox']['client']['version']              = nil

default['lumenvox']['client']['authentication_username'] =  nil
default['lumenvox']['client']['authentication_password'] =  nil
