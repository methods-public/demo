default['lumenvox']['core']['version'] = nil
