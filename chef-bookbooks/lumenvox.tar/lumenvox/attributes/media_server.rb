default['lumenvox']['media_server']['version']            = nil
default['lumenvox']['media_server']['mrcp_server_ip']     = 'default'
default['lumenvox']['media_server']['enable_sre_logging'] = 0
default['lumenvox']['media_server']['sre_ip']             = 'default'
default['lumenvox']['media_server']['sip_port']           = 'default'
