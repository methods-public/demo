default['lumenvox']['license_server']['version'] = nil
