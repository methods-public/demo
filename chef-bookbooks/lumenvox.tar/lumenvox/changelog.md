# develop

# 0.1.1
  * Chris/Lindsey are the default US voices. Jason/Rebecca are TTS2, whatever that is.

# 0.1.0
  * Major clean up. Too much to document

# 0.0.2
  * Support for specifying version of all packages
  * Added Berkshelf files

# 0.0.1
  * Intial release
