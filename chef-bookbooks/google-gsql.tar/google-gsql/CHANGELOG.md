# Changelog

## 0.2.0 (2017-10-19)

### New features

- Added PostgreSQL support.

## 0.1.0 (2017-10-04)

Initial release
