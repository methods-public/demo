## 0.1.2 (January 19, 2015)

Added Redhat/CentOs support.

[@rdoorn]: https://github.com/rdoorn

## 0.1.1 (November 7, 2012)

Optimized some code.

[@demonccc]: https://github.com/demonccc

## 0.1.0 (November 7, 2012)

The initial release.

[@demonccc]: https://github.com/demonccc
