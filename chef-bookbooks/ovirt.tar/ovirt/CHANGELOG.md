ovirt cookbook CHANGELOG
========================

This file is used to list changes made in each version of the ovirt cookbook.

0.1.1
-----
- Created attributes for the answers file location, oVirt release package name, and oVirt release package URL.

0.1.0
-----
- Initial release of the ovirt cookbook.

