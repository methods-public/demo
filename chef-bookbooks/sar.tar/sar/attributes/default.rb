default['sar']['enabled'] = true
default['sar']['sa1_options'] = '-S DISK'
default['sar']['sa2_options'] = ''
default['sar']['cron']['run_every_minutes'] = '2'
