# kimchi Cookbook CHANGELOG

This file is used to list changes made in each version of the kimchi cookbook.

## 1.0.2 (2016-08-30)

- Loosen runit pin
- Update maintainers

## 1.0.1 (2016-08-30)

- Update kitchen.yml with ports and better defaults
- Added docs
- Added supermarket metadata
- Added badges to the readme
- Resolved rubocop warnings
- Add rakefile for testing and maintainers files
- Removed iptables version constraint
- Added additional platforms to the metadata
- Added Github issues and PR templates
- Removed node names from configs

## v1.0.0

- Initial Release
