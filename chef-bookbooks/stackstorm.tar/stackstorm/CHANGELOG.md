# stackstorm cookbook CHANGELOG

## 0.4.0

 * Update Test kitchen to CentOS 7.2
 * Drop Fedora support. Distro not officially supported by Stackstorm
 * Migrate from 'mongodb' to 'mongodb3' cookbook (mongo 2.6 to mongo 3.2)

## 0.3.2

 * Remove poise-python

## 0.3.1

 * (Identical to 0.3.0)

## 0.3.0

* Support installing via system packaginpackagingg.

## 0.2.2

 * Native repository layout support
 * Various fixes, tested on Fedora 20, Centos 70 and Ubuntu 14.04

## 0.1.0

Initial release of stackstorm cookbook
