default['nagios_v_shell']['download_url'] = 'https://github.com/NagiosEnterprises/nagiosvshell/archive/v2.0.0-416.zip'
default['nagios_v_shell']['checksum'] = '64f2a48a0dd21075d01714ecfb58fba2e79525e915cdf0523535b396848e76c6'
default['nagios_v_shell']['version'] = '2.0.0-416'
