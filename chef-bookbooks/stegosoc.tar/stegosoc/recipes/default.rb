#
# Cookbook:: stegosoc
# Recipe:: default
#
# Copyright:: 2017, Mayank Gaikwad, All Rights Reserved.
