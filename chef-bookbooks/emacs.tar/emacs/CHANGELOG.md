## v0.10.0:

* Clean up the attributes
* Use platform family for the conditional
* Default to Emacs 24 on Debian
* Update test harness

## v0.9.0:

* [COOK-2710] - use default action for package

## v0.8.4:

* [COOK-1601] - Install Emacs without X support by default on Arch
  linux

## v0.8.2:

* [COOK-551] - FreeBSD Support
* [COOK-839] - install non-X11 package by setting an attribute

## v0.7.0:

* Initial public release
