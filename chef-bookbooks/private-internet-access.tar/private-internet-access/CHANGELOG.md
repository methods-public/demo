Private Internet Access Cookbook CHANGELOG
==========================================

v1.0.0 (2015-11-28)
-------------------
- Convert HWRPs to custom resources (breaking compatibility with Chef < 12.5)
- Rename the `private_internet_access` resource to `private_internet_access_app`
- Rename the `package_url` property/attribute to `source`

v0.1.0 (2015-01-03)
-------------------
- Initial release (installation only)

v0.0.1 (2014-12-21)
-------------------
- Development started
