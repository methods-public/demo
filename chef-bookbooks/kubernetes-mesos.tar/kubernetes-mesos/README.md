Kubernetes-Mesos Cookbook
=========================
[![Cookbook](http://img.shields.io/cookbook/v/kubernetes-mesos.svg)](https://supermarket.chef.io/cookbooks/kubernetes-mesos)
[![Build Status](https://travis-ci.org/ndobson/kubernetes-mesos.svg?branch=master)](https://travis-ci.org/ndobson/kubernetes-mesos)

Cookbook to build and install Kubernetes-Mesos per the [install instructions](http://kubernetes.io/v1.0/docs/getting-started-guides/mesos.html#run-the-example-guestbook-app)

## Platform

Tested on
* CentOS 6.5, 6.6

## Attributes

## Recipes

### default

### etcd

### docker_service
Starts a basic docker service
