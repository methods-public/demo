Description
===========

Installs pngquant.

Requirements
============

## Platform:

Tested on:

* Ubuntu 14.04

Should also function on RHEL but not tested

Usage
=====


  include_recipe "pngquant"

