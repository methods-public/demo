# default decorator hash.
default['osquery']['decorators'] = {}

# Decorator query key examples:
# default['osquery']['decorators']['load'] = []
# default['osquery']['decorators']['always'] = []
# default['osquery']['decorators']['interval'] = []
