## 0.2.3 (2016-12-12)

* Action update for plex media server package

## 0.2.2 (2016-10-24)

* Refactor into LWRP

## 0.2.1: (2016-08-02)

* Ensure the plexmediaserver service is started

## 0.2.0: (2016-07-20)

* Use The Plex API to get the Download Links

## 0.1.2: (2015-11-17)

* Food critic fixes

## 0.1.1: (2015-08-20)

* Initial public version of Plex cookbook.
