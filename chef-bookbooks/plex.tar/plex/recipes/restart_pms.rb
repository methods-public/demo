plex_media_server 'pms' do
  action :restart
end
