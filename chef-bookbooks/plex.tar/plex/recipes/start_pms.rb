plex_media_server 'pms' do
  action :start
end
