plex_media_server 'pms' do
  action :stop
end
