plex_media_server 'pms' do
  action :disable
end
