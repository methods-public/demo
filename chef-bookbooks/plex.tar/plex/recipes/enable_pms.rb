plex_media_server 'pms' do
  action :enable
end
