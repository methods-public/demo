## v0.2.9
- releasever requires centos-release pkg, removing this dependency.

## v0.2.8
- type is not needed and yum resource throws an error

## v0.2.7
- updating to latest elastisearch version

## v0.2.6
- updating source_url and gems

## v0.2.5
- updating repo url

## v0.2.4
- update metadata description

## v0.2.3
- easier management of yum resource
- add managed attrib
- update README

## v0.2.2
- update README

## v0.2.1
- prefixing all repos with elasticsearch for easy sorting

## v0.2.0
- adding additional elasticsearch projects

## v0.1.0
- Initial release
