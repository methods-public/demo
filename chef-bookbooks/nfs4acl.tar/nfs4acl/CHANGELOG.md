nfs4acl Cookbook CHANGELOG
==========================

1.0.1 (2016-02-03)
------------------
- Richard Lock
- Fixed issue #2: ensures current_acl is array

1.0.0 (2016-02-03)
------------------
- Richard Lock
- Changed default resource action to :set
- Added resource action :add

0.1.1 (2015-12-16)
------------------
- Richard Lock
- Updated README

0.1.0 (2015-12-15)
------------------
- Richard Lock
- Initial release of nfs4acl
