pacemaker CHANGELOG
===================

This file is used to list changes made in each version of the pacemaker cookbook.

1.0.1
-----
- Require `shellwords` library

1.0.0
-----
- Initial release of pacemaker
