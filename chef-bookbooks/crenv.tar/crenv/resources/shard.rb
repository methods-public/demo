default_action :install

#installs a set of shards for a given user
action :install do
end

# removes one version
action :remove do
end

# similar to rvm implode command, removes crenv completely from the vm
action :destroy do
end
