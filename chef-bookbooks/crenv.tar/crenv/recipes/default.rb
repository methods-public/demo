#
# Cookbook Name:: crenv
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.
Chef::Log.warn('The default crenv recipe does nothing. See the readme for information on using the crenv resources')
