maintainer       "Łukasz Jernaś"
maintainer_email "deejay1@srem.org"
license          "Apache 2.0"
description      "Installs/Configures ircd-ratbox"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.rdoc'))
version          "0.0.2"
supports 'centos'
supports 'fedora'
supports 'rhel'
