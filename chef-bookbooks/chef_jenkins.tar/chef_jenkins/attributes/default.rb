default['chef_jenkins']['auto_create_folders'] = true
