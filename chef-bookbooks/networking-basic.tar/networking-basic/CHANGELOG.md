NETWORKING-BASIC CHANGELOG
==========================

1.0.0 (15-Aug-2017)
-------------------
- Updated cookbook dependencies.
- Added a Travis integration test harness using Docker.
- Added Rubocop linter support.

0.1.0
-----
- Initial release.  Supports Ubuntu, Debian, and RedHat flavored OSes.

