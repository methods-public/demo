## iproute2 cookbook CHANGELOG

## 0.0.1
* [**Karthik**](https://github.com/karthik-altiscale):
  Basic skeleton

## 0.0.2
* [**Karthik**](https://github.com/karthik-altiscale):
  basic ip link operations

## 0.0.3
* [**Karthik**](https://github.com/karthik-altiscale):
  network namespace capability

## 0.1.0
* [**Karthik**](https://github.com/karthik-altiscale):
  Update readme for ip-link and ip-netns

## 0.1.1
* [**Karthik**](https://github.com/karthik-altiscale):
  Action add to add and set [https://github.com/karthik-altiscale/iproute2-cookbook/issues/10](issue) 

## 0.1.2
* [**Karthik**](https://github.com/karthik-altiscale):
  update mac address
  test on all platforms 

## 0.2.0
* [**Karthik**](https://github.com/karthik-altiscale):
  all targetted `ip link` features

## 0.3.0
* [**Karthik**](https://github.com/karthik-altiscale):
  ip link can create VLANs

## 0.4.0
* [**Karthik**](https://github.com/karthik-altiscale):
  ip link can create veth pairs and associate to netns

## 0.4.1
* [**Karthik**](https://github.com/karthik-altiscale):
  apache-2 license

## 0.4.2
* [**Karthik**](https://github.com/karthik-altiscale):
  Delete action for links

## 1.0.0
* [**Karthik**](https://github.com/karthik-altiscale):
  A fully working IP Addr and IP Link (vlan, netns)

## 1.0.1
* [**Karthik**](https://github.com/karthik-altiscale):
  matchers for chefspec

## 1.0.2
* [**Karthik**](https://github.com/karthik-altiscale):
  Chef guys removed property_is_set?

## 2.0.0
* [**Karthik**](https://github.com/karthik-altiscale):
  ip route
