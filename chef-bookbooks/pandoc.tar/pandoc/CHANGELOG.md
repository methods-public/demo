## v1.0.0:

* Cookbook is stable, releasing as 1.0.0.

## v0.5.0:

* Add install method attribute for osx so pandoc can be installed by
  homebrew, too

## v0.0.1:

* Initial release

