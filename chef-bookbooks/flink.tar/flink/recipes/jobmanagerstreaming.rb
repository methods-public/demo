
node.default.flink.mode = "STREAMING"

include_recipe "flink::jobmanager"
