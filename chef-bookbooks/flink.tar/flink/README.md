Apache Flink Cookbook
==============
This chef cookbook installs Apache Flink on DataNodes/NodeManagers in an Apache YARN environment,
including both flink-config.yml and jar files. The cookbook also provides PaaS support in the
Hops Dashboard.
