node.default.java.jdk_version                         = 8
node.default.java.set_etc_environment                 = true
node.default.java.install_flavor                      = "oracle"
node.default.java.oracle.accept_oracle_download_terms = true
