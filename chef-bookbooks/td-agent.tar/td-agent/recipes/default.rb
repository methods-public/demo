#
# Cookbook Name:: td-agent
# Recipe:: default
#
# Copyright 2011, Treasure Data, Inc.
#

include_recipe 'td-agent::install'
include_recipe 'td-agent::configure'
