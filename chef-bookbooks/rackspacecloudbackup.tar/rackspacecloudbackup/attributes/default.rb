#
# Cookbook Name:: rackspacecloudbackup
# Attributes:: default
#
# Copyright 2013, David Joos
#

default[:rackspacecloudbackup][:username] = "CHANGE_ME"
default[:rackspacecloudbackup][:api_key] = "CHANGE_ME"

default[:rackspacecloudbackup][:repository_key] = "F6A5034C"