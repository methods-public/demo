sysctl.d CHANGELOG
==================

0.1.4
-----
- Lev Popov - Fixing issue with include_recipe in a LWRP cookbook

0.1.3
-----
- Lev Popov - Update description

0.1.2
-----
- Lev Popov - List supported OS

0.1.1
-----
- Lev Popov - Fix foodcritic warnings

0.1.0
-----
- Lev Popov - Initial release of sysctl.d
