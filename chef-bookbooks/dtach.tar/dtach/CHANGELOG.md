dtach Cookbook CHANGELOG
========================

v1.0.0 (2014-02-14)
-------------------
Initial release


v0.1.0 (2014-02-14)
-------------------
- Initial release
