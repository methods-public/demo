nginx-repo CHANGELOG
=====================

This file is used to list changes made in each version of the nginx-repo
cookbook.

0.1.2
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - add OS constraints
  - faster travis-ci build
  - update documentation

0.1.1
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - add '--extended-metadata' option for stove rake publish task
  - change format of CHANGELOG.md
  - fix README.md to address rendering issues in Chef Supermarket

0.1.0
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - initial release of nginx-repo
