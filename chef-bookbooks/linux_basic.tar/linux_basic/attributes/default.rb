default['basic']['download_dir'] = '/root/download'
default['basic']['security'] = 'enforcing'

default['basic']['readonly_user'] = ''
default['basic']['admin_user'] = ''
