# -*- encoding: utf-8 -*-
#
# Cookbook Name:: linux_basic
# Recipe:: sysctl
#
# Copyright 2015, http://DennyZhang.com
#
# Apache License, Version 2.0
#
################ /etc/profile.d ################################
# template "/etc/profile.d/profile_fluig.sh" do
#   source "profile_fluig.sh.erb"
#   mode '0655'
# end
##############################################################
