# CONTRIBUTING
You can follow this [link]() to find out contribution guide.

The still has to be defined, sorry
