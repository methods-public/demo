Please refer to the shared contributing doc [here](https://github.com/socrata-cookbooks/shared/blob/master/files/CONTRIBUTING.md).
