topbeat CHANGELOG
=================

This file is used to list changes made in each version of the topbeat cookbook.

0.2.0
-----

- Virender Khatri - updates to topbeat cookbook

