default[:mysql_config_bin] = '/usr/bin/mysql_config'
default[:mysql_password] = 'password'
default[:rails_version] = '2.3.14'
default[:nventory_version] = '0.86'
default[:nventory_install_dir] = '/opt'

