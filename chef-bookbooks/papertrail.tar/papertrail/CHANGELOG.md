# 1.1.0

* Add support for two new config options: `facility` and `severity`.
* Minor bug fixes

# 1.0.0

Initial release of chef-papertrail
