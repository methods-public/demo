chef-grafana Cookbook CHANGELOG
===============================

## 0.5.0 (2018-01-04)

* Add channel option to repositories allowing installation of beta versions of grafana.
* Add ability to install a specific version of grafana.

## 0.4.0 (2017-07-13)

* Remove default_dashboards recipe, which replaced the default dashboard with
  an old and broken one.

## 0.3.0 (2017-04-01)

* Add support for rhel platforms.


