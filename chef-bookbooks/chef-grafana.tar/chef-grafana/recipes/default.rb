include_recipe 'chef-grafana::install'
include_recipe 'chef-grafana::configure'
