## 1.0.4:
* Update Notepad++ version to 6.8.6

## 1.0.3:
* Update Notepad++ version to 6.1.6

## 1.0.2:
* Update Notepad++ version to 6.1.5

## 1.0.1:
* Update Notepad++ version to 6.1.2

## 1.0.0:
* Initial release
