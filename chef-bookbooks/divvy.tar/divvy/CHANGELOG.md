Divvy Cookbook CHANGELOG
========================

v1.0.0 (2016-05-31)
-------------------
- Update to custom resources, breaking compatibility with Chef < 12.5
- Update for mac-app-store cookbook 2.0

v0.2.1 (2016-02-22)
-------------------
- Fix issue failing to enable service on Windows
- Fix incorrect bundle ID for OS X App Store installs

v0.2.0 (2015-05-09)
-------------------
- Add support for non-App Store direct downloads for OS X
- Add support for Windows
- Grant required Accessibility privileges automatically on OS X
- Add a `:start` action and start Divvy after it's installed
- Add an `:enable` action to start Divvy on log-in and do it after install

v0.1.0 (2015-04-25)
-------------------
- Initial release!

v0.0.1 (2015-04-24)
-------------------
- Development started
