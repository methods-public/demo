jar_deployment CHANGELOG
========================

This file is used to list changes made in each version of the jar_deployment cookbook.

0.2.0
-----
- Robert Northard - Added java args parsing to service script.

0.1.1
-----
- Robert Northard - Added source/issues URL to cookbook metadata.

0.1.0
-----
- Robert Northard - Initial release of jar_deployment

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
