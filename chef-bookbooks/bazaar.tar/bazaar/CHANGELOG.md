bazaar Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the bazaar cookbook.

v1.0.1 (2015-02-06)
-------------------
- Typo in the README.md

v1.0.0 (2015-02-06)
-------------------
- Initial Release, basic package install and basic LWRP to do specific cloning
