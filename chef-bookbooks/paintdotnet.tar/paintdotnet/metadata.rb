name             'paintdotnet'
maintainer       'Sean Fleming'
maintainer_email 'seenya@gmail.com'
license          'MIT'
description      'Installs/Configures Paint.Net'
long_description 'Installs/Configures Paint.Net'
version          '0.3.0'

supports 		 'windows'

depends			 'windows', '1.31.0'