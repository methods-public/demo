# ilorest CHANGELOG

This file is used to list changes made in each version of the ilorest cookbook.

## 1.0.0
- [lumbajack] - Initial release of ilorest
