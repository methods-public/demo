node.default['ilorest']['iLO_IP'] = "10.0.0.100"
node.default['ilorest']['iLO_username'] = "admin"
node.default['ilorest']['iLO_password'] = "password"
