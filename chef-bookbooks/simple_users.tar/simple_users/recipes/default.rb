#
# Cookbook:: simple_users
# Recipe:: default
#
# Greg Konradt
include_recipe 'simple_users::users'
