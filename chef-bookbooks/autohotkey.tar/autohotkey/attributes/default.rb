default.autohotkey.source = 'http://ahkscript.org/download/ahk-install.exe'
default.autohotkey.checksum = 'f2c600d3467713ae433153f9b7f268c1a5f7653316abf9f9992276b808e44411'