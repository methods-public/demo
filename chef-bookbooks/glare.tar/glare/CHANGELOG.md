# glare cookbook CHANGELOG

## 1.0.6

- No changes. Uploaded using custom stove version with gem metadata.

## 1.0.5

- No changes. Uploaded using custom stove version. Do not use.

## 1.0.4

- No changes. Uploaded using custom stove version. Do not use.

## 1.0.3

- Use rake for stove
- Upload extended metadata to supermarket

## 1.0.2

- Update cookbook description

## 1.0.1

- Bump version to upload it with metadata

## 1.0.0

- Rename `add` action to `create` and `remove` to `delete`

## 0.1.1

- Add default action for record provider

## 0.1.0

- Initial release of glare cookbook with record provider
