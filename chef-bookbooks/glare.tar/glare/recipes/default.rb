chef_gem 'glare' do
  compile_time false
end
