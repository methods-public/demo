# 1.0.5
* Bug fixing.
* Serverspec tests.

# 1.0.4
* Added checks to prevent multiple executions of mount/umount while converge.
* Added support for Ubuntu 14.04

# 1.0.3
Chef cookbook to install PXE network booting server. 
* Small fixes
* Added support of CentOS 6.5 and Ubuntu 12.04

# 1.0.0
* Initial release of pxe.
