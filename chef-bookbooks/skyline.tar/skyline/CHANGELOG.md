## 0.3.0

* Add unittest2 and mock to default pip packages (from Skyline requirements.txt)

## 0.2.0

* Add `node['skyline']['horizon']['horizon_ip']` attribute

## 0.1.5

* Add default packages for install, starting with netcat which is used by skyline source code

## 0.1.4

* Set redis logfile attribute if redis source install and left defaulted to "stdout"

## 0.1.3

* Always create redis log directory for redis source installs

## 0.1.2

* Use "redis" as instance name in init script for redis source installs

## 0.1.1

* Additional platforms for source installation in redis recipe (fixes FC024 as well)

## 0.1.0

* Initial release
