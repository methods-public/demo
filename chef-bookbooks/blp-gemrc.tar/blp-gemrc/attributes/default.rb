#
# Cookbook: blp-gemrc
# License: Apache 2.0
#
# Copyright 2013, OptimisCorp, Inc.
# Copyright 2014-2017, Bloomberg Finance L.P.
#

default['gemrc']['config']['gem'] = '--no-ri --no-rdoc'
