ssh_authorized_keys_test CHANGELOG
==================================

This file is used to list changes made in each version of the ssh_authorized_keys_test cookbook.

0.1.0
-----
- [your_name] - Initial release of ssh_authorized_keys_test

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
