This cookbook is used with [test-kitchen](http://kitchen.ci/) to test the parent, [ssh_authorized_keys](https://supermarket.chef.io/cookbooks/ssh_authorized_keys) cookbook.
