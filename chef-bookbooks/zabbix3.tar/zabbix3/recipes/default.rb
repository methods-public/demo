#
# Cookbook Name:: zabbix3
# Recipe:: default
#
# Copyright (c) 2016 Robert Ressl, GPL v3.
