Sinopia Cookbook CHANGELOG
==========================

0.3.2
-------------------
- Adding changelog file
- Adding EL6/EL7 support
- Adding systemd support for debian platform
- fixing ACL in config file
