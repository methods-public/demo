# encoding: utf-8
#
# Cookbook Name:: sinopia
# Recipe:: nodejs
#

include_recipe 'nodejs'
