# schannel Cookbook CHANGELOG

This file is used to list changes made in each version of the schannel cookbook.

## v1.0.1  (2017-04-12)
- Add info to README. 

## v1.0.0  (2017-04-10)
- Initial release of schannel cookbook. 