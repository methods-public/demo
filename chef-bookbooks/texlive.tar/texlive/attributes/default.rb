default['texlive']['dvd_url'] = "http://ftp.jaist.ac.jp/pub/CTAN/systems/texlive/Images/texlive2014-20140525.iso"
default['texlive']['timeout'] = 1800  # 30min
