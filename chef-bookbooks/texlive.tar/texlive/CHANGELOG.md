## 0.2.1:

* Update ISO image to texlive2014-20140525.iso

## 0.2.0:

* Add configuration: node['texlive']['timeout']

## 0.1.0:

* Initial release of texlive
