default['nrpe_configuration']['install_directory'] = 'C:/Program Files/NSClient++/'
default['nrpe_configuration']['notify_service'] = false
default['nrpe_configuration']['settings'] = []