qpdf Cookbook CHANGELOG
=======================

v1.1.0 (2014-05-14)
-------------------

* Use package manager to resolve runtime lib dependency.
* Remove chef-sugar as it is no longer used.


v1.0.0 (2014-05-14)
-------------------

* Initial release
