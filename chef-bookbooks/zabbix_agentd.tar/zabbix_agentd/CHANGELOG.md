# zabbix_agentd Cookbook CHANGELOG

This file is used to list changes made in each version of the Zabbix Agent cookbook.

## v0.1.0

- Initial release.
- Support only RHEL 7.
