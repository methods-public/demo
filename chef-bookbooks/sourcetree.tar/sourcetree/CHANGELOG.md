# SourceTree Cookbook CHANGELOG

This file is used to list changes made in each version of the SourceTree cookbook.

## 1.1.0 (2017-5-29)
- Bump SourceTree version to 2.0.20.1
- Add license to source code and change to standardized license name
- Add AppVeyor CI testing
- Add chef_version constraint
- Move InSpec test location

## 1.0.1 (2017-1-2)
- Add recipes to README
- Fix grammar in metadata.rb

## 1.0.0 (2016-12-27)
- Initial release
