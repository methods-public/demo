# katello cookbook CHANGELOG
This file is used to list changes made in each version of the katello cookbook.

## v0.1.0 (2014-03-31)
- Initial release of katello
