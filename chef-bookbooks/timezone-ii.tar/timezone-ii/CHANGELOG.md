# CHANGELOG for timezone-ii

This file is used to list changes made in each version of timezone-ii.

## 0.2.0:

* Initial release of timezone-ii (as forked from timezone)
* Added support for Fedora
* Configurable paths for localtime data and tzdata tree (just in case someone
  wants them...)
* For generic Linux timezone setting, a choice of copying or symlinking timezone
  data to localtime (copying is the default, to avoid surprises)

