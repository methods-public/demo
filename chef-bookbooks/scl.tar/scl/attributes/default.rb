# Default the gcc/g++ toolset only
default['scl']['packages'] = %w(devtoolset-3-gcc-c++)
