# Changelog of the updatable-attributes cookbook

This file is used to list changes made in each version of the updatable-attributes cookbook.

## Version 0.0.2
- Fix calling syntax
- Describe the syntax in the README.md

## Version 0.0.1
- Initial implementation

## Version 0.0.0
- Initial commit
