# Changelog

## 0.1.1 (2017-10-17)

### New features

- Added `gcompute_address_ip` client function.

## 0.1.0 (2017-10-04)

Initial release
