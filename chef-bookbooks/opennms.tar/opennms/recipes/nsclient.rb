# frozen_string_literal: true
node.default['opennms']['plugin']['nsclient'] = true
