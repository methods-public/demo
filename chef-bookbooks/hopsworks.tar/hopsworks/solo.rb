file_cache_path "/tmp/chef"
cookbook_path "/tmp/cookbooks"
