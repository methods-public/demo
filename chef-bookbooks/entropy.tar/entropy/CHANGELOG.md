# 1.0.0

Initial release of the `entropy` cookbook
