# alphard-chef-awscli CHANGELOG

This file is used to list changes made in each version of the alphard-chef-awscli cookbook.

## 1.0.1
- [Frédéric Nowak] - Fix README.md, add TESTING.md and CONTRIBUTING.md for supermarket quality metrics.

## 1.0.0
- [Frédéric Nowak] - Initial release of alphard-chef-awscli

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
