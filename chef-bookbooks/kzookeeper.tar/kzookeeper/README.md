Description
===========

Installs and configures a zookeeper service.

Requirements
============
Chef 0.11+.

Platform
--------
* Ubuntu, centos


Tested on:
* Ubuntu 14.04, 16.04
* centos 7.0+
