## v0.8.0:

* [COOK-1996] - Add "source" recipe to build and install from the
  savannah git repositor

## v0.7.1:

* Current public release.
