# Winrm Changelog

## 2.0.0 (2017-10-19)
- * BREAKING CHANGE, attributes no longer exist
- Convert to custom resource
- Update to work with newer chef versions

## 1.0.2
- Added configurable Everyone group attribute

## 1.0.1 (10-16-2015)
- Added Kitchen CI config
- Added rubocop config
- Added Berksfile
- Added gitignore and chefignore filex
- Moved Gemfile and add standard development dependencies
- Fixed the license in the metadata to be Apache 2.0
- Added modern Ruby releases to Travis and add rubocop and chefspec testing
- Added retina badges to the readme and added the cookbook version badge


## 1.0.0 (02-14-2014):
- Initial release of the WinRM cookbook
- Adding support for Travis-CI and foodcritic
