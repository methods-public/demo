`modcloth-nad` cookbook
=======================

[![Build Status](https://travis-ci.org/modcloth-cookbooks/modcloth-nad.png?branch=master)](https://travis-ci.org/modcloth-cookbooks/modcloth-nad)

Description
===========
Use this cookbook to install the Node Agent Daemon (nad) on your system.
nad acts as an extensible agent to report data back to Circonus.


Requirements
============
We currently support SmartOS, Ubuntu, and CentOS.  This cookbook depends
on the `git` cookbook and sugggests `build-essential` and `nodejs`
cookbooks.


Related work
============
See also: https://github.com/omniti-labs/nad-cookbook
