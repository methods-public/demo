Authors of `nad`
==============

 - Blake Irvin
 - Dan Buch
 - Eric Saxby
 - Paul Henry
 - Seth Kingry
 - Stephen Lauck
