Contributing to `nad`
===================

Pull requests accepted.  Don't forget to add yourself to the
`AUTHORS.md` file alphabetically by first name.
