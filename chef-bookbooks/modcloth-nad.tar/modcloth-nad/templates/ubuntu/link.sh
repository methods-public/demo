#!/bin/bash

IN=`ifconfig eth0 | awk '/RX bytes/ {print $2}' | awk -F: '{print $2}'`
OUT=`ifconfig eth0 | awk '/RX bytes/ {print $6}' | awk -F: '{print $2}'`

PREFIX="unix:0:link:"

echo -e "${PREFIX}in\tn\t${IN}"
echo -e "${PREFIX}out\tn\t${OUT}"

