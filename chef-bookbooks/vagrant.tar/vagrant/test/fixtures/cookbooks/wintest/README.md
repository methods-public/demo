# test

This cookbook is used for testing the `vagrant` cookbook.

