# icinga2_core

Install icinga2 core. This is needed for the the client and the server.

## Usage:

```ruby
include_recipe 'icinga2_core'
```
