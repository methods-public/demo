TODO
====

* [x] Fix RuboCop offenses.
 * [x] Add rubocop.yml.
* [x] Update to ChefSpec `4.1`.
* [x] Integrate with `should_not`.
* [x] Use Berksfile template.
* [x] Add Guardfile.
* [x] Homogenize license headers.
* [x] README: Use markdown tables.
* [x] README: Use single quotes in examples.
* [ ] Add more unit tests for the libraries.
* [ ] Support to install from sources.
