iis-packages-server CHANGELOG
=========================

This file is used to list changes made in each version of orchestration-server cookbook.

0.0.1
-----
- Steve Dillon - Initial release of iis-packages-server

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
