# valid options: deadline, noop, cfq, anticipatory
default['kvm']['guest']['tuning']['io_scheduler'] = 'noop'
