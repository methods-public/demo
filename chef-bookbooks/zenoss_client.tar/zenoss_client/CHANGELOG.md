# Zenoss Client Cookbook Change Log

## v1.1.2 (Nov 15, 2013)
  * [#2](https://github.com/ZCA/zenoss_client-chef-cookbook/issues/2) - 
    Fix issued with default lwrp attribute values under Chef 10.x
  * [#3](https://github.com/ZCA/zenoss_client-chef-cookbook/issues/3) -
    Allow for setting pubkey via node attribute

## v1.1.0 (Jul 12, 2013)
  * Added new LWRP for registering devices
  * Switched to new Bento bucket location

## v1.0.0 (Jun 29, 2013)
  * Initial release of cookbook split from the original Zenoss cookbook