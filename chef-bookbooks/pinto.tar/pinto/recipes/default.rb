include_recipe 'pinto::application'
include_recipe 'pinto::server'

