default['java']['jdk_version'] = '8'

default['postfix']['main']['relayhost'] = 'smtp.example.com'

default['zammad']['local_mta'] = true
default['zammad']['local_es'] = true
default['zammad']['use_proxy'] = false

default['zammad']['nginx_server_name'] = 'localhost'
