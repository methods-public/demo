vs-2008 CHANGELOG
===================

This file is used to list changes made in each version of the vs-2008 cookbook.

1.1.0
-----
- y.siu - Add a prerequisites check for .Net Framework 3.5 with a registry look up.

1.0.0
-----
- y.siu - Initial release of vs-2008

- - -
