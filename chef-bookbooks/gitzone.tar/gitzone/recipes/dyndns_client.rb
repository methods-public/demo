
#configure dyndns client
