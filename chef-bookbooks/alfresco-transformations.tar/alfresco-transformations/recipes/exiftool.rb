package 'perl-Image-ExifTool' do
  action :install
end
