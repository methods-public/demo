describe user('proxysql') do
  it { should exist }
end

describe group('proxysql') do
  it { should exist }
end
