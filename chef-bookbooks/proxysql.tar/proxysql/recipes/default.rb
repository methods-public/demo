# Uses default node['proxysql'] attributes
proxysql_service 'default instance' do
end
