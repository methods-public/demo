## v0.2.1
- Pierre-Luc - add name into metadata.md for Chef v12 support.

## v0.2.0
- Pierre-Luc - license and Readme update

## v0.1.4
- Pierre-Luc - fix installation of package for Chefv11 co-nfs::default

## v0.1.3
- Matthieu - CLient recipes chef 11 compatibility

## v0.1.2
- Matthieu - HA NFS Server recipe co-nfs::server_ha

## v0.1.1
- Matthieu - shares recipes to manage nfs mount point on a client

## v0.1.0 
- Initial version
