summary-handlers CHANGELOG
==========================

This file is used to list changes made in each version of the summary-handlers cookbook.

0.3.0
-----
- [Chris Sullivan] - Updated due to https://blog.chef.io/2017/04/19/find-better-cookbooks-supermarket/
  Added a sub cookbooks for test / example output.

0.2.6
-----
- [Chris Sullivan] - Applied Rubocop rules to code

0.2.6
-----
- [Chris Sullivan] - Re-added unit tests

0.2.5
-----
- [Chris Sullivan] - Fix FC064 and FC065

0.2.4
-----
- [Chris Sullivan] - Remove Berksfile.lock

0.2.3
-----
- [Chris Sullivan] - Added updated only option for resource summary, refactored

0.2.2
-----
- [Chris Sullivan] - Cookbook report and refactoring of Recipe Summary

0.2.1
-----
- [Chris Sullivan] - Slight change in format of reports

0.2.0
-----
- [Chris Sullivan] - Simplify code and change format of reports

0.1.0
-----
- [Chris Sullivan] - Initial release of summary-handlers

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
