default['summary-handlers']['cookbook-summary-report'] = true
default['summary-handlers']['recipe-summary-report'] = true
default['summary-handlers']['resource-summary-report'] = true
