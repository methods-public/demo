Zeyple CHANGELOG
================

## v1.2.1
- Update cookbook for Zeyple 1.2.1

## v1.1.0
- Update checksum for Zeyple 1.1.0

## v1.0.0
- Initial release
