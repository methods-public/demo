icinga2repo CHANGELOG
==================

1.0.0
-----

- Virender Khatri - first commit
