# Contributors

(in no particular order)

- hoatle
- hieptranquoc

see:

- https://github.com/teracyhq-incubator/kubernetes-stack-cookbook/graphs/contributors
