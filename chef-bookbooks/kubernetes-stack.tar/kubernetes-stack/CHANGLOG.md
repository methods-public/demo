# Change Log



## [v0.1.1][] (2017-08-26)

A bug fix for README content formatter on the Chef Supermarket.


## [v0.1.0][] (2017-08-26)


The first milestone release includes:

- initial project setup
- add support for `kubectl`, `helm`, `gcloud` resources
- add autocomplete support
- unit tests, integration tests
- travis-ci build


[v0.1.0]: https://github.com/teracyhq-incubator/kubernetes-stack-cookbook/milestone/1?closed=1
[v0.1.1]: https://github.com/teracyhq-incubator/kubernetes-stack-cookbook/milestone/3?closed=1
