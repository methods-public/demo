helm 'uninstall helm' do
  action :remove
end
