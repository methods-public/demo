kubectl 'uninstall kubectl' do
  action :remove
end
