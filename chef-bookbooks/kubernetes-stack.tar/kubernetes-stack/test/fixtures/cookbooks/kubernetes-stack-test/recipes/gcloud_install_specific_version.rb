gcloud 'install specific gcloud version' do
  version '158.0.0'
end
