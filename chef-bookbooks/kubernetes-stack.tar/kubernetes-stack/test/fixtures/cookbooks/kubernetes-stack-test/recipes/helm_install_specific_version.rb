helm 'install specific helm version' do
  version 'v2.4.2'
end
