kubectl 'install default kubectl'
