kubectl 'install specific kubectl version' do
  version 'v1.7.0'
end
