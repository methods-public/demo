gcloud 'uninstall gcloud' do
  action :remove
end
