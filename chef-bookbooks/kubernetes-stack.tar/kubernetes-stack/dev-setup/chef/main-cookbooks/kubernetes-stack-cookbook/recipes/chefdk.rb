chef_dk 'latest chefdk' do
  global_shell_init true
  action :install
end
