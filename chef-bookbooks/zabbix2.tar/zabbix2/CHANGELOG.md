zabbix2 CHANGELOG
===================

This file is used to list changes made in each version of the zabbix2 cookbook.

0.1.2 (2015-07-29)
------------------
- Fixed a typo in the README file
- Added Source URL to the metadata file

0.1.1 (2015-07-29)
------------------
- Fixed the README file

0.1.0 (2015-07-26)
------------------
- Initial release of zabbix2

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
