Description
===========
Installs bitly gem and Chef library to provide easy bitly link shortening in recipes via Bit:short()

Requirements
============

Rubygems; works on linux and windows!

Attributes
==========

Tune to set temp and location of your encrypted data bag secret, the name of your encrypted data bag for bitly application key setting and the name of your bitly account.

Usage
=====

Check out full functioned example.rb for details by adding "bitly" and "bitly::example" to the run list.