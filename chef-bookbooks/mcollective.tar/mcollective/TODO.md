
* Push relevant chef-client/solo config into chef agent config
* Provide attribute to install additional mcollective agent packages
* Recipe to configure ssl security plugin (using chef public keys)
* Attribute to configure rpcaudit plugin
* Actionpolicy configuration?
