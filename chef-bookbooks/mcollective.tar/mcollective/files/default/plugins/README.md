This directory contains mcollective plugins to distribute to your nodes.
