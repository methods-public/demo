# Attributes for configuring the Redis connector plugin

default['mcollective']['redis']['hostname'] = "localhost"
default['mcollective']['redis']['port'] = "6379"
default['mcollective']['redis']['db'] = "1"

