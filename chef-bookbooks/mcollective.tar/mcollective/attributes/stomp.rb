# STOMP server details (used by stomp, rabbitmq and activemq connectors)
default['mcollective']['stomp']['hostname'] = "localhost"
default['mcollective']['stomp']['port'] = "6163"
default['mcollective']['stomp']['username'] = "mcollective"
default['mcollective']['stomp']['password'] = "marionette"
default['mcollective']['stomp']['client_username'] = nil
default['mcollective']['stomp']['client_password'] = nil
