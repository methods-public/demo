#
# Cookbook: yum-jenkins
# License: Apache 2.0
#
# Copyright 2016, Bloomberg Finance L.P.
#
default['yum-jenkins']['repositories'] = %w{jenkins}
