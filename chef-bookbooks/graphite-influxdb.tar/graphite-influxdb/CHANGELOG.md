# 0.1.0

Initial release of chef-graphite-influxdb
