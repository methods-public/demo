# Chef Webinar #1

Setup the infrastructure to run the sample application

For complete details visit [Chef Webinar #1 - Getting Started][webinar1-site].


[webinar1-site]: https://github.com/nelsonjr/chef-webinars/tree/master/getting-started
