default['air']['download_url'] = 'http://airdownload.adobe.com/air/win/download'
default['air']['version'] = '20.0'

default['air']['update_disabled'] = false

default['air']['path'] = nil
default['air']['pingback_allowed'] = true
default['air']['location'] = nil
default['air']['desktop_shortcut'] = true
default['air']['program_menu'] = true
