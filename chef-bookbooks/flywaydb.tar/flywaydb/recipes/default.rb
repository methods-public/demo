flywaydb 'install flywaydb' do
  action :install
end
