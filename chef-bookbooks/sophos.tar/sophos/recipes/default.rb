# Copyright 2016 Sophos Technology GmbH. All rights reserved.
# See the LICENSE.txt file for details.
# Authors: Vincent Landgraf

chef_gem 'sophos-sg-rest' do
  compile_time true
end
