#
# Cookbook Name:: phpcs
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpcs']['install_method'] = 'composer'
default['phpcs']['version'] = 'latest'
default['phpcs']['install_dir'] = '/usr/local/phpcs'
