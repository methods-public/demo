#
# Cookbook Name:: phpcs
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpcs']['prefix'] = '/usr/bin'
