#
# Cookbook Name:: phpcs
# Attributes:: coding_standard
#
# Copyright (c) 2016, David Joos
#

default['phpcs']['coding_standards'] = {}
