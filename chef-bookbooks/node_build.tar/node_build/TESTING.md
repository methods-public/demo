# Testing

- [Test Kitchen](https://kitchen.ci/docs/getting-started/running-test): `kitchen test`
- [ChefSpec](https://docs.chef.io/chefspec.html): `chef exec rspec`
