# Inspec test for recipe chrony_ii::default

# The Inspec reference, with examples and extensive documentation, can be
# found at http://inspec.io/docs/reference/resources/

# Nothing
