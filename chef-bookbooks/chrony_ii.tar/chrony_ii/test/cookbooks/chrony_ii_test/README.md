# chrony_ii_test

Support cookbook for testing `chrony_ii`
