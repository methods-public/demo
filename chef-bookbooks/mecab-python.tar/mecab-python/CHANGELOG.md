mecab-python Chef cookbook CHANGELOG
========================

0.1.0 / 2015-02-19
-----
- The initial release.
