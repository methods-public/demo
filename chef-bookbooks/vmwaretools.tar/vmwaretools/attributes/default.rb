# The location to get the Windows VMware-Tools executable from.
default['vmware-tools']['url'] = "https://packages.vmware.com/tools/esx/latest/windows/x64"
# The version of the Windows VMware-Tools.
default['vmware-tools']['version'] = "10.1.15-6677369"
