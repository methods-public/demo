name 'blog-ovh'
maintainer 'The Authors'
maintainer_email 'nmyster@gmail.com'
license 'all_rights'
description 'Installs/Configures blog-ovh'
long_description 'Installs/Configures blog-ovh'
version '0.1.9'

supports 'centos'

issues_url "https://chef.njsnet.co"
source_url "https://chef.njsnet.co"