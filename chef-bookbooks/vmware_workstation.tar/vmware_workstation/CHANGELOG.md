# CHANGELOG for vmware_workstation

This file is used to list changes made in each version of vmware_workstation.

## 0.2.0:
Bad Supermarket upload created 0.1.0.  Pushing 0.2.0 to fix upload.

## 0.0.2:
Updated travis to run more rake tests (foodcritic, tailor).

## 0.0.1:
Initial version.
- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
