## 0.3.6 / 2013-06-12
Fix the bug with non-present FQDN.

## 0.3.5 / 2013-06-12
Update the name to use underscore (to fix potential Chef resource naming problem).

## 0.3.4 / 2013-06-11
Change to using the `hostsfile` cookbook.

## 0.3.3 / 2013-06-11
Initial public release with test-kitchen integration.
