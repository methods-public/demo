[![Cookbook Version](https://img.shields.io/cookbook/v/alphard-chef-deploy.svg)](https://supermarket.chef.io/cookbooks/alphard-chef-deploy)
[![License](https://img.shields.io/badge/License-Apache%202.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Build Status](https://travis-ci.org/hydra-technologies/alphard-chef-deploy.svg?branch=master)](https://travis-ci.org/hydra-technologies/alphard-chef-deploy)
[![Coverage Status](https://coveralls.io/repos/github/hydra-technologies/alphard-chef-deploy/badge.svg?branch=master)](https://coveralls.io/github/hydra-technologies/alphard-chef-deploy?branch=master)

# Cookbook 'alphard-chef-deploy'

TODO: Enter the cookbook description here.

e.g.
This cookbook makes your favorite breakfast sandwich.

## Requirements

TODO: List your cookbook requirements. Be sure to include any requirements this cookbook has on platforms, libraries, other cookbooks, packages, operating systems, etc.

e.g.
### Platforms

- SandwichOS

### Chef

- Chef 12.0 or later

### Cookbooks

- `toaster` - alphard-chef-deploy needs toaster to brown your bagel.

## Attributes

TODO: List your cookbook attributes here.

e.g.
### alphard-chef-deploy::default

- `['"alphard-chef-deploy"']['attribute_1']` - comment for attribute 1
- `['"alphard-chef-deploy"']['attribute_2']` - comment for attribute 2
- `['"alphard-chef-deploy"']['attribute_3']` - comment for attribute 3
- `['"alphard-chef-deploy"']['attribute_4']` - comment for attribute 4

## Usage

### alphard-chef-deploy::default

TODO: Write usage instructions for each cookbook.

e.g.
Just include `alphard-chef-deploy` in your node's `run_list`:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[alphard-chef-deploy]"
  ]
}
```

## Contributing

1. Fork the repository on Github
2. Create a named feature branch (like `add_component_x`)
3. Write your change
4. Write tests for your change (if applicable)
5. Run the tests, ensuring they all pass
6. Submit a Pull Request using Github

## License

Copyright 2009-2016, Hydra Technologies, Inc

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

## Authors

- John Doe - john@doe.com
