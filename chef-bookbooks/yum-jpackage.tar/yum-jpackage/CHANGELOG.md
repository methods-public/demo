# 0.1.0

Initial release of yum-jpackage

* Enhancements
  * Add repo jpackage for RHEL familys

# 0.1.1

Second release of yum-jpackage

* fixes
  * Correct foodcritics errors 

