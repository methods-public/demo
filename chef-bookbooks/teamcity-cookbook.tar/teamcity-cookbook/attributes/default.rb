default['teamcity']['version'] = '9.0.4'
default['teamcity']['service-name'] = 'teamcity-server'
default['teamcity']['service-group'] = 'teamcity'
default['teamcity']['service-username'] = 'teamcity'
default['teamcity']['accept-license'] = true
default['teamcity']['admin-username'] = 'teamcity'
default['teamcity']['admin-password'] = 'teamcity'
