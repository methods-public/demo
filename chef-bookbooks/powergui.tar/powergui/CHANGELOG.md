## 1.0.1:
* Rubocop fixes
* Foodcritic fixes

## 1.0.0:
* Initial release
