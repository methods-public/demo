Description
===========

This cookbook installs PowerGUI 3.2.0 for Windows

Requirements
============

Platform
--------

* Windows Vista
* Windows 7
* Windows Server 2008 (R1, R2)
* Windows 2003 (R1 / R2)
* Windows XP


Attributes
==========

Usage
=====

Include the default recipe on a node's runlist to ensure that PowerGUI is installed


