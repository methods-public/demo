default['minio']['volume_path'] = '/data'
default['minio']['volumes'] = ['/data']
default['minio']['opts'] = '--address :9000'
default['minio']['access_key'] = nil
default['minio']['secret_key'] = nil
