# CHANGELOG

## 0.1.1 (2018-05-06)

IMPROVEMENTS:

* Include systemd unit file in the cookbook (Takaaki Furukawa)

## 0.1.0 (2018-05-02)

* Initial release (Takaaki Furukawa)

