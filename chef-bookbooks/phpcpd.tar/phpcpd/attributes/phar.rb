#
# Cookbook Name:: phpcpd
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpcpd']['phar_url'] = 'https://phar.phpunit.de/phpcpd.phar'
default['phpcpd']['install_dir'] = '/usr/bin'
