#
# Cookbook Name:: phpcpd
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpcpd']['prefix'] = '/usr/bin'
