#
# Cookbook Name:: phpcpd
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpcpd']['install_method'] = 'composer'
default['phpcpd']['version'] = 'latest'
