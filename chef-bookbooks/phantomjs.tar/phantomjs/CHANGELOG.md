phantomjs CHANGELOG

v1.0.3
------
- Update default PhantomJS version to 1.9.2 [@TheDude05](https://github.com/TheDude05)

===================
v1.0.1
------
- **CHANGELOG is deprecated - see [releases](https://github.com/customink-webops/phantomjs/releases)**

v1.0.0
------
- Added support for Windows
- Added tests and refactored code

v0.0.6
-------
- Initial CHANGELOG created
