# oracle_client CHANGELOG

This file is used to list changes made in each version of the oracle_client cookbook.

## 0.1.0
- [your_name] - Initial release of oracle_client

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
