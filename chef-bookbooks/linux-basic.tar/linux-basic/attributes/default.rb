default['basic']['download_dir'] = '/root/download' # TODO: what default value should be better
default['basic']['security'] = 'enforcing'

#default['basic']['epel_release_url'] = 'https://dl.fedoraproject.org/pub/epel/6/x86_64/epel-release-6-8.noarch.rpm'

default['basic']['readonly_user'] = ''
default['basic']['admin_user'] = ''
