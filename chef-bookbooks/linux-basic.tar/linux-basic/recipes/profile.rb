#
# Cookbook Name:: linux-basic
# Recipe:: sysctl
#
# Copyright 2015, http://DennyZhang.com
#
# All rights reserved - Do Not Redistribute
#
################ /etc/profile.d ################################
# template "/etc/profile.d/profile_fluig.sh" do
#   source "profile_fluig.sh.erb"
#   mode '0655'
# end
##############################################################
