v2.1.0

* [#7](https://github.com/RiotGames/scala-cookbook/pull/8) Upgrading to Scala 2.11.1

v2.0.0

* [#7](https://github.com/RiotGames/scala-cookbook/pull/7) Upgrading to Scala 2.11.0

v1.1.0

* [#6](https://github.com/RiotGames/scala-cookbook/pull/6) Upgrading to Scala 2.10.4

v1.0.0

* [#5](https://github.com/RiotGames/scala-cookbook/pull/5) Upgrading to Scala 2.10.3
