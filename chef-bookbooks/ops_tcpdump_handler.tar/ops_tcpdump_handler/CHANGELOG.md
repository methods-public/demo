Change Log
==========

[1.0.0 - 01-24-2016](https://github.com/cerner/ops_tcpdump_handler/issues?milestone=1&state=closed)
--------------------------------------------------------------------------------------------

  * [Bug] [Issue-1](https://github.com/cerner/ops_tcpdump_handler/issues/1) : Lock down version of runit cookbook

