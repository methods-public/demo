# develop

# 0.2.0
  * Fixed readme
  * Depend on v1.0 of FreeSWITCH cookbook

# 0.1.0
  * First release
