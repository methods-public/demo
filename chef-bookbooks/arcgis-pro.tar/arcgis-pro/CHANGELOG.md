arcgis-pro cookbook CHANGELOG
================

This file is used to list changes made in each version of the arcgis-pro cookbook.

3.2.0
-----
- Added support for ArcGIS Pro 2.1.

3.1.0
-----
- Added support for ArcGIS Pro 2.0.

3.0.0
-----
- Added support for ArcGIS Pro 1.4.

2.3.1
-----
- Added support for ArcGIS Pro 1.3.

2.3.0
-----
- This version supports ArcGIS Pro 1.1, 1.2, and 1.3 Beta.
- Split from 'arcgis' cookbook.