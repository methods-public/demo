default['kickstart']['rootpw'] = nil
default['kickstart']['virtual_host_name'] = "build.#{domain}"
default['kickstart']['mirror_url'] = 'http://mirrors.kernel.org/centos/5.5/os/x86_64'
