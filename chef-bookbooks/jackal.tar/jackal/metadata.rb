name 'jackal'
version '0.1.6'
maintainer 'Chris Roberts'
maintainer_email 'chris@hw-ops.com'
license 'Apache 2.0'
description 'Run your jackals'

supports 'ubuntu'
supports 'centos'

depends 'build-essential'
depends 'runit'
