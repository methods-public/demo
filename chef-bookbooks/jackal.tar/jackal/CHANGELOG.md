# v0.1.6
* Allow exec name to be configurable

# v0.1.4
* Wrap app enable flags in block resource to prevent restart on first run setup

# v0.1.2
* Configure process using directory not single file

# v0.1.0
* Initial release
