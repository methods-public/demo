#
# Cookbook Name:: br-ruby
# Recipe:: default
#

include_recipe 'br-ruby::install'
include_recipe 'br-ruby::clean'
