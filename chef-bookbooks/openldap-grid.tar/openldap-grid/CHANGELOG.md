# CHANGELOG for openldap-grid

0.2.5
-----
- refactoring.

0.2.4
-----
- bug fix: key access group modification.
- updates documents.

0.2.3
-----
- adds Samba schema setup feature.

0.2.2
-----
- refactoring.
- updates the `ssl_cert` cookbook dependency.

0.2.1
-----
- Cleanup for FoodCritic and RuboCop.

0.2.0
-----
- rename cookbook.

# CHANGELOG for openldap

0.1.2
-----
- adds the `['openldap']['server']['ldaps']` attribute.
- adds `['openldap']['server']['KRB5_KTNAME']` attribute.

0.1.1
-----
- adds the `server` recipe.
- adds linkage with `ssl_cert` cookbook.

0.1.0
-----
- Initial release of openldap

