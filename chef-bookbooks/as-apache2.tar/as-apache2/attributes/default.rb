
default['httpd']['DocumentRoot'] = '/var/www/html'

default['httpd']['Alias'] = [
    # {:name => '/ts/', :source => '/var/www/html/sub/'}
]
