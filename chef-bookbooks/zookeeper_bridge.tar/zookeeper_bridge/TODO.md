TODO
====

* [ ] Add `zookeeper_bridge_attrs#key` property removed in [6ea5fca](https://github.com/zuazo/zookeeper_bridge-cookbook/commit/6ea5fcaf2d492599b87680f8ee714ebaf1cc388b).
* [ ] Improve the `zookeeper_bridge_wait#event` and `zookeeper_bridge_wait#status` parameters. They are a bit confusing.
* [ ] Add unit tests for libraries.
* [ ] Add better integration tests (not a tricky *test* cookbook).
* [ ] Avoid installing `chef-handler-zookeeper` inside `::depends` if not used.
