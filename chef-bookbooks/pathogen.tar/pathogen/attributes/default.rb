default['pathogen']['install_path'] = File.join('/root', '.vim')

default['pathogen']['vimrc_path'] = File.join('/root', '.vimrc')
