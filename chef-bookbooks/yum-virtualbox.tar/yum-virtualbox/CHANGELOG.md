## v0.1.2
- removing yum dependency

## v0.1.1
- releasever requires centos-release pkg, removing this dependency.

## v0.1.0
- initial release
