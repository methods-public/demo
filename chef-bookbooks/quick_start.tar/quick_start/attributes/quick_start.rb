deep_thought "If a tree falls in the forest..."
