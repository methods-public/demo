windows_rdp CHANGELOG
=====================

This file is used to list changes made in each version of the windows_rdp cookbook.

0.1.1
-----
- jrnker - Fixing foodcritic stuff
         - Changed default value of 'configure' to true

0.1.0
-----
- jrnker - Initial release of windows_rdp

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
