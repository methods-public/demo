yum_utils CHANGELOG
===================

0.2.0
-----
- adds the `yum_utils::yum-epel` recipe.

0.1.0
-----
- Initial release of yum_utils
