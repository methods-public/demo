Team and repository tags
========================

[![Team and repository tags](http://governance.openstack.org/badges/cookbook-openstack-ops-messaging.svg)](http://governance.openstack.org/reference/tags/index.html)

<!-- Change things from this point on -->

![Chef OpenStack Logo](https://www.openstack.org/themes/openstack/images/project-mascots/Chef%20OpenStack/OpenStack_Project_Chef_horizontal.png)

# Description #

This cookbook provides shared message queue configuration for the OpenStack deployment provided by Chef for OpenStack. The [OpenStack chef-repo](http://github.com/openstack/openstack-chef-repo) contains documentation for using this cookbook in the context of a full OpenStack deployment. It currently supports RabbitMQ and will soon other queues.

# Requirements #

Chef 12 with Ruby 2.1.x required.

# Platforms #

* Ubuntu-14.04

# Cookbooks #

The following cookbooks are dependencies:

* openstack-common
* rabbitmq

# Usage #

The usage of this cookbook is optional, you may choose to set up your own messaging service without using this cookbook. If you choose to do so, you will need to provide all of the attributes listed under the [Attributes](#attributes).

# Resources/Providers #

None

# Templates #

None

# Recipes #

## server ##

- message queue server configuration, selected by attributes

## rabbitmq-server ##

- configures the RabbitMQ server for OpenStack

# Attributes #

* `openstack["mq"]["cluster"]` - whether or not to cluster rabbit, defaults to 'false'

The following attributes are defined in attributes/messaging.rb of the common cookbook, but are documented here due to their relevance:

* `openstack["endpoints"]["mq"]["host"]` - The IP address to bind the rabbit service to
* `openstack["endpoints"]["mq"]["scheme"]` - Unused at this time
* `openstack["endpoints"]["mq"]["port"]` - The port to bind the rabbit service to
* `openstack["endpoints"]["mq"]["path"]` - Unused at this time
* `openstack["endpoints"]["mq"]["bind_interface"]` - The interface name to bind the rabbit service to
* `openstack["mq"]["rabbitmq"]["use_ssl"]` - Enables/disables SSL for RabbitMQ, the default is false.

If the value of the "bind_interface" attribute is non-nil, then the rabbit service will be bound to the first IP address on that interface.  If the value of the "bind_interface" attribute is nil, then the rabbit service will be bound to the IP address specified in the host attribute.

Testing
=====

Please refer to the [TESTING.md](TESTING.md) for instructions for testing the cookbook.

Berkshelf
=====

Berks will resolve version requirements and dependencies on first run and
store these in Berksfile.lock. If new cookbooks become available you can run
`berks update` to update the references in Berksfile.lock. Berksfile.lock will
be included in stable branches to provide a known good set of dependencies.
Berksfile.lock will not be included in development branches to encourage
development against the latest cookbooks.

License and Author
==================

|                      |                                                    |
|:---------------------|:---------------------------------------------------|
| **Author**           |  John Dewey (<john@dewey.ws>)                      |
| **Author**           |  Matt Ray (<matt@opscode.com>)                     |
| **Author**           |  Craig Tracey (<craigtracey@gmail.com>)            |
| **Author**           |  Ionut Artarisi (<iartarisi@suse.cz>)              |
| **Author**           |  JieHua Jin (<jinjhua@cn.ibm.com>)                 |
| **Author**           |  Mark Vanderwiel (<vanderwl@us.ibm.com>)           |
| **Author**           |  Jan Klare (<j.klare@x-ion.de>)                    |
|                      |                                                    |
| **Copyright**        |  Copyright (c) 2013, Opscode, Inc.                 |
| **Copyright**        |  Copyright (c) 2013, Craig Tracey                  |
| **Copyright**        |  Copyright (c) 2013, AT&T Services, Inc.           |
| **Copyright**        |  Copyright (c) 2013, SUSE Linux  GmbH.             |
| **Copyright**        |  Copyright (c) 2013-2014, IBM Corp.                |



Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
