#
# Cookbook Name:: gzip
# Recipe:: default
# License:: Apache 2.0 (see http://www.apache.org/licenses/LICENSE-2.0)
#
package 'gzip'
