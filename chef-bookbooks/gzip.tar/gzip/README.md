# gzip-cookbook

Installs gzip operating system package.

## Usage

### gzip::default

Include `gzip` in your node's `run_list`:

```json
{
  "run_list": [
    "recipe[gzip::default]"
  ]
}
```
