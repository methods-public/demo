name             'dacpac'
maintainer       'SuiGeneris'
maintainer_email 'luis.aguilar@suigeneris.com'
license          'All rights reserved'
description      'Deploys dacpac files'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.1'
supports         'windows'
depends          "windows", ">= 1.34.6"
