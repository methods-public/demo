node.default['qas']['quest_etc'] = '/etc/opt/quest'
node.default['qas']['quest_root'] = '/opt/quest'
node.default['qas']['quest_bin'] = "#{node['qas']['quest_root']}/bin"
node.default['qas']['configure_kerberos'] = false
