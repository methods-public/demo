## Mon May 18 12:22:13 EDT 2015 / 1.0.0
### Improvements
* Initial release. The QAS cookbook provides a centralized authentication management cookbook for Quest Authentication Services
