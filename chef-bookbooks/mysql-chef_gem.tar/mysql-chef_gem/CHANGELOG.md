mysql-chef_gem CHANGELOG
========================
This file is used to list changes made in each version of the mysql-chef_gem cookbook.

v1.0.0 (2014-12-12)
-------------------
- Removing recipe that contained a single resource
- Removed dependency on mysql cookbook
- Switched to using the MySQL connector libraries tarball from a
  webserver rather than system development package
- Added serverspec tests
- Updated the README

v0.0.5 (2014-09-26)
-------------------
- Reverting installation of ruby dev packages

v0.0.4 (2014-09-22)
-------------------
- Fixing some bugs in the README
- Adding more development packages

v0.0.2 (2014-03-31)
-------------------
Initial Release


v0.0.1 (2014-03-28)
-------------------
- Initial release
