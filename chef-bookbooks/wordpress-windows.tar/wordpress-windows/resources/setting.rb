actions :set
default_action :set
attribute :name, :kind_of => String, :name_attribute => true
attribute :value, :kind_of => String
attribute :autoload, :default => true
