default['wordpress']['windows']['plugins']['smtpplugin']['name']="wp-mail-smtp"
default['wordpress']['windows']['plugins']['smtpplugin']['version']="0.9.1"
default['wordpress']['windows']['plugins']['smtpplugin']['scriptname']="#{node['wordpress']['windows']['plugins']['smtpplugin']['name']}/wp_mail_smtp.php"
default['wordpress']['windows']['plugins']['smtpplugin']['sourcepath']="http://downloads.wordpress.org/plugin/#{node['wordpress']['windows']['plugins']['smtpplugin']['name']}.#{node['wordpress']['windows']['plugins']['smtpplugin']['version']}.zip"


