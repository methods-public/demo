default['wordpress']['windows']['plugins']['azurestorage']['name']="windows-azure-storage"
default['wordpress']['windows']['plugins']['azurestorage']['scriptname']="#{node['wordpress']['windows']['plugins']['azurestorage']['name']}/windows-azure-storage.php"
default['wordpress']['windows']['plugins']['azurestorage']['sourcepath']="http://downloads.wordpress.org/plugin/#{node['wordpress']['windows']['plugins']['azurestorage']['name']}.zip"

