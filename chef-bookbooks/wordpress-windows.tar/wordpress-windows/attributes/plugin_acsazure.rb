default['wordpress']['windows']['plugins']['acsplugin']['name']="acs-plugin-for-wordpress"
default['wordpress']['windows']['plugins']['acsplugin']['scriptname']="#{node['wordpress']['windows']['plugins']['acsplugin']['name']}/acs-wp-plugin.php"
default['wordpress']['windows']['plugins']['acsplugin']['sourcepath']="http://downloads.wordpress.org/plugin/#{node['wordpress']['windows']['plugins']['acsplugin']['name']}.zip"
