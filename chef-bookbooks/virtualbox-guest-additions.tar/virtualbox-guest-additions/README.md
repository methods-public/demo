# virtualbox-guest-additions-cookbook

Installs the Virtualbox Guest Additions

## Supported Platforms

* Centos 6.5 

## Attributes

* [default](attributes/default.rb)

## Recipes

### default

Installs the Virtualbox Guest Additions

## Contributing

1. Fork the repository on Github
2. Create a named feature branch (i.e. `add-new-recipe`)
3. Write your change
4. Write tests for your change (if applicable)
5. Run the tests, ensuring they all pass
6. Submit a Pull Request

## License and Authors

Author:: Patrick Ayoup (patrick.ayoup@gmail.com)
