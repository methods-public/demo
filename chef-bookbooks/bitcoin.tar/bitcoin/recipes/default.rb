#
# Cookbook Name:: bitcoin
# Recipe:: default
#

raise "bitcoin::default does nothing"
