## v0.1.3
- Fixing test, and switching to stable branch

## v0.1.2
- Removing bunk copy

## v0.1.1
- Updating badges

## v0.1.0
- Initial release
