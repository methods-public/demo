# The release you want to install of minecraft
default['factorio']['version'] = '0.12.35'

# The map location
default['factorio']['map'] = '/srv/save/map'
