# Change Log

1.3.0 (2016-06-28)

- Bumped to the newest headless server

1.1.1 (2016-03-17)

- typos and errors all over the place

1.1.0 (2016-03-17)

- Removed CentOS support because I didn't test it :(

1.0.0 (2016-03-17)

- Initial Release
