actions :create

attribute :aws_access_key, :kind_of => String
attribute :aws_secret_access_key, :kind_of => String
attribute :value, :kind_of => String
attribute :instance_id, :kind_of => String
attribute :tag, :kind_of => String, :name_attribute => true