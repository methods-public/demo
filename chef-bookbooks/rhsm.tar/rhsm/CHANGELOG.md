rhsm Cookbook CHANGELOG
==============

This file is used to list changes made in each version of the rhsm cookbook.

1.0.0
-----
- Initial release

