mecab-java Chef cookbook CHANGELOG
========================

0.2.0 / 2015-02-28
-----
- Java SDK header path attribute for usability.
- Add dependency to Java cookbook.

0.1.0 / 2015-02-24
-----
- The initial release.
