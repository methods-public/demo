#
# Cookbook Name:: bashrc
# Recipe:: default
#
