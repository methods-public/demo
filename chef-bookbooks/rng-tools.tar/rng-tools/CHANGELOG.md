## v1.1.0:

* Issue #1: Add RHEL Support

## v1.0.0:

* Initial release
