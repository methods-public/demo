default['rng_tools']['device'] = "/dev/urandom"
