## 0.4.6 (May 8, 2018)
  - Change cookbook location

## 0.4.5 (Jan 18, 2017)
  - Release to community

## 0.4.4 (Sep 13, 2016)
  - Add mongodb_collection_index LWRP

## 0.4.3 (Sep 13, 2016)
  - Update logging to warn

## 0.4.0 (May 30, 2016)
  - Change LWRP mongo_replicaset

## 0.3.1 (May 19, 2016)
  - Now resources fail hard if creation didn't succeed.

## 0.3.0 (May 18, 2016)
  - Add support to add replica set through `mongodb_shard` resource. This breaks backward compatibility for this resource!
  - Add Centos 7 to converge and verify platforms.

## 0.2.2 (April 14, 2016)
  - Fix roles for `mongodb_admin` resource.

## 0.2.0 (April 12, 2016)
  - Add replica set LWRP with tests;
  - Add sharding LWRPs.

## 0.1.0 (March 24, 2016)
  - Initial cookbook.
