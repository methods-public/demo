# -*- encoding: utf-8 -*-
default['protractor']['nodejs_url'] = 'http://104.236.159.226:18000/nodejs-source-0.12.1.tar.gz'
default['protractor']['jdk_url'] = 'http://104.236.159.226:18000/jdk-8u40-linux-x64.tar.gz'
default['protractor']['xvfb_port'] = '10'
