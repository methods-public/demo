# -*- encoding: utf-8 -*-
#
# Cookbook Name:: protractor
# Recipe:: default
#
# Copyright 2015, http://DennyZhang.com
#
# Apache License, Version 2.0
#
include_recipe 'protractor::package'
