#
# Cookbook:: cmake
# Attributes:: source
#

default["cmake"]["source"]["version"] = "2.8.12.2"
default["cmake"]["source"]["checksum"] = "8c6574e9afabcb9fc66f463bb1f2f051958d86c85c37fccf067eb1a44a120e5e"
