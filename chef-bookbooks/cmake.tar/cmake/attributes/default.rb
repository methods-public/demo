#
# Cookbook:: cmake
# Attributes:: default
#

default["cmake"]["install_method"] = "package" # `package` or `source`
