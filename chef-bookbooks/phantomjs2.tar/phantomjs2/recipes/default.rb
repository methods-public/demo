phantomjs2 node['phantomjs2']['path']
