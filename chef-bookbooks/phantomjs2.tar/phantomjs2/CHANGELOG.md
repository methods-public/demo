# CHANGELOG

## v1.1.0

- Support Windows installs
- Bump phantomjs version to 2.1.1

## v1.0.0

- Fork of Seth Vargo's phantomjs with resource added and support for package installs removed
