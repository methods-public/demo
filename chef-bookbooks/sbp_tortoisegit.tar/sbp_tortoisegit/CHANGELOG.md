sbp_tortoisegit CHANGELOG
==========================

0.1.0
-----
- Sander van Harmelen - Initial release of sbp_tortoisegit
