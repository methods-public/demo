hp-tools Cookbook CHANGELOG
===========================
This file is used to list changes made in each version of the hp-tools cookbook.

## 1.0.2
* Add license file
* Update contact information to my gmail account
* Add a Travis CI config
* Add a Test Kitchen config
* Add a Gemfile with development dependencies
* Add a rubocop config and resolve warnings
* Add source_url and issues_url to metadata
* Add .gitignore file
* Add Berksfile
* Add basic Chefspec unit test
* Add gitignore file
* Add badges and license to the readme
* Add contributing doc
