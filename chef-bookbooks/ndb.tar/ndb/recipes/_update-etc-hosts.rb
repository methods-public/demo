file "/etc/hosts" do
  action :delete
end

