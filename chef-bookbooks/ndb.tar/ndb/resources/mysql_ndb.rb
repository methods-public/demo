actions :install_distributed_privileges, :install_memcached

default_action :install_distributed_privileges


