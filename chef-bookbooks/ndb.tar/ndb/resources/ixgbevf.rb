actions :install_ubuntu, :install_redhat

default_action :install_ubuntu
