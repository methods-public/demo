default['backupdir']['dir_list'] = ''
default['backupdir']['file_list'] = ''
default['backupdir']['cron_time'] = '01:05'
default['backupdir']['remotecopy_method'] = ''

# Required parameter, need to be customized
default['backupdir']['backup_dir'] = ''
# Required parameter, need to be customized
default['backupdir']['aws_access_key_id'] = ''
# Required parameter, need to be customized
default['backupdir']['aws_secret_access_key'] = ''
default['backupdir']['s3_region'] = 'us-east-1'
