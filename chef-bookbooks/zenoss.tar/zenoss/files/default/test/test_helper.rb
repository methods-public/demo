require 'minitest/spec'
require "net/http"

include MiniTest::Chef::Assertions
include MiniTest::Chef::Context
include MiniTest::Chef::Resources