actions :run

default_action :run

attribute :devices, :kind_of => Hash, :default => {}
attribute :groups, :kind_of => Hash, :default => {}
attribute :systems, :kind_of => Array, :default => []
attribute :locations, :kind_of => Hash, :default => {}
