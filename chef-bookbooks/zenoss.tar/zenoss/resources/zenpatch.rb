actions :install

default_action :install

attribute :svnpatch, :kind_of => String, :name_attribute => true
attribute :ticket, :kind_of => String
