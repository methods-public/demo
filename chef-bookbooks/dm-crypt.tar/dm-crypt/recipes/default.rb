%w(cryptsetup file).each { |pkg| package pkg }
