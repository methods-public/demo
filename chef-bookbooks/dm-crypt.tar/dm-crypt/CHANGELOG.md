## 2016-02-15
### Summary
Initial release.

#### Features
- Installs `cryptsetup` utilities.
- Provides resource for `dmcrypt_device` to format devices with dm-crypt (LUKS).
