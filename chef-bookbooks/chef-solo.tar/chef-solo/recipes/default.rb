#
# Cookbook Name:: chef-solo
# Recipe:: default
#
# Copyright 2015, http://DennyZhang.com
#
# All rights reserved - Do Not Redistribute
#

# TODO to be implemented