test_kitchen_adds Cookbook CHANGELOG
====================================

0.1.1 (2017-10-27)
------------------
- Changed join_domain recipe to reboot immediately after domain join.

0.1.0 (2017-10-27)
------------------
- Initial version.
