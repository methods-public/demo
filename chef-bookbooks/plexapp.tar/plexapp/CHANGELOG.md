# v1.0.0

- #3, Plex no longer maintains upstream package repositories. We need to download the package from a specified URL and install it.

# v0.1.0

- Initial release
