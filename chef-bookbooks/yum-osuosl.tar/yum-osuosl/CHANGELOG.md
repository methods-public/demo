yum-osuosl CHANGELOG
====================
This file is used to list changes made in each version of the
yum-osuosl cookbook.

0.1.2 (2017-01-06)
------------------
- Fixed rubocop and foodcritic for yum-osuosl

0.1.0
-----
- Initial release of yum-osuosl

