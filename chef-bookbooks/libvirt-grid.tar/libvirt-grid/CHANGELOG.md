# libvirt-grid CHANGELOG

0.1.0
-----
- Initial release of libvirt-grid
