#
# Cookbook: blp-grub
# License: Apache 2.0
#
# Copyright 2015-2017, Bloomberg Finance L.P.
#

default['grub']['config'] = {}
