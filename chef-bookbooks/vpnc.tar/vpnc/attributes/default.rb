default['vpnc']['compile_time'] = false
default['vpnc']['run_as_service'] = true
