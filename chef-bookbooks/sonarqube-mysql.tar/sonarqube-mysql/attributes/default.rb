default['sonarqube-mysql']['username'] = 'sonar'
default['sonarqube-mysql']['password'] = 'sonar'

default['sonarqube-mysql']['mysql']['host']     = 'localhost'
default['sonarqube-mysql']['mysql']['username'] = 'root'
default['sonarqube-mysql']['mysql']['password'] = 'root'
default['sonarqube-mysql']['mysql']['version']  = '5.7'

default['sonarqube-mysql']['sonarqube']['url'] = 'http://localhost:9000'
