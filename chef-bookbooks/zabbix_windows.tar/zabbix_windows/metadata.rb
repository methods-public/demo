maintainer       'H. "Waldo" Grunenwald'
maintainer_email "gwaldo@gmail.com"
license          "Apache 2.0"
description      "Installs/Configures zabbix client on Windows."
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.1"
