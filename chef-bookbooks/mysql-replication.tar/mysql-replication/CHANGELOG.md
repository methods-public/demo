# Mysql-replication Cookbook Changelog

## 2.0.0 (March 31, 2017)
- Switch from HWRP to new Chef resources
- Added a support of mysql cookbook newer then 8.0
