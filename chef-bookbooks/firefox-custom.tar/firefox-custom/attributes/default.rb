#
# Cookbook Name:: firefox-custom
# Recipe:: default
#
# Copyright (C) 2015 digitalr00ts
#

# default['firefox-custom']['cfg-src'] = 'https://github.com/ckujau/scripts/raw/master/mozilla/firefox.cfg'
default['firefox-custom']['local-settings']['cfg'] = 'mozilla.cfg'
# default['firefox-custom']['local-settings']['rot'] = '0'
