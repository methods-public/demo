firefox-custom cookbook CHANGELOG
=================================
Tracking changes to the firefox-custom cookbook

## 0.1.1
* Corrections to README

## 0.1.0
* Initial release of firefox-custom
* Implemented support for global preferences via local-settings
* Support for 32-bit and 64-bit OSes
