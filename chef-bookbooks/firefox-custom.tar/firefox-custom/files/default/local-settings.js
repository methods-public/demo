/*
 * local-settings.js
 * http://kb.mozillazine.org/Locking_preferences
 *
 */
pref("general.config.obscure_value", 0);	// Do not obscure the content with ROT-13
pref("general.config.filename", "mozilla.cfg");
