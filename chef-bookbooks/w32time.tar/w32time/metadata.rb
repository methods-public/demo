name             'w32time'
maintainer       'Nicolas BENOIT'
maintainer_email 'sre-core-infra@criteo.com'
license          'Apache 2.0'
description      'This cookbook configure w32time'
long_description 'Installs/Configures w32time'
issues_url       'https://github.com/criteo-cookbooks/w32time' if respond_to? :issues_url
source_url       'https://github.com/criteo-cookbooks/w32time' if respond_to? :source_url
version          '0.1.0'
supports         'windows'
