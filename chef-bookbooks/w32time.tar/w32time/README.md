# w32time

This cookbook uses windows time service as a time synchronization client.
It sets its configuration to use a specific ntp server.