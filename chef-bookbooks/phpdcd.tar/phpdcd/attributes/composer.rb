#
# Cookbook Name:: phpdcd
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpdcd']['prefix'] = '/usr/bin'
