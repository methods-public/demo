#
# Cookbook Name:: phpdcd
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpdcd']['phar_url'] = 'https://phar.phpunit.de/phpdcd.phar'
default['phpdcd']['install_dir'] = '/usr/bin'
