#
# Cookbook Name:: phpdcd
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpdcd']['install_method'] = 'composer'
default['phpdcd']['version'] = 'latest'
