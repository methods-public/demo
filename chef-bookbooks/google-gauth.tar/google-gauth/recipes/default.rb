#
# Cookbook:: gauth
# Recipe:: default
#
# Copyright:: 2016, The Authors, All Rights Reserved.
