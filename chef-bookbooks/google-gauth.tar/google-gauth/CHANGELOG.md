# Changelog

## 0.1.1 (2017-10-16)

### New features

- Added `gauth_credential_serviceaccount_for_function` client function.

## 0.1.0 (2017-10-04)

Initial release
