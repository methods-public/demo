# git-extensions

Chef cookbook for downloading and installing Git Extensions
