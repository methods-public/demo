## 0.0.5 (unreleased)


## 0.0.4 (September 19, 2011)

### Improvments

* Add support for chef older than 0.9.16. ([@fnichol][])
* Add installation instructions to README. ([@fnichol][])


## 0.0.1 (August 4, 2011)

The initial release.

[@fnichol]: https://github.com/fnichol

