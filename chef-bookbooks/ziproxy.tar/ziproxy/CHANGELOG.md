# CHANGELOG for ziproxy

This file is used to list changes made in each version of ziproxy.

1.0.0
-----
- Initial release of ziproxy cookbook
