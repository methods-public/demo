#
# Cookbook:: crio
# Attributes:: default
#
# Copyright:: 2018, Nathan Williams <nath.e.will@gmail.com>
#

default['crio']['repo'] = 'virt7-container-common'
default['crio']['storage'] = []
default['crio']['network'] = []
default['crio']['conf'] = {}
