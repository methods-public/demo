name 'test'
version '0.0.0'

depends 'crio'
depends 'yum-epel'
