sumologic-collector
==============

To test this cookbook update your ruby environment using bundle install. To run the suite of tests run rake.
This cookbook uses rubocop, foodcritic, chefspec and test-kitchen with serverspec.