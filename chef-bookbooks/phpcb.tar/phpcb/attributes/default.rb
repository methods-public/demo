#
# Cookbook Name:: phpcb
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpcb']['install_method'] = 'composer'
default['phpcb']['version'] = 'latest'
