#
# Cookbook Name:: phpcb
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpcb']['phar_url'] = 'https://github.com/Mayflower/PHP_CodeBrowser/releases/download/1.1.0/phpcb-1.1.0.phar'
default['phpcb']['install_dir'] = '/usr/bin'
