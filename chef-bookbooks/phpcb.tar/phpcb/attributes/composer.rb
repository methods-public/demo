#
# Cookbook Name:: phpcb
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpcb']['prefix'] = '/usr/bin'
