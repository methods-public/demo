# CHANGELOG for collectd_ii

## 1.1.0 (4/28/2017)

- [Corey Hemminger] - Updated collectd version to 5.5.1

## 1.0.1 (4/22/2017)

- [Corey Hemminger] - bug fix

## 1.0.0 (4/21/2017)

- [Corey Hemminger] - Initial commit