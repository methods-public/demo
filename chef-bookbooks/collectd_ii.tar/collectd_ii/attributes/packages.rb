default['collectd_ii']['packages'] = ['collectd']
