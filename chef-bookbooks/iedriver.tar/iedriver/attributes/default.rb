default['iedriver']['version'] = '3.1.0'
default['iedriver']['url'] = 'https://selenium-release.storage.googleapis.com'

default['iedriver']['home'] = "#{ENV['SYSTEMDRIVE']}\\iedriver"
default['iedriver']['config_ie'] = true

default['iedriver']['forcex86'] = false
