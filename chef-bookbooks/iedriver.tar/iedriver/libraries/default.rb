def iedriver_short_version(version)
  version.slice(0, version.rindex('.'))
end
