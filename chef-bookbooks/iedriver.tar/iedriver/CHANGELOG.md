# Changelog
## 2.2.1 2017-12-15

- New attribute `node['iedriver']['forcex86']` added, which controls whether to force a 32-bit install of IEDriver

## 2.2.0 2017-02-27

- IEDriver release 3.1.0

## 2.1.0 2017-01-27

- IEDriver release 3.0.0

## 2.0.0 2016-10-01

- Drop support for Chef 11

## 1.5.1 2016-08-03

- IEDriver release 2.53.1

## 1.5.0 2016-03-22

- IEDriver release 2.53.0

## 1.4.0 2016-02-18

- IEDriver release 2.52.0

## 1.3.0 2016-02-10

- IEDriver release 2.51.0

## 1.2.0 2016-01-28

- IEDriver release 2.50.0

## 1.1.2

- Fix #3 Enable first run for all browser versions

## 1.1.1

- Fix #2 IEDriver on Windows 10 is getting 'Windows firewall has blocked some of the features of this app'

## 1.1.0

- IEDriver release 2.48.0

## 1.0.1

- Fix #1 WARN: Cloning resource attributes for env[PATH] from prior resource (CHEF-3694)

## 1.0.0

- Initial release
