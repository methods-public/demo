maintainer       "OmniTI"
maintainer_email "sa@omniti.com"
license          "Modified BSD"
description      "nad (nodejs monitoring agent)"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.6"
name             "nad"
supports         "ubuntu", ">= 10.0.0"    
supports         "centos", ">= 5.0"    
supports         "rhel",   ">= 5.0"    
supports         "smartos", ">= 0.0"

depends         "smf", ">= 0.0.0"
