# Cookbook Changelog

This file is used to list changes made in each version of the __application_wlp__ cookbook.

## 0.2.0:

### Bugs

- **[Issue #2](https://github.com/WASdev/ci.chef.wlp.application/issues/2)** - Deploying application using chef-client 11.6: undefined method 'create' for nil:NilClass

### Improvements

- **[Issue #1](https://github.com/WASdev/ci.chef.wlp.application/issues/1)** - Update dependency to application 4.1.0

## 0.1.0:

* Initial release.

