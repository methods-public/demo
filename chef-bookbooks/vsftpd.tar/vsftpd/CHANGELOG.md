vsftpd CHANGELOG
========================

0.1.3 (2017-10-08)
------------------
- Update readme

0.1.2 (2017-10-08)
------------------
- Update travis-ci settings

0.1.1 (2016-12-28)
------------------
- Initial release
