# Contributing to WebSphere Liberty Profile Chef Cookbook

We welcome contributions but request that you follow [these guidelines](https://github.com/WASdev/wasdev.github.io/blob/master/CONTRIBUTING.md).

[Issue tracker][].

[issue tracker]: https://github.com/WASdev/ci.chef.wlp/issues

