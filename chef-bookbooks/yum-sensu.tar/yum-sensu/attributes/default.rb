default['yum']['sensu']['description'] = 'Sensu Repository'
default['yum']['sensu']['baseurl'] = 'https://sensu.global.ssl.fastly.net/yum/$releasever/$basearch/'
default['yum']['sensu']['gpgcheck'] = false
default['yum']['sensu']['enabled'] = true
default['yum']['sensu']['managed'] = true
