# CHANGELOG for windirstat

This file is used to list changes made in each version of windirstat.

Changes/Roadmap
===============

## 1.0.2:

* added unit and integration tests
* updated default WinDirStat download URL

## 1.0.1:

* fixes invalid `metadata.json` (thanks to kbaltrinic)

## 0.1.0:

* initial release
