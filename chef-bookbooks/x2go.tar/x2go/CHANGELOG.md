x2go CHANGELOG
==============

This file is used to list changes made in each version of the x2go cookbook.

0.1.0
-----
- [Rilindo Foster] - Initial release of x2go

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
