google-cloud-logging CHANGELOG
=================

This file is used to list changes made in each version of the google-cloud-logging cookbook.

0.1.0
-----
- Vipin Thomas - Initial release of google-cloud-logging

0.1.1
-----
- Vipin Thomas - Documentation Changes

0.1.2
-----
- Vipin Thomas - Documentation Changes

0.1.3
-----
- Vipin Thomas - Documentation Changes

0.1.4
-----
- Vipin Thomas - Documentation Changes

0.1.5
-----
- Vipin Thomas - Documentation Changes

0.1.6
-----
- Vipin Thomas - Documentation Changes

0.1.7
-----
- Vipin Thomas - Version details with GitHub source link

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
