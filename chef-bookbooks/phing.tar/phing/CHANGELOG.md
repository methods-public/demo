0.0.3 (2015-02-09)
------------------

* Refactor PEAR recipe
* Add Composer installation method and set it as default

0.0.2 (2014-01-06)
------------------

* Repack cookbook

