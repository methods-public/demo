default['rubyinstaller']['version'] = '2.3.0'
default['rubyinstaller']['path']    = 'C:/Ruby23-x64'
default['rubyinstaller']['cert_path'] =
  "#{node['rubyinstaller']['path']}/lib/ruby/2.3.0/rubygems/ssl_certs"
