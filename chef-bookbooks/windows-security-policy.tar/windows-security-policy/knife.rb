cookbook_path ["../."]
client_key '~/.chef/grdnr.pem'
node_name 'grdnr'
