# yum-zabbix Cookbook CHANGELOG
This file is used to list changes made in each version of the yum-zabbix cookbook.

## v0.1.0
initial release
