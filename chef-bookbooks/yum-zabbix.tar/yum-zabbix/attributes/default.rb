default['yum-zabbix']['repositories'] = %w(zabbix zabbix-non-supported)
