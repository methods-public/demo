# alternatives CHANGELOG

This file is used to list changes made in each version of the alternatives cookbook.

0.2.0
-----

- Virender Khatri - fixed README for #1 [ci skip]

- Virender Khatri - added inspec, travis, kitchen dokken, test cookbook

- Virender Khatri - attribute link is not required

- Virender Khatri - lint fix

0.1.1
-----

- Virender Khatri - updated README for correct cookbook version

0.1.0
-----

- Virender Khatri - initial release of alternatives

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
