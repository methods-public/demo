#
# Cookbook Name:: asset_provider
# Recipe:: default
#
# Copyright (c) 2015 Tnarik Innael, All Rights Reserved.
