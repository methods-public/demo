## v0.0.4:
* Refactoring the provider implementation, moving most of the logic to chef client subclass
* Support for json_attributes and arguments in stage chef runs
* stage chef runs will run in their own cache folder eliminating repeated cookbook upload/download

