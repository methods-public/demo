sda-agent CHANGELOG
===================

This file is used to list changes made in each version of the sda-agent cookbook.

0.1.1
-----
- [Kevin Lee] - Fix issue of Agent service stopping on completion
0.1.0
-----
- [Kevin Lee] - Initial release of sda-agent


