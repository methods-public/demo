default['boxstarter']['tmp_dir'] = "#{ENV['TEMP']}/boxstarter"
