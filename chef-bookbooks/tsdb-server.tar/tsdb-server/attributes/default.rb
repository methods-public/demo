# The zookeeper address.
default[:tsdb][:quorum] = "localhost"
