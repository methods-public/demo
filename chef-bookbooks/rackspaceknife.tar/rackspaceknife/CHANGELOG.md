opschef-cookbook-rackspace version 0.0.4

+ Add test/support/Gemfile
+ Add Rakefile
+ Bring cookbook into foodcritic compliance
+ No additional functionality then previous version
