actions :update

attribute :name, :kind_of => String, :name_attribute => true

default_action :update
