# Tissues

Install patch for CVE-2017-0145 AKA WannaCry.

More Info: [https://www.microsoft.com/security/portal/threat/encyclopedia/Entry.aspx?Name=Ransom:Win32/WannaCrypt](https://www.microsoft.com/security/portal/threat/encyclopedia/Entry.aspx?Name=Ransom:Win32/WannaCrypt)

---

Usage:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[tissues]"
  ]
}
```
