windows_dhcp CHANGELOG
======================

This file is used to list changes made in each version of the windows_dhcp cookbook.

0.2.0

- reservations update provider

0.1.0
-----
- Initial release of windows_dhcp

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
