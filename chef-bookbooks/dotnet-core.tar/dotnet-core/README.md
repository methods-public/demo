# .NET Core Cookbook

This cookbook installs .NET Core for Windows(planned) and Linux.

### Supported Platforms
* Red Hat, Fedora, CentOS
* Debian, Ubuntu
* Windows

### Dependencies
* Chef 12.5+
* yum
* apt
* sudo
