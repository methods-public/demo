# hc-vault CHANGELOG

0.1.3
-----
- improves server key pair deployment.

0.1.2
-----
- improves SSL server key management.

0.1.1
-----
- revises documents.

0.1.0
-----
- Initial release of hc-vault
