## v0.4.0

- Remove source recipe and related attributes

## v0.3.0

- dont namespace use_brew? in Chef::Recipe, makes it unavailable in a resource

## v0.2.0

- add apt cookbook as a dependency (LWRP is used in package recipe)
- move bash resource above remote_file
- 'tar' missing in url attribute
- package dependencies for building from source
- freebsd has a mosh package now, default to that

## v0.1.0

- Initial release
