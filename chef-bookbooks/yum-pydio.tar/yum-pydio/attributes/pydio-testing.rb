default['yum']['pydio-testing']['repositoryid'] = 'pydio-testing'
default['yum']['pydio-testing']['description'] = 'Pydio for EL6 (Testing) - $basearch'
default['yum']['pydio-testing']['baseurl'] = 'http://dl.ajaxplorer.info/repos/el6/pydio-testing'
default['yum']['pydio-testing']['gpgkey'] = 'http://dl.ajaxplorer.info/repos/charles@ajaxplorer.info.gpg.key'
default['yum']['pydio-testing']['gpgcheck'] = true
default['yum']['pydio-testing']['enabled'] = true
default['yum']['pydio-testing']['managed'] = true
