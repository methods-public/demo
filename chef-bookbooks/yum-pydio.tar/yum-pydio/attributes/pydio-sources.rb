default['yum']['pydio-sources']['repositoryid'] = 'pydio-sources'
default['yum']['pydio-sources']['description'] = 'Pydio for EL6 (SRPMs) - $basearch'
default['yum']['pydio-sources']['baseurl'] = 'http://dl.ajaxplorer.info/repos/el6/pydio-sources'
default['yum']['pydio-sources']['gpgkey'] = 'http://dl.ajaxplorer.info/repos/charles@ajaxplorer.info.gpg.key'
default['yum']['pydio-sources']['gpgcheck'] = true
default['yum']['pydio-sources']['enabled'] = false
default['yum']['pydio-sources']['managed'] = true
