default['yum-pydio']['repositories'] = %w(pydio pydio-testing pydio-sources)
