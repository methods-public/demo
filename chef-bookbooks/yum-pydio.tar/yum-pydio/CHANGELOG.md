# 0.1.0

Initial release of yum-pydio

* Enhancements
  * Add repo pydio for RHEL familys

