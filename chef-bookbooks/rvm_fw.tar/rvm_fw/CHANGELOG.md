rvm_fw CHANGELOG
================

This file is used to list changes made in each version of the rvm_fw cookbook.

0.1.0
-----
- [Steven Haddox] - Initial release of rvm_fw
