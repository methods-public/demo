require 'rubygems'
require 'bootstrap-sass'

http_path = "/"
css_dir = "public/stylesheets"
sass_dir = "sass"
images_dir = "public/images"
javascripts_dir = "public/javascripts"

output_style = :compressed
