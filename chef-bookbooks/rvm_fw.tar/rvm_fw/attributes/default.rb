default['rvm_fw']['url'] = nil
default['rvm_fw']['version'] = '1.18.14'
default['rvm_fw']['global_ruby'] = 'ruby-2.3.1'
default['rvm_fw']['extra_rubies'] = []
default['rvm_fw']['disable_requiretty'] = false
default['rvm_fw']['user'] = 'root'
