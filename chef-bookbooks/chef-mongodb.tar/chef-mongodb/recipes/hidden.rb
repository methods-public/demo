node.set[:mongodb][:type][:hidden] = true
