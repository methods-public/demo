sbp_chef_embedded Cookbook
==========================
This cookbook enables you to use the embedded packages like ruby and perl system wide


Attributes
----------
N/A


Usage
-----
Include `sbp_chef_embedded` in your node's `run_list` to enable the system wide usage of the Chef embedded packages


Contributing
------------
  1. Fork the repository on Github
  2. Create a named feature branch (i.e. `add-new-recipe`)
  3. Write you change
  4. Write tests for your change (if applicable)
  5. Run the tests, ensuring they all pass
  6. Submit a Pull Request


License and Authors
-------------------
Authors: Sander van Harmelen

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

