sbp_chef_embedded CHANGELOG
===========================

0.1.0
-----
- Sander van Harmelen - Initial release of sbp_chef_embedded
