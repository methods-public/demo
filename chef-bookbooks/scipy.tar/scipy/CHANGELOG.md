## 0.3.1

* Bugfix: Fix platform_version typo in default recipe for Fedora

## 0.3.0

* Enhancement: Migrate from deprecated yum::epel recipe to yum-epel cookbook

## 0.2.0

* Update pip_packages to requirements format and specify >= SciPy Stack 1.0 requirements by default

## 0.1.0

* Initial release with package recipe
