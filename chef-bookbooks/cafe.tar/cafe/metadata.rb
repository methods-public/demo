name 'cafe'
maintainer 'Michael Hedgpeth'
maintainer_email 'mhedgpeth@gmail.com'
license 'Apache-2.0'
description 'Installs/Configures cafe'
long_description 'Installs/Configures cafe'
issues_url 'https://github.com/mhedgpeth/cafe-cookbook/issues'
source_url 'https://github.com/mhedgpeth/cafe-cookbook'
version '2.0.0'

supports 'windows'

depends 'vcruntime'
depends 'windows'
