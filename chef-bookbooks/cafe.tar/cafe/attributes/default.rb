default['cafe'] = {
  chef_interval: 1800,
  port: 59320,
  install_root: 'C:',
  version: '0.9.2.0',
  version_github: '0.9.2-beta',
}
