## v1.0.0:

* Converted Opscode cookbook to work with chef-solo, using data-bags
