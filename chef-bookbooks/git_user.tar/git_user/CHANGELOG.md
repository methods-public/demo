## 0.5.0 / 2017-06-01

lookup users data bag in the same style as user cookbook [@GolubevV](https://github.com/GolubevV), [#7](https://github.com/lxmx/chef-git-user/pull/7)
github requires login as git user [@veilig2000](https://github.com/GolubevV), [#5](https://github.com/lxmx/chef-git-user/pull/5)

## 0.4.0 / 2015-12-02

expose gitconfig values as cookbook attributes
change gitconfig ownership to specified user [@bcg62](https://github.com/bcg62), [#6](https://github.com/lxmx/chef-git-user/pull/6)

## 0.3.1 / 2014-09-23

Provide a way to not include git recipe - [@obazoud](https://github.com/obazoud), [#1](https://github.com/lxmx/chef-git-user/pull/1)

## 0.3.0 / 2013-06-17

Full rewrite with a LWRP and a data_bag recipe.
Implemented integration tests.
