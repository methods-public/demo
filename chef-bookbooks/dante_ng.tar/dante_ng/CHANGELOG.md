# dante_ng CHANGELOG

This file is used to list changes made in each version of the shadowsocks cookbook.

## 0.3.1
- [merqlove] - Support telegram voice-calls by default

## 0.3.0
- [merqlove] - Stable service configuration

## 0.2.0
- [merqlove] - Fixed dante installer. Using sources. Support CentOS 7+.

## 0.1.0
- [merqlove] - Initial release of dante_ng

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
