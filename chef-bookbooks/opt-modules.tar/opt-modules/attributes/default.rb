default['opt-modules']['version'] = "3.2.10"
default['opt-modules']['download_url'] = "http://prdownloads.sourceforge.net/modules/modules-#{node['opt-modules']['version']}.tar.gz"
default['opt-modules']['download_dir'] = "/tmp"
default['opt-modules']['install_dir'] = "/opt"
