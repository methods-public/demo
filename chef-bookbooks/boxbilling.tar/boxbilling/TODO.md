TODO
====

* [ ] Update `mysql` cookbook to version `6`.
* [ ] Add unit tests for libraries.
* [ ] Improve api provider PATH_SPECIAL_IDS implementation avoiding nils.
