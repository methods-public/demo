# Run this recipe to completely remove the cloudinsight-agent
package 'cloudinsight-agent' do
  action :purge
end
