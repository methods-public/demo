#
# Cookbook Name:: cloudinsight-agent
# Recipe:: cloudinsight-ruby
#


gem_package 'cloudinsight-sdk'
