#
# Cookbook Name:: cloudinsight-agent
# Recipe:: default
#

