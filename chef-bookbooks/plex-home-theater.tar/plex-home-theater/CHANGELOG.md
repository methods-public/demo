Plex Home Theater Cookbook CHANGELOG
====================================

v1.0.0 (2015-11-30)
-------------------
- Convert to Chef 12.5 custom resources

v0.1.0 (2015-06-29)
-------------------
- Initial release, with support for OS X and Windows

v0.0.1 (2015-06-08)
-------------------
- Development started
