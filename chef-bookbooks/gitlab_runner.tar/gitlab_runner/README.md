# gitlab_runner

Chef cookbook to install and configure GitLab Runner.
DEPRECATED in favor of [aegir-ci-runner](https://supermarket.chef.io/cookbooks/gitlab-ci-runner)

## License and (original) Authors

Author:: Matt Thomson (mattjohnthomson@gmail.com)

[gitlab-ci-runner]:https://supermarket.chef.io/cookbooks/gitlab-ci-runner
