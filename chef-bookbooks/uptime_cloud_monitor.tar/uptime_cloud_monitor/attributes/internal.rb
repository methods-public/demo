# Cookbook Name:: uptime_cloud_monitor
# # Attributes :: internal
# Copyright 2016-2017 IDERA
# License:: MIT License


default['copperegg']['url'] = 'api.copperegg.com'
