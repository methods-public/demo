v0.1.3
======
* Corrections for iconv-dev and rhel/centos
* Cookbook admin support for emeril
* Basic Kitchen.ci support

v0.1.2
======
* Add attribute based package removal

v0.1.0
======

* Adds source install method
* Adds rubygems install method

v0.0.1
======

* Initial release
