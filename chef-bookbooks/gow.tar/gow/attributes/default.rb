
default["gow"]["url"] = "https://github.com/downloads/bmatzelle/gow/Gow-0.5.0.exe"
