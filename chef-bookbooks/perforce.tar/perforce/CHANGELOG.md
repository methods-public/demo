# CHANGELOG

## 2.2.0 2016-12-15

- Drop apt and yum cookbook dependencies by going to Chef 12.14.x

## 2.1.0 2016-11-14

- Support new cli package name

## 2.0.0 2016-10-04

- Drop support for Chef 11

## 1.4.1 2016-09-16

- Debian 8 should use trusty package
- Add support for Ubuntu 13 and 15 versions

## 1.4.0 2016-09-16

- Use p4 r16.1 release
- Add Mac OS X support

## 1.3.0 2016-07-07

- Add Fedora 19+ support
- Add Ubuntu 16.04 support

## 1.2.4 2016-01-22

- Relax pessimistic locking on apt and yum dependencies 

## 1.2.3 2016-01-21

- Fix #2 Incompatible windows version

## 1.2.2 2015-12-28

- Change windows_package name to match registry DisplayName to prevent re-installs

## 1.2.1 2015-12-16

- Fix Windows unattended install

## 1.2.0 2015-11-27

- Add Windows support

## 1.1.0 2015-11-27

- Add Debian support

## 1.0.0 2015-10-27

- Initial release
