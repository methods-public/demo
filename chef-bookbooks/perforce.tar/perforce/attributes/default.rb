default['perforce']['download_url'] = 'http://www.perforce.com/downloads/perforce'
default['perforce']['release'] = 'r16.1'
