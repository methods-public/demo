sbp_treesizefree CHANGELOG
==========================

0.1.2
-----
- Updated checksum to match the current (3.3.2) version
- New option to add a desktop shortcut

0.1.0
-----
- Sander van Harmelen / Ane van Straten - Initial release of treesizefree
