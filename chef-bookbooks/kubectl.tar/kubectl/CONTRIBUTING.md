# How to contribute

Simply create an issue, make a PR, and then I'll review and merge.
