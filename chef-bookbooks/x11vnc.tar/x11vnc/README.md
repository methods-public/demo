Description
===========

Installs and configures x11vnc

Usage
=====

Fill out the password in attributes/default.rb if you want to protect with a password
