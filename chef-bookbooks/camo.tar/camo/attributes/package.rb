#
# cookbook name: camo
#
