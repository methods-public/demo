name             'grubby'
maintainer       'Criteo'
maintainer_email 'j.mauro@criteo.com'
license          'Apache 2.0'
description      'Installs/Configures grubby'
long_description 'Installs/Configures grubby'
issues_url       'https://github.com/criteo-cookbooks/grubby' if respond_to?(:issue_url)
source_url       'https://github.com/criteo-cookbooks/grubby' if respond_to?(:source_url)
version          '0.1.1'
supports         'centos'
supports         'rhel'
