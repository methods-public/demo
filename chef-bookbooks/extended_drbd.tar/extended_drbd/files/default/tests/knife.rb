cache_type 'BasicFile'
cache_options(:path => File.expand_path('../../.kitchen/.cache', __FILE__))

# vim: ai et ts=2 sts=2 sw=2 ft=ruby
