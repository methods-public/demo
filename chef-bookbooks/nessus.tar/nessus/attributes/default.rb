# Install
default['nessus']['installer_file']   = '/tmp/Nessus-*'
default['nessus']['enable']           = true

# Activation 
default['nessus']['activate']         = true
default['nessus']['activation_code']  = nil

# Users
default['nessus']['vault']            = nil
default['nessus']['vault_users_item'] = nil
