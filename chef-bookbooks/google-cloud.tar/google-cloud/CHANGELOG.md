# Changelog

## 0.2.0 (2018-03-16)

### New features

- Added `google-glogging` cookbook.

## 0.1.0 (2017-10-04)

Initial release
