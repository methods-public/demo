consul-ng CHANGELOG
================

This file is used to list changes made in each version of the consul-ng cookbook.

0.1.4
-----

- Virender Khatri - Update Consul version to 0.7.0

0.1.3
-----

- JustGav - Create systemd.debian.erb

- JustGav - Fix Travis

- JustGav - Added kitchen Ubuntu 16.04

- Daan de Goede - Fix for Search is not working with double quotes around the datacenter string

- Virender Khatri - Fix travis build

0.1.2
-----

- Rene Mul - Fix lint

- Rene Mul - Added support for systemd

- Nathan Sullivan - fix to allow init script to be installed successfully in kitchen-docker

- Nathan Sullivan - bump versions supported to include 0.6.4

- Nathan Sullivan - fixed rubocop, spec tests

- Virender Khatri - make install and config recipe optional

0.1.1
-----
- Rene Mul - Added Windows installation support

0.1.0
-----
- Virender Khatri - Initial release of consul-ng

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
