AWS_ms_dotnet CHANGELOG
==================================

This file is used to list changes made in each version of the AWS_ms_dotnet cookbook.

0.1.0
-----
- Yeung Siu - Initial release of AWS_ms_dotnet

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
