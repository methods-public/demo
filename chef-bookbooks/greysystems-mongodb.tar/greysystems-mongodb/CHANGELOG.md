# 1.0.0

initial release

# 2.0.1

Improved CI/CD with automatic publishing to chef supermarket

# 2.0.2

Fixed [#issue-1](https://github.com/grey-systems/chef-greysystems-mongodb/issues/1)
