#
# Installs/configure a basic mongo instance
# Cookbook Name:: greysystems-mongodb
# Recipe:: default
#
# Copyright (C) 2015 GreySystems
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'greysystems-mongodb::install'
