chef-manageiq CHANGELOG
=========================

This file is used to list changes made in each version of the chef-manageiq cookbook.

1.0.0
-----
- [Chris Kacerguis] - Updated Cookbook with misc bugfixes

0.1.0
-----
- [BoozAllen] - Initial release of chef-manageiq
