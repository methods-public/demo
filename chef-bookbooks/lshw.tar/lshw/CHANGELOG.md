lshw CHANGELOG
==============

This file is used to list changes made in each version of the lshw cookbook.

0.1.0
-----
- [Rilindo Foster] - Initial release of lshw

0.1.1
-----
- [Rilindo Foster] - Removed support for CentOS/RHEL - conflict with chef in EPEL repo.

0.1.2
-----
- [Rilindo Foster] - Reddded support for CentOS.

0.1.3
-----
- [Rilindo Foster] - Documentation fix.
- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
