# version_databag cookbook CHANGELOG

This file is used to list changes made in each version of the version_databag cookbook.

## 1.0 (yyyy-mm-dd)

- The 1.0 release of the version_databag cookbook
