default['version_databag']['version_type'] = 'release'
default['version_databag']['databag'] = nil
default['version_databag']['databag_item'] = nil
default['version_databag']['artifact_override_map'] = nil
default['version_databag']['artifact_specifications'] = nil
default['version_databag']['delimiter'] = '<>'
