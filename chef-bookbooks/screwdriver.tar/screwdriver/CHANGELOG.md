# screwdriver CHANGELOG

0.6.0
-----
- adds Minio support.

0.5.0
-----
- adds PostgreSQL support. 
- fixes typo.

0.4.0
-----
- adds MySQL support. 

0.3.1
-----
- revises documents. 

0.3.0
-----
- adds multiple SCM support.
- refactoring.

0.2.2
-----
- improves server key pair deployment.

0.2.1
-----
- revises documents.
- bug fix.

0.2.0
-----
- adds a reverse proxy service (Nginx) for the UI service SSL/TLS settings.
- bug fix.

0.1.0
-----
- Initial release of screwdriver
