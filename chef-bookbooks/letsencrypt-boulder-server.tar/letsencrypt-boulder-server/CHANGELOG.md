# 0.1.2

* Added more specific platform version specification.
* Get boulder git revision from attribute

# 0.1.1

* Added metadata for Supermarket.

# 0.1.0

* Initial release of `letsencrypt-boulder-server`, based off
  [`acme_server` test cookbook](https://github.com/schubergphilis/letsencrypt/tree/master/test/fixtures/cookbooks/acme_server).
