
default['opsview']['agent']['x64']['url'] = 'https://s3.amazonaws.com/opsview-agents/Windows/Opsview_Windows_Agent_x64_28-01-15-1600.msi'
default['opsview']['agent']['Win32']['url'] = 'https://s3.amazonaws.com/opsview-agents/Windows/Opsview_Windows_Agent_Win32_28-01-15-1559.msi'
default['opsview']['agent']['windows_conf_dir'] = 'C:\Program Files\Opsview Agent'
default['opsview']['agent']['manage_ncslient_config'] = true