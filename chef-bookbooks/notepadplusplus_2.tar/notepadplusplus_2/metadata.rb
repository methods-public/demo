maintainer        "Tim Smith - Webtrends Inc"
maintainer_email  "tim.smith@webtrends.com"
license           "Apache 2.0"
license          "All rights reserved"
description      "Installs/Configures Notepad++"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.0.3"
supports         "windows"
depends          "windows"