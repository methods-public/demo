name             'netcdf'
maintainer       'Ivan Suftin'
maintainer_email 'isuftin@usgs.gov'
license          'Public Domain'
description      'Installs/Configures netcdf'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
supports         'centos'
version          '0.1.1'