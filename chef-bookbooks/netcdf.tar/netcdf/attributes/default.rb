default['netcdf']['zlib']['version'] = '1.2.8'

default['netcdf']['szip']['version'] = '2.1'
default['netcdf']['szip']['skip'] = false

default['netcdf']['hdf5']['version'] = '1.8.14'
default['netcdf']['hdf5']['skip_check'] = true

default['netcdf']['netcdf']['version'] = 'v4.3.3-rc3'
default['netcdf']['netcdf']['skip_check'] = true
