## 0.4.1 / 2013-06-15

Full rewrite with LWRP, data_bag recipe and integration tests.
