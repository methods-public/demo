# CHANGELOG for artifactory_ii

## 2.0.0 (4/26/2017)

- [Corey Hemminger] - Rewritten for jfrog artifactory oss from rpm and yum repo

## 1.0.0 (4/18/2017)

- [Corey Hemminger] - Initial commit
