net_core CHANGELOG
========================
0.1.5 (01-12-2016)
Update to .Net Core 1.0.1

0.1.4 (26-09-2016)
Fixes bug with .net core not on the path correctly. 

0.1.3 (14-09-2016)
Updated DotNetCore package to 1.0.1
