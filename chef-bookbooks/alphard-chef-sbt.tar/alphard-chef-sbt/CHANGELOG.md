# Cookbook SBT CHANGELOG

This file is used to list changes made in each version of the alphard-chef-sbt cookbook.

## 1.0.0
- Frédéric Nowak - frederic.nowak@hydra-technologies.net - Create sbt installation recipe
