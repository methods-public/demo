# yum_mysql_community cookbook

This cookbook installs the Oracle yum repository for MySQL community.
See http://dev.mysql.com/doc/mysql-repo-excerpt/5.6/en/linux-installation-yum-repo.html
Officially, the Oracle-provided repo only supports RHEL5, RHEL6, RHEL7, Fedora 19 and Fedora 20.


# Requirements

# Usage

Run the default recipe to install the repo

# Attributes

# Recipes

The ::default recipe installs the repository
The ::remove recipe removes the repository

# Author

Author:: Bryan Taylor (<bcptaylor@gmail.com>)
