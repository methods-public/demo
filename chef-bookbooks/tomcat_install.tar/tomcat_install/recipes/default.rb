#
# Cookbook Name:: tomcat_install
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
include_recipe "tomcat_install::java"
