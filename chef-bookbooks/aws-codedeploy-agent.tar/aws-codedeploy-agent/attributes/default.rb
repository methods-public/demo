default['aws-codedeploy-agent']['rbenv_ruby-version'] = '2.1.5'
default['aws-codedeploy-agent']['aws_sdk_core-version'] = '2.6.11'
default['aws-codedeploy-agent']['aws_codedeploy_agent-version'] = 'v1.0-1045'
