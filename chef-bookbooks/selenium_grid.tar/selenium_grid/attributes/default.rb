default['selenium_grid']['username'] = nil
default['selenium_grid']['password'] = nil

default['selenium_grid']['display']['width'] = 1024
default['selenium_grid']['display']['height'] = 768
default['selenium_grid']['display']['depth'] = 24
default['selenium_grid']['display']['windows'] = true

default['selenium_grid']['chrome']['max_instances'] = 0
default['selenium_grid']['chrome']['version'] = nil
default['selenium_grid']['firefox']['max_instances'] = 0
default['selenium_grid']['firefox']['version'] = nil
default['selenium_grid']['htmlunit']['max_instances'] = 0
default['selenium_grid']['htmlunit']['version'] = nil
default['selenium_grid']['ie']['max_instances'] = 0
default['selenium_grid']['ie']['version'] = nil
