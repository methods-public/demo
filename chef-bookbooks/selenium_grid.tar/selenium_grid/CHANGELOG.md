# Changelog

## 2.0.0

- Drop support for Chef 11
- Drop support for Opera
- Drop support for Mac OS X
- Drop support for PhantomJS

## 1.2.2

- Support Firefox on Debian platform

## 1.2.1

- Replace firefox with mozilla_firefox cookbook

## 1.2.0 

- Support Opera

## 1.1.0 

- Support PhantomJS

## 1.0.0 

- Initial release
