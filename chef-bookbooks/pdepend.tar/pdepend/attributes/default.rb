#
# Cookbook Name:: pdepend
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['pdepend']['install_method'] = 'composer'
default['pdepend']['version'] = 'latest'
