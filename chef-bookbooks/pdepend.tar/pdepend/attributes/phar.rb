#
# Cookbook Name:: pdepend
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['pdepend']['phar_url'] = 'http://static.pdepend.org/php/latest/pdepend.phar'
default['pdepend']['install_dir'] = '/usr/bin'
