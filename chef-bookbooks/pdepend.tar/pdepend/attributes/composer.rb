#
# Cookbook Name:: pdepend
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['pdepend']['prefix'] = '/usr/bin'
