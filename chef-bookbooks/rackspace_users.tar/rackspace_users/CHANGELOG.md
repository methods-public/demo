rackspace_users CHANGELOG
=========================

0.2.8
-----
- Updated README
- Fixed Rubocop errors
- Fixed circleci ssh key issue
- Added Gemfile.lock to repo
- Changed CentOS 6.6 to 6.7 in unit tests

0.2.7
-----
- Use pessimistic version when pinning

0.2.6
-----
- Pin upstream cookbooks

0.2.5
-----
- Support for CentOS 6.7 instead of 6.6

0.2.4
-----
- Corrected README
- Fixed unit test error related to Faraday gem

0.2.3
-----
- Sudo 'runas' now defaults to 'ALL' and is configurable via the data bag

0.2.2
-----
- Fixed README

0.2.1
-----
- Fix cookbook description in metadata

0.2.0
-----
- Default behaviour and membership changes

0.1.2
-----
- Fix for group creation conditional

0.1.1
-----
- Added more tests

0.1.0
-----
- First version
