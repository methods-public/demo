#vifm [![Build Status](https://secure.travis-ci.org/gregf/cookbook-vifm.png)](http://travis-ci.org/gregf/cookbook-vifm)

Installs vifm file manager.

###Platform

* Debian, Ubuntu
* CentOS, Fedora

##Attributes

See `attributes/default.rb` for default values.

* `default['vifm']['install_vifm']`
* `default['vifm']['version']`
* `default['vifm']['checksum']`
