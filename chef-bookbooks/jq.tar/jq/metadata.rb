name             'jq'
maintainer       'ThoughtWorks, Inc.'
maintainer_email 'go-cd-dev@googlegroups.com'
license          'MIT'
description      'Installs/Configures jq'
version          '0.1.0'

supports 'centos'
supports 'ubuntu'

depends 'yum-epel'
