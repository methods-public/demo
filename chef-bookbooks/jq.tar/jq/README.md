# jq Cookbook

Installs [jq](https://github.com/stedolan/jq) "Command-line JSON processor"
