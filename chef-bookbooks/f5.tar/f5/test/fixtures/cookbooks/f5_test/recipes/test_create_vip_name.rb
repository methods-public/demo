f5_vip 'myvip' do
  address 'github.com'
  port '80'
  protocol 'PROTOCOL_TCP'
  pool 'reallybasic'
end
