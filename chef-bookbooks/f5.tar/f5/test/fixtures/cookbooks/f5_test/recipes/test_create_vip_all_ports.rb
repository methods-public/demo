f5_vip 'myvip' do
  address '86.75.30.9'
  port '*'
  protocol 'PROTOCOL_TCP'
  pool 'reallybasic'
end
