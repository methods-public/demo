default['f5']['gem_version'] = '0.2.7'
default['f5']['enabled_status'] = :manual # :manual, :disabled, or :enabled
default['f5']['databag_name'] = 'f5'
default['f5']['credentials'] = {}
