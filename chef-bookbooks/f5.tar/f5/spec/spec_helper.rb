# spec_helper.rb
require 'chefspec'
require 'chefspec/berkshelf'
