# 0.2.2
Bugfix for the last version

# 0.2.1

Supporting credentials in a databag

# 0.2.0

Still rough around the edges and nowhere near feature complete, but
this cookbook will create the pool and VIP and add the node as a member

# 0.1.0

Initial release of f5
