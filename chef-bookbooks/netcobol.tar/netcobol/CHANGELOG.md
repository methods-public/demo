## v0.0.8

* Correct x86_64 profile script
* Correct x86_64 path attributes
* Add path sanity tests

## v0.0.7

* Correct x86_64 package names

## v0.0.6

* Clean-up for initial release

## v0.0.1

* I feel dirty, deployed **COBOL** using Chef
