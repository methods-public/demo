graphviz CHANGELOG
==================

This file is used to list changes made in each version of the graphviz cookbook.

0.1.1
-----
- Takuma J Miyake - Add metadata and readme


0.1.0
-----
- Takuma J Miyake - Initial release of graphviz

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
