default['bginfo']['url']       = 'http://download.sysinternals.com/Files/BgInfo.zip'

default['bginfo']['home']      = "#{ENV['SYSTEMDRIVE']}\\bginfo"
