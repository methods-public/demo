maintainer       "Nathan Lee"
maintainer_email "nathan@globalphobia.com"
license          "All rights reserved"
description      "Installs/Configures bginfo"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.6"
supports         "windows"
depends          "windows", ">= 1.2.8"
