Description
===========
Installs BGInfo and sets up an auto run.

Requirements
============
Windows

Attributes
==========

Usage
=====

