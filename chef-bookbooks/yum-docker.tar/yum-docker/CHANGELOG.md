yum-docker CHANGELOG
=====================

This file is used to list changes made in each version of the yum-docker
cookbook.

0.3.0
-----
- Sean OMeara (sean@chef.io)
  - add Amazon Linux support

0.2.0
-----
- Sean OMeara (sean@chef.io)
  - fix Chef 13 deprecation warnings

0.1.0
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - initial release of yum-docker
