CHANGELOG for Patchman
======================

## 1.1.0 (December 1, 2015)

Bugfixes
  - updated Ruby code syntax

Improvements
  - added unit tests coverage
  - added CD framework for automated testing

## 1.0.2 (March 4, 2015)

Bugfixes
  - fixed Berksfile.lock (removed)
