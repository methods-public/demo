rssh CHANGELOG
==============

This file is used to list changes made in each version of the rssh cookbook.

0.1.5
-----

- Virender Khatri - added rubocop, food critic,  knife and spec lint tests

- Virender Khatri - fixed for rubocop syntax

- Virender Khatri - added rake tasks

0.1.3
-----

- Virender Khatri - re formatted README

- Virender Khatri - foodcritic ready

- Dan Fruehauf - updated README for lwrp

- Dan Fruehauf - added user lwrp


0.1.1
-----

- Virender Khatri - initial release of rssh

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
