Chef::Log.warn('The default chef_slack recipe does nothing. See the readme for information on using the slack_notify resources')
