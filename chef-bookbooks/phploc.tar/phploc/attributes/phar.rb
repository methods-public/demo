#
# Cookbook Name:: phploc
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phploc']['phar_url'] = 'https://phar.phpunit.de/phploc.phar'
default['phploc']['install_dir'] = '/usr/bin'
