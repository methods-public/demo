#
# Cookbook Name:: phploc
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phploc']['prefix'] = '/usr/bin'
