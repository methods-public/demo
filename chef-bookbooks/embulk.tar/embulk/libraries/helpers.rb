module EmbulkCookbook
  # Helper methods included by various providers and passed to the template engine
  module Helpers
  end
end
