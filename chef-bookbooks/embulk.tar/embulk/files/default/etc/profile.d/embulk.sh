# DEPLOYED BY CHEF

if [ -d "$HOME"/.embulk/bin ]; then
  export PATH="$HOME/.embulk/bin:$PATH"
fi
