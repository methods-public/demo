default['embulk']['user'] = ''
default['embulk']['group'] = ''
default['embulk']['home'] = ''
default['embulk']['version'] = 'latest'
default['embulk']['checksum'] = 'd2c2f1e059b31a9cbf9422cbb64fd11b'

default['embulk']['gemlist'] = {}
