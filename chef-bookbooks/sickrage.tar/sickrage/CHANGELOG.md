sickrage CHANGELOG
==================

This file is used to list changes made in each version of the sickrage cookbook.

### 0.2.0
- Added ability to use rhel 7 or similar OS

### 0.1.0
- Jeremy - Initial release of sickrage
- Basic install and service install
- No configuration for sickrage included
