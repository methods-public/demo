default['gearman']['parameters']['backlog'] = nil
default['gearman']['parameters']['file-descriptors'] = nil
default['gearman']['parameters']['job-retries'] = nil
default['gearman']['parameters']['log-file'] = nil
default['gearman']['parameters']['listen'] = 'localhost'
default['gearman']['parameters']['port'] = 4730
default['gearman']['parameters']['threads'] = nil
default['gearman']['parameters']['user'] = nil

default['gearman']['parameters']['queue-type'] = nil

default['gearman']['libdrizzle']['host'] = nil
default['gearman']['libdrizzle']['port'] = nil
default['gearman']['libdrizzle']['uds'] = nil
default['gearman']['libdrizzle']['user'] = nil
default['gearman']['libdrizzle']['password'] = nil
default['gearman']['libdrizzle']['db'] = nil
default['gearman']['libdrizzle']['table'] = nil
default['gearman']['libdrizzle']['mysql'] = nil

default['gearman']['libmemcached']['servers'] = nil

default['gearman']['libsqlite3']['db'] = nil
default['gearman']['libsqlite3']['table'] = nil

default['gearman']['libpq']['conninfo'] = nil
default['gearman']['libpq']['table'] = nil

default['gearman']['libtokyocabinet']['file'] = nil
default['gearman']['libtokyocabinet']['optimize'] = nil

default['gearman']['mysql']['host'] = nil
default['gearman']['mysql']['port'] = nil
default['gearman']['mysql']['user'] = nil
default['gearman']['mysql']['password'] = nil
default['gearman']['mysql']['db'] = nil
default['gearman']['mysql']['table'] = nil
