require File.expand_path('../support/helpers', __FILE__)

describe_recipe 'cacti::package' do
  include Helpers::CactiCookbook
end
