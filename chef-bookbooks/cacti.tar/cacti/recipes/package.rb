node['cacti']['packages'].each do |p|
  package p
end
