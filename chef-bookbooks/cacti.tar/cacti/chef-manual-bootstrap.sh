#!/bin/sh

# pld Linux
if [ -f /usr/bin/poldek ]; then
  /usr/bin/poldek --noask -u chef
fi
