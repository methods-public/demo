twindb-repo Cookbook CHANGELOG
==============================
This file is used to list changes made in each version of the twindb-repo cookbook.

v0.2.0
------
- The TwinDB repository has been migrated to Package Cloud

v0.1.1
------
- Fix issues reported by foodcritic

v0.1.0
------
- First release
