# secrets_management Cookbook CHANGELOG

This file is used to list changes made in each version of the secrets_management cookbook.

## v1.0.0

- Initial release with support for reading Hashicorp Vault, Chef-Vault, and Chef Data bag items
