#
# Cookbook:: secrets_management
# Attribute:: default
#
# maintainer:: Exosphere Data, LLC
# maintainer_email:: chef@exospheredata.com
#
# Copyright:: 2017, Exosphere Data, LLC, All Rights Reserved.

default['hashicorp']['refresh_token'] = nil
