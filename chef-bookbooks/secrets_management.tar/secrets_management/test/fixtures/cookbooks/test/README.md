This cookbook is used for testing the secrets_management cookbook
