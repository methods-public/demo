# CHANGELOG

## 0.2.2 2018-03-18

- Add attribute to change task run level

## 0.2.1 2017-10-25

- Update version of logrotate installer


## 0.2.0 2017-06-07

- Replace sensitive attribute with confidential attribute for Chef 13
- Flagged password as sensitive for Chef 13


## 0.1.0 2017-01-20

- Initial release using logrotateSetup v0.0.0.17
