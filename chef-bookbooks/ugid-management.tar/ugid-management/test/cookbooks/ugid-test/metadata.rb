name 'ugid-test'
maintainer 'Make.org'
maintainer_email 'sre@make.org'
license 'Apache-2.0'
description 'Library cookbook to help testing ugid-mamagement cookbook'
long_description 'Library cookbook to help testing ugid-mamagement cookbook'
source_url 'https://gitlab.com/chef-platform/ugid-management'
issues_url 'https://gitlab.com/chef-platform/ugid-management/issues'
version '1.0.0'

supports 'centos', '>= 7.1'

depends 'docker-platform', '= 1.0.1'
