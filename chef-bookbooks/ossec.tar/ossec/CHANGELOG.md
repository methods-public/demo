## v1.0.4

### Bug

- [COOK-2740]: Use FQDN for a client name

### Improvement

- [COOK-2739]: Upgrade OSSEC to version 2.7

## v1.0.2:

* [COOK-1394] - update ossec to version 2.6

## v1.0.0:

* Initial/current release
