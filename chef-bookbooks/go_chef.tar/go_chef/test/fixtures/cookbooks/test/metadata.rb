name 'test'
version '0.0.1'
depends 'go_chef'
