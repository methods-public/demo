go "Installing Go for Chef VM" do
  version '1.9.2'
  action :install
end
