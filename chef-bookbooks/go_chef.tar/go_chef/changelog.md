# CHANGELOG for go_chef

This file is used to list changes made in each version of golang. Mark you change number, underneath put your username then your changes.

## 2.0.0
  * ilovemysillybanana
  * Converted Cookbook to use resource model
  * Added Test Cookbook

## 1.0.3
  * bws0013
  * Removing changes from 1.0.2

## 1.0.2
  * bws0013
  * Testing removing depends

## 1.0.1
  * bws0013
  * Made changes to metadata

## 1.0.0
  * bws0013
  * Create a temporary directory

## 0.1.0
  * github username
  * change made
