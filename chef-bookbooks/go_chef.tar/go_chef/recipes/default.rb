#
# Cookbook:: go_chef
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.

Chef::Log.warn('The default go_chef recipe does nothing. See the readme for information on using the go_chef resources')
