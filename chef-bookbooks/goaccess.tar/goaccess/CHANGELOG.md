goaccess Cookbook
=================

v0.2.0 (2014-09-15)
-------------------

* [Greg Barker] Update to 0.8.5 and add attribute for url.

v0.1.0 (2014-03-24)
-------------------

* Initial release

