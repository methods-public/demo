mecab-perl Chef cookbook CHANGELOG
========================

0.1.0 / 2015-02-20
-----
- The initial release.
