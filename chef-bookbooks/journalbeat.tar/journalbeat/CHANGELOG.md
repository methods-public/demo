Changelog
=========

1.0.0
-----

- Initial version with logstash support, tested on Centos
