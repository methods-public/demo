name 'test-journalbeat'
maintainer 'Make.org'
maintainer_email 'sre@make.org'
license 'Apache 2.0'
description 'Helper Cookbook to test JournalBeat'
long_description 'Helper Cookbook to test JournalBeat'
source_url 'https://gitlab.com/chef-platform/journalbeat'
issues_url 'https://gitlab.com/chef-platform/journalbeat/issues'
version '1.0.0'

chef_version '>= 12.19'

supports 'centos', '>= 7.3'
