## v0.0.9

* Add support for PureStorage SAN
* Add test-kitchen tests
* Fix issues reported by foodcritic

## v0.0.8

* Correct resource ordering problem with service/notify

## v0.0.7

* Fix Travis badge on README
* Add chefignore file

## v0.0.6

* Add package/service attributes
* Add debian family support
* Add attribute sanity tests + Travis files
* Add multipath::undo recipe
