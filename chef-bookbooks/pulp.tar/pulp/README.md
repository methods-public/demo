Usage
-----

Description
-----------
This is Chef cookbook to deploy pulp service.

Support
-------
- CentOS 6 (Tested on CentOS 6.5)

Links
-----
- http://www.pulpproject.org/
