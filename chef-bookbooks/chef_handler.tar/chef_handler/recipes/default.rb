Chef::Log.warn('chef_handler::default recipe has been deprecated. Use the chef_handler resource instead to define handlers from your own wrapper cookbook.')
