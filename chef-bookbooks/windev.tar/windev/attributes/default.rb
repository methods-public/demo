default['software_depot']="software"
default['drivers']=[]
default['installer_packages']=[]
default['zip_packages']=[]
default['windows_features']={"remove"=>[]}
default['environment']={}#~FC039
