#
# Cookbook Name:: windev
# Recipe:: default
#
# Author:: Vassilis Rizopoulos (<var@zuehlke.com>)
#
# Copyright (c) 2014-2018 Zühlke, All Rights Reserved.
#
