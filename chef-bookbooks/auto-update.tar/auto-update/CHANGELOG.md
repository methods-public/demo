auto-update CHANGELOG
=====================

0.3.0
-----
- Sandor Acs - Code refactoring

0.2.0
-----
- Sandor Acs - "Unattended-update" conflict solved 

0.1.0
-----
- Sandor Acs - Initial release of auto-update
