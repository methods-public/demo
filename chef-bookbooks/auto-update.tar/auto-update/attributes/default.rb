default['auto-update']['enabled'] = false
default['auto-update']['stamp_file'] = '/var/tmp/periodic_update_last_run'
default['auto-update']['interval'] = 86400

