ssmtp2 CHANGELOG
===============

0.1.0
-----
- [michael.m.morris@gmail.com] - Initial release of ssmtp2 cookbook

0.2.0
-----
- [michael.m.morris@gmail.com] - Moved to yum 3.x cookbook for epel recipe

0.2.1
-----
- [michael.m.morris@gmail.com] - Changed bundle process from tar to 'knife cookbook site share'

0.3.0
-----
- [michael.m.morris@gmail.com] - Updates to enable Chef 12 support (should still be Chef 11 compliant!)
