default['n98-magerun']['install_dir'] = '/usr/local/bin'
default['n98-magerun']['install_file'] = 'n98-magerun.phar'
default['n98-magerun']['url'] = 'https://raw.github.com/netz98/n98-magerun/master/n98-magerun.phar'
default['n98-magerun']['unstable'] = false
