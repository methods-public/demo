## v1.1.1:

* Added CentOS and Fedora support
* Remove end-of-life Ubuntus from test matrix

## v1.0.0:

* Resolve foodcritic warnings
* Convert README to markdown
* Rename attributes file to default.rb
* Add test kitchen support

## v0.1.0:

* Current/initial release
