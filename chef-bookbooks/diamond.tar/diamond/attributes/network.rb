default['diamond']['collectors']['NetworkCollector']['byte_unit'] = 'megabit'
default['diamond']['collectors']['NetworkCollector']['interfaces'] = 'eth,pbond,bond'
