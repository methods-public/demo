default['diamond']['collectors']['MongoDBCollector']['path'] = 'mongo'
default['diamond']['collectors']['MongoDBCollector']['host'] = 'localhost'
