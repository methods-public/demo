default['diamond']['collectors']['NginxCollector']['path'] = 'nginx'
default['diamond']['collectors']['NginxCollector']['req_path'] = '/nginx_status'
default['diamond']['collectors']['NginxCollector']['req_host'] = 'localhost'
default['diamond']['collectors']['NginxCollector']['req_port'] = '8080'
