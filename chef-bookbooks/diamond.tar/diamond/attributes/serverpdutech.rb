default['diamond']['collectors']['ServerTechPDUCollector']['interval'] = 300
default['diamond']['collectors']['ServerTechPDUCollector']['timeout'] = 15
default['diamond']['collectors']['ServerTechPDUCollector']['retries'] = 3
default['diamond']['collectors']['ServerTechPDUCollector']['port'] = 161
