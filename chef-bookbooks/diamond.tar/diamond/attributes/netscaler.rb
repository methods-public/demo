default['diamond']['collectors']['NetscalerSNMPCollector']['path'] = 'netscaler'
default['diamond']['collectors']['NetscalerSNMPCollector']['interval'] = 300
default['diamond']['collectors']['NetscalerSNMPCollector']['timeout'] = 15
default['diamond']['collectors']['NetscalerSNMPCollector']['retries'] = 3
