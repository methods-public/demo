default['diamond']['collectors']['MySQLCollector']['path'] = 'mysql'
default['diamond']['collectors']['MySQLCollector']['host'] = 'localhost'
default['diamond']['collectors']['MySQLCollector']['port'] = 3306
default['diamond']['collectors']['MySQLCollector']['db'] = 'information_schema'
