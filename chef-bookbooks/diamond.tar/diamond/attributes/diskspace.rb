default['diamond']['collectors']['DiskSpaceCollector']['filesystems'] = 'ext2, ext3, ext4, xfs, glusterfs, nfs, ntfs, hfs, fat32, fat16'
default['diamond']['collectors']['DiskSpaceCollector']['exclude_filters'] = '/export/home'
default['diamond']['collectors']['DiskSpaceCollector']['byte_unit'] = 'byte'
