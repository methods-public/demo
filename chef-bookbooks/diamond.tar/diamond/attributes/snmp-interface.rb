default['diamond']['collectors']['SNMPInterfaceCollector']['path'] = 'interface'
default['diamond']['collectors']['SNMPInterfaceCollector']['interval'] = 300
default['diamond']['collectors']['SNMPInterfaceCollector']['timeout'] = 15
default['diamond']['collectors']['SNMPInterfaceCollector']['retries'] = 3
default['diamond']['collectors']['SNMPInterfaceCollector']['port'] = 161
