Changelog
=========

1.2.0
-----

Main:

- refactor(exporter): rename metrics dir in lsb way
- refactor(exporter): put exporter attrs in sub-key

Tests:

- increase wait tries, minor code improvement

Misc:

- style(rubocop): fix heredoc delimiters

1.1.0
-----

Main:

- fix(exporter): correct metrics file format and extension
- refactor(exporter): set better default paths

Tests:

- add test to check metrics file format

1.0.0
-----

- Initial version with centos and debian support
