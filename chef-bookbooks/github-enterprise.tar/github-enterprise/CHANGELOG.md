# 1.0.1

Update custom resources for better names and remove name conflicts

# 1.0.0

Move to using custom resources for all setup and config

# 0.1.1

Release with Travis-ci support for foodcritic and chef-syntax

# 0.1.0

Initial release of github-enterprise
