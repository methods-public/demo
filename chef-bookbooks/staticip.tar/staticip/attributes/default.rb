default['staticip']['nic_interface'] = 'eth0'
default['staticip']['ipaddress'] = '127.0.0.1'
