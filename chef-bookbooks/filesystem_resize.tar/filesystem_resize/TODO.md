TODO
====

* [ ] LVM support.
* [ ] Support for resize unmounted file systems.
* [ ] Add RSpec unit tests for libraries.
