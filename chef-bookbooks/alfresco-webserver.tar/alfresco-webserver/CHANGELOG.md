# 0.7.3

- Removed the nginx-hardening cookbook from Berksfile, as it has been [published](https://supermarket.chef.io/cookbooks/nginx-hardening) on the public supermarket ( 62795ff )
- Added coveralls support and flare on the README.md ( 19613b4 )
- Added explicit support for Redhat and Centos platforms, to be displayed on the supermarket ( 7c9cf55 )

# 0.7.2

Preparing README for Chef supermarket release

# 0.7.1

Documentation Review

- added licensing ( 5a8dbc2 )
- documentation review ( 6eb8396 )
- removed unused protocol attribute ( ce11f86 )


# 0.7.0

Initial release of chef-alfresco-webserver
