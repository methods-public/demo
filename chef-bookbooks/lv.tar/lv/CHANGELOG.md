# CHANGELOG for lv

## 0.2.0

* Add test-kitchen
* Support Ubuntu
* Improve metadata.rb

## 0.1.0

* Initial release
