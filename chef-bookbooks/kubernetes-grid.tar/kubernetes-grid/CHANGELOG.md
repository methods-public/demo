# kubernetes-grid CHANGELOG

0.1.2
-----
- Bug fix: linux-image installation in a Linux container.

0.1.1
-----
- adds the `kubernetes-grid::gp-node` recipe.

0.1.0
-----
- Initial release of kubernetes-grid
