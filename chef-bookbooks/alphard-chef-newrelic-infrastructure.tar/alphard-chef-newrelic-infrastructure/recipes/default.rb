
# Install and configure the New Relic Infrastructure agent
include_recipe "::agent"
