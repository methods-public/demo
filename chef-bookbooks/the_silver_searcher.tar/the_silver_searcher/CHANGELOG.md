# the\_silver\_searcher

## v1.4.3 (2016-01-21)

-   the\_silver\_searcher updated to version 0.31.0
-   various spec, test, and documentation improvements

## v1.4.2 (2015-06-05)

-   remove chef-sugar
-   various small fixes

## v1.4.1 (2015-05-06)

-   the\_silver\_searcher updated to version 0.30.0

## v1.4.0 (2015-03-25)

-   bring this cookbook back from the dead!
-   the\_silver\_searcher updated to version 0.29.1
-   update to modern tooling and code standards
-   collapse integration tests into one suite
-   allow passing options to ag's build.sh script

## v1.3.9 (2014-03-23)

-   the\_silver\_searcher updated to 0.21.0
-   there is a 0.21.1 version in git HEAD, but no tarball is available yet
-   changed the URL (hopefully temporarily) to work around CHEF-5148

## v1.3.8 (2014-03-15)

-   the\_silver\_searcher updated to version 0.20.0
-   support alternate source URLs

## v1.3.7 (2014-02-17)

-   the\_silver\_searcher updated to version 0.19.2

## v1.3.6 (2014-01-29)

-   the\_silver\_searcher updated to version 0.19.1
-   test on Fedora 20

## v1.3.5 (2014-01-28)

Fixing a few issues resulting from adding stove

## v1.3.4 (2014-01-28)

-   skipped due to me misunderstanding stove docs

## v1.3.3 (2014-01-28)

-   switching to stove for releases

## v1.3.2 (2013-12-09)

-   the\_silver\_searcher updated to version 0.18.1

## v1.3.1 (2013-12-09)

-   SUSE support removed due to untestability

## v1.2.4 (2013-10-31)

-   the\_silver\_searcher updated to version 0.18

## v1.2.3 (2013-09-09)

-   the\_silver\_searcher updated to version 0.16

## v1.2.2 (2013-09-04)

-   test on fedora 19 and ubuntu 13.04

## v1.2.1 (2013-08-28)

-   support fedora
-   test on fedora and debian

## v1.2.0 (2013-08-09)

-   the\_silver\_searcher updated to version 0.15
-   adds liblzma as a dependency

## v1.1.1 (2013-05-31)

-   support SUSE

## v1.1.0 (2013-05-21)

-   simplify build, use chef file\_cache\_path

## v1.0.4 (2013-04-30)

-   bump version for testing

## v1.0.3 (2013-04-29)

-   first public version
