default.the_silver_searcher.version = '0.31.0'
default.the_silver_searcher.checksum = '61bc827f4557d8108e91cdfc9ba31632e2568b26884c92426417f58135b37da8'
default.the_silver_searcher.url = "https://codeload.github.com/ggreer/the_silver_searcher/tar.gz/#{node.the_silver_searcher.version}"
default.the_silver_searcher.build_opt = ''
