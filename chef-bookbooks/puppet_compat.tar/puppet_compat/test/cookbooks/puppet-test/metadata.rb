name 'puppet-test'
version '0.0.1'
description 'Test cookbook'
depends 'puppet_compat'
