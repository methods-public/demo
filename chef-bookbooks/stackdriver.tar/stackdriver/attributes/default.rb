#
# Cookbook Name:: stackdriver
# Attributes:: default
#
#

default['stackdriver']['api']['key'] = "YOUR_API_KEY_HERE"
default['stackdriver']['collectd']['config'] = "yes"
