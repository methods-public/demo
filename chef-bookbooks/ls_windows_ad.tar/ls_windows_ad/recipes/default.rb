#
# Cookbook Name:: ls_windows_ad
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

# Install Active Directory Role and RSAT tools
include_recipe 'ls_windows_ad::server'

