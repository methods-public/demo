#
# Cookbook Name:: phpdoc
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpdoc']['prefix'] = '/usr/bin'
