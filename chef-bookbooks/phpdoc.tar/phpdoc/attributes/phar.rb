#
# Cookbook Name:: phpdoc
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpdoc']['phar_url'] = 'http://phpdoc.org/phpDocumentor.phar'
default['phpdoc']['install_dir'] = '/usr/bin'
