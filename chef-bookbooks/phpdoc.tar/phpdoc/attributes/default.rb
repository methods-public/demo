#
# Cookbook Name:: phpdoc
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpdoc']['install_method'] = 'composer'
default['phpdoc']['version'] = 'latest'
