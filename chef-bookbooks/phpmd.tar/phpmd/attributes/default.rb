#
# Cookbook Name:: phpmd
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpmd']['install_method'] = 'composer'
default['phpmd']['version'] = 'latest'
