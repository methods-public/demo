#
# Cookbook Name:: phpmd
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpmd']['prefix'] = '/usr/bin'
