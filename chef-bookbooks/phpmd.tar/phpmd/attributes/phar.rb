#
# Cookbook Name:: phpmd
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpmd']['phar_url'] = 'http://static.phpmd.org/php/latest/phpmd.phar'
default['phpmd']['install_dir'] = '/usr/bin'
