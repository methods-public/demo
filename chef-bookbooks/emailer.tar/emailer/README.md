Description
===========

Installs gems that enable servers to send email.  Library in-lines the text as well as attaches it.

Requirements
============

Attributes
==========

What you see is what you get.  I have a gmail account that I use as an SMTP server; my example is currently setup for TLS with google.

Usage
=====

Check "example.rb"