#
# Cookbook Name:: phpunit
# Attributes:: phar
#
# Copyright (c) 2016, David Joos
#

default['phpunit']['phar_url'] = 'https://phar.phpunit.de/phpunit.phar'
default['phpunit']['install_dir'] = '/usr/bin'
