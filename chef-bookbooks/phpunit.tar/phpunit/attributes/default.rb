#
# Cookbook Name:: phpunit
# Attributes:: default
#
# Copyright (c) 2016, David Joos
#

default['phpunit']['install_method'] = 'composer'
default['phpunit']['version'] = 'latest'
