#
# Cookbook Name:: phpunit
# Attributes:: composer
#
# Copyright (c) 2016, David Joos
#

default['phpunit']['prefix'] = '/usr/bin'
