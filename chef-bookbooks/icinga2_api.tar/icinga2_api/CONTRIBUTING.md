https://github.com/scopenco/chef-icinga2_api/issues
