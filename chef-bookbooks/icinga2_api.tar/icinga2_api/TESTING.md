Please refer to [official docs](https://github.com/chef-cookbooks/community_cookbook_documentation/blob/master/TESTING.MD) for details.
