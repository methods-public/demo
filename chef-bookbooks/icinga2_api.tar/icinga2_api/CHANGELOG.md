icinga2_api CHANGELOG
========================

1.0.3 (2018-04-5)
------------------
- Add cascade:true for removing host/service

1.0.2 (2018-04-3)
------------------
- Improve removing host object

1.0.1 (2018-03-26)
------------------
- Decrease debuging
- Support strings/symbols in arguments

1.0.0 (2018-03-23)
------------------
- Switch to the new style custom resource

0.3.1 (2018-03-20)
------------------
- Fix build-essential setup

0.3.0 (2018-03-08)
------------------
- Fix API calls
- Update teskitchen env

0.2.1 (2017-11-21)
------------------
- Fix docs

0.2.0 (2017-11-21)
------------------
- Add icinga2_api_service LWRP
- Update docs

0.1.5 (2017-11-19)
------------------
- Add TESTING.md
- Add CONTRIBUTING.md

0.1.4 (2017-11-17)
------------------
- Fix readme

0.1.3 (2017-11-17)
------------------
- Fix rubocop
- Update email info

0.1.2 (2017-11-17)
------------------
- Fix integration tests
- Add build-essential dep

0.1.1 (2017-11-16)
------------------
- Update docs

0.1.0 (2017-11-16)
------------------
- Initial release
