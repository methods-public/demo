name 'test'
depends 'icinga2', '~> 3.0.1'
depends 'icinga2_api'
