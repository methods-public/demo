## v0.1.7
- removing yum dependecy

## v0.1.6
- releasever requires centos-release pkg, removing this dependency.

## v0.1.5
- updating source_url and gems

## v0.1.4
- updating repo url

## v0.1.3
- correct gpg key location

## v0.1.2
- easier management of yum resource
- add managed attrib
- update README

## v0.1.1
- updating supermarket urls

## v0.1.0
- initial release
