# kill-switch CHANGELOG

This file is used to list changes made in each version of the kill-switch cookbook.

## 1.0.1
- [mattlqx] - Fix not honoring `normal_exit` if run_list contained `kill-switch` instead of `kill-switch::default`. (#1)

## 1.0.0
- [mattlqx] - Initial release.

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
