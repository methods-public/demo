name 'kill-switch-test'
supports 'windows'
supports 'ubuntu'
