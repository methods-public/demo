## Testing

### Test Kitchen

Configure the appropriate behavior in .kitchen.yml and converge an instance.

### RSpec

ChefSpec tests can be run by simply running `rspec`.
