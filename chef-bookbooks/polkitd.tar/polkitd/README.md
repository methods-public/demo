# polkitd

This cookbook will manage the polkitd service.

## Supported Platforms

* Centos 7.0

## License and Authors

Author:: Sander Botman (<sander.botman@gmail.com>)
