# proget-cookbook

[![AppVeyor Build Status](https://img.shields.io/appveyor/ci/jonathanmorley/proget-cookbook/master.svg?label=appveyor)](https://ci.appveyor.com/project/jonathanmorley/proget-cookbook)
[![Travis Build Status](https://img.shields.io/travis/cvent/proget-cookbook/master.svg?label=travis)](https://travis-ci.org/cvent/proget-cookbook)
[![Code Climate](https://img.shields.io/codeclimate/github/cvent/proget-cookbook.svg)](https://codeclimate.com/github/cvent/proget-cookbook)
[![Chef cookbook](https://img.shields.io/cookbook/v/proget.svg)](https://supermarket.chef.io/cookbooks/proget)
[![GitHub license](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](https://github.com/cvent/proget-cookbook/blob/master/LICENSE)
