TODO
====

* [ ] Fix total swap size with Chef `< 11.12` when a wrong */swapfile0* already exists.
* [ ] Consider the available disk space.
* [ ] Distribute files among different disks.
* [ ] Set swappiness.
