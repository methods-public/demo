# Change Log

## Unreleased

## [0.3.0] - 2016-10-20
### Added
- Support debian-8.5
- Added daun usage in helloworld example

## [0.2.0] - 2016-09-25
### Added
- Support opensuse-13.2
- Support opensuse-leap-42.1
- Support ubuntu-16.04
- opengrok_index output goes to both console and file

## 0.1.0 - 2016-09-16
### Added
- Initial release. Support only centos-7.2

[Unreleased]: https://github.com/ceilfors/cookbook-opengrok/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/ceilfors/cookbook-opengrok/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/ceilfors/cookbook-opengrok/compare/v0.1.0...v0.2.0