##Set the Splunk Version to be used

#Server
default['splunk']['server_root']                  = "http://download.splunk.com/releases"
default['splunk']['server_version']               = "5.0.1"
default['splunk']['server_build']                 = "143156"

#Forwarder
default['splunk']['forwarder_root']               = "http://download.splunk.com/releases"
default['splunk']['forwarder_version']            = "5.0.1"
default['splunk']['forwarder_build']              = "143156"