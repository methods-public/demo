awscreds Cookbook CHANGELOG
===========================
This file is used to list changes made in each version of the awscreds cookbook.

## 1.0.2 (2017-08-31)

- Resolve Foodcritic warning in the metadata

## 1.0.1 (2017-04-11)

- Test with local delivery and not Rake
- Update apache2 license string
- Add supported platforms to the metadata

## 1.0.0 (2016-09-15)

- Testing updates
- Require Chef 12.1

# 0.1.0

Initial release.
