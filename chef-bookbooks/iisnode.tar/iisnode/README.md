# iisnode Cookbook
[![Build status](https://ci.appveyor.com/api/projects/status/github/AqoviaCookbooks/iisnode?branch=master&svg=true&retina=true)](https://ci.appveyor.com/project/AqoviaCookbooks/iisnode/branch/master)[![Cookbook Version](https://img.shields.io/cookbook/v/iisnode.svg)](https://supermarket.chef.io/cookbooks/iisnode)

# cookbook-iisnode
Chef cookbook for installing iisnode

## Attributes
* `node['iisnode']['desktop_iis_edition']: ` Set attribute to override default IIS Express selection for desktop windows versions: `full` or `express`. Default: `express`
