# Cookbook Name:: skype
# Recipe:: default

skype 'Install Skype' do
	action :install
end