# frozen_string_literal: true

name 'letsencryptaws_test'
