# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased]

## [1.0.0]
### Bug Fixes
- Fixes integration test harness using Test Kitchen.
- Squashes several issues while testing locally and on machines.

[Unreleased]: https://bbgithub.dev.bloomberg.com/chef/blp-base-cookbook/compare/v1.0.0...HEAD
[1.0.0]: https://bbgithub.dev.bloomberg.com/chef/blp-base-cookbook/compare/v1.0.0...HEAD
