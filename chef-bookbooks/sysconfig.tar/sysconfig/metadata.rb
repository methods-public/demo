name 'sysconfig'
maintainer 'Bloomberg L.P.'
maintainer_email 'acaiafa1@bloomberg.net'
license 'all_rights'
description 'Configures sysconfig'
long_description 'Configures sysconfig'
version '0.1.1'

supports 'centos', '>= 6.4'
supports 'redhat', '>= 6.4'

depends 'poise'
