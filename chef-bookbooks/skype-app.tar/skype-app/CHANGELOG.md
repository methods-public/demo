Skype App Cookbook CHANGELOG
============================

v0.3.0 (2016-03-02)
-------------------
- Bump apt dependency from 2.x to 3.x

v0.2.0 (2015-10-18)
-------------------
- Update provider resolver to use most current style
- Fix package installation failures in 64-bit Ubuntu due to the i386 arch not
  being enabled

v0.1.1 (2015-07-05)
-------------------
- Add missing 'ubuntu' to list of supported platforms

v0.1.0 (2015-07-05)
-------------------
- Initial release, with support for OS X, Windows, and Ubuntu

v0.0.1 (2015-06-30)
-------------------
- Development started
