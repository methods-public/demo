directory '/etc/chef/'
