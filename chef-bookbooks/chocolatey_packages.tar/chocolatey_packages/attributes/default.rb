default['chocolatey_packages']['source'] = 'https://chocolatey.org/api/v2'
default['chocolatey_packages']['ignore_failure'] = false
