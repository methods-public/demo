## 0.3.0 / 2013-06-28
First public release with test-kitchen.

