default['gkrellmd']['port'] = 19150
default['gkrellmd']['allowed_hosts'] = [] # allow all

