default['numpy']['ld_library_path'] = "/opt/atlas-3.10.2/lib"
