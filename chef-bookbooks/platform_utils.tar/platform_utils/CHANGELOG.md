platform_utils CHANGELOG
========================

0.4.4
-----
- improves the `platform_utils::kernel_modules` recipe.

0.4.3
-----
- adds the `platform_utils::sysctl` recipe.

0.4.2
-----
- adds the `platform_utils::kernel_modules` recipe.
- adds the `platform_utils::kernel_user_namespace` recipe.

0.4.1
-----
- adds the `PlatformUtils::VirtUtils` module.

0.4.0
-----
- adds the `platform_utils::crond` recipe.
- adds the `platform_utils::ntpd` recipe.
- adds the `platform_utils::tcp_wrappers` recipe.

0.3.2
-----
- adds the `['platform_utils']['subid']['notifies']` attribute.
- refactoring.

0.3.1
-----
- adds the `PlatformUtils::Helper.append_subusers` method.
- bug fix.

0.3.0
-----
- adds the `platform_utils::subid` recipe.

0.2.0
-----
- adds the `platform_utils::sudo` recipe.

0.1.2
-----
- adds the `['platform_utils']['platform_update']['timer']` attribute.

0.1.1
-----
- improves update command string validation.

0.1.0
-----
- Initial release of platform_utils