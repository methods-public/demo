default['docker_compose']['release'] = '1.8.0'
default['docker_compose']['command_path'] = '/usr/local/bin/docker-compose'