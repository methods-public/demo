#
# Cookbook Name:: docker_compose
# Recipe:: default
#
# Copyright (c) 2016 Sebastian Boschert, All Rights Reserved.

include_recipe 'docker_compose::default'