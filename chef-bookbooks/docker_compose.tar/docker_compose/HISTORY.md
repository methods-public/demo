# Release History

## vNEXT

## v0.1.1

* Added support for docker-compose's --remove-orphans parameter.
* The cookbook is now compatible with CentOS.
* Improved cookbook documentation.

## v0.1.0

* Initial release.

