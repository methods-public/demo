## Version 0.2.7
* Fix shellwords include for Chef 11.6+
* Improve apt-file cache updates under Ubuntu

## Version 0.2.6
* Repackage without bsdtar for greater compatibility

## Version 0.2.4

* Update integration tests to use test-kitchen 1.0
* Bugfix with apt/yum providers
* Add :package option to default resource

## Version 0.2.1

Initial release.
