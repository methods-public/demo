default['rustlang']['version'] = "1.0.0-alpha"
default['rustlang']['installation_prefix'] = '/opt'
