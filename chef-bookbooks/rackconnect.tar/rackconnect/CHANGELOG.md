# CHANGELOG for rackconnect

## 0.1.0:

* Initial release of rackconnect
