#
# Cookbook:: asf
# Recipe:: default
#
# Copyright:: 2017, Tyler Wong, All Rights Reserved.

include_recipe 'asf::mono'
include_recipe 'asf::service'
