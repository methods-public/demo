# frozen_string_literal: true

nssm 'service name' do
  action :remove
end
