include_recipe "mecab::ipadic"
