mecab Chef Cookbook CHANGELOG
========================

0.2.0 (Feb 25, 2015)
-----
- NAIST-JDIC support.

0.1.0 (Feb 19, 2015)
-----
- The initial release.
