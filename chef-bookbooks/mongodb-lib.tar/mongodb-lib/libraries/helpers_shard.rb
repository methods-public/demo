# frozen_string_literal: true

module MongoDBLibCookbook
  module MongoDBLibHelpers
    module MongodbShard
    end
  end
end
