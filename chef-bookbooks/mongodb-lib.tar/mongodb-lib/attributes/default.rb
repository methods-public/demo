# frozen_string_literal: true

default['mongodb']['lib']['version'] = '3.2.19'
