CopperEgg RevealCloud Agent
===========

This cookbook has been deprecated.  Please download the [chef-copperegg cookbook](https://github.com/CopperEgg/chef-copperegg).



Links
=====
* [CopperEgg Homepage](http://www.copperegg.com)
* [RevealCloud Signup](https://app.copperegg.com/signup)
* [RevealCloud Login](https://app.copperegg.com/login)


