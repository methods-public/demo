This cookbook is now up for adoption! Open an issue, or contact me in some way,
if you have any interest in taking over maintenance or development of this
cookbook.
