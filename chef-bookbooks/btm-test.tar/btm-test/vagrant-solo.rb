Chef::Config.ssl_verify_mode = :verify_peer
