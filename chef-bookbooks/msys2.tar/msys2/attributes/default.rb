default['msys2']['auto_update'] = true
default['msys2']['install_dir'] = 'C:/msys64'
default['msys2']['packages'] = []
default['msys2']['default_env'] = :msys
default['msys2']['verbose'] = true
default['msys2']['override_package'] = false
default['msys2']['override_execute'] = false
