microfocus cookbook CHANGELOG
=============================

3.0.0 (2016-10-05)
------------------
- Updated constraint for ark cookbook to ~> 2.0. version is now name_property. Removed default recipe.

2.1.2 (2016-04-27)
------------------
- Removed leading / from template resources source property.

2.1.1 (2016-04-22)
------------------
- Added Travis CI build status.

2.1.0 (2016-04-20)
------------------
- Updated microfocus_server_express resource to manually install init.d/systemd service.

2.0.1 (2016-04-17)
------------------
- Updated readme.

2.0.0 (2016-04-16)
------------------
- Refactored as resource cookbook.

1.0.0 (2015-06-30)
------------------
- Updated recipe.

0.1.0 (2015-05-10)
------------------
- Initial release.
