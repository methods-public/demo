# CHANGELOG for appveyor

This file is used to list changes made in each version of appveyor.

## 0.4.0

* Licence of cookbook change to MIT, and opensourced
* Foodcritic fixes

## 0.3.0

* Added ability to set deployment group

## 0.2.2

* Fixed incorrect reference to AppVeyor agent download

## 0.2.1:

* Fixed bug where non-existant attribute was referenced

## 0.2.0:

* Added checking to the recipe to ensure the agent isn't installed twice

## 0.1.0:

* Initial release of appveyor

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
