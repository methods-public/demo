chef_gem 'inspec' do
  version '1.19.1'
  action :nothing
end.run_action(:install)
