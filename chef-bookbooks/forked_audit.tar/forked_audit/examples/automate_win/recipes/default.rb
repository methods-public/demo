# encoding: utf-8
#
# Cookbook Name:: automate_win
# Recipe:: default

include_recipe 'automate_win::chef_client_config'
