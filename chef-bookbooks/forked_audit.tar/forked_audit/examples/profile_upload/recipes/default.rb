#
# Cookbook Name:: test-profiles
# Recipe:: default
#
# Copyright (c) 2016 The Authors, All Rights Reserved.

# package 'git'

include_recipe 'audit::upload'
