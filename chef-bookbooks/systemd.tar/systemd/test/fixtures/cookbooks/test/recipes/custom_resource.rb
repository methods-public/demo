test_file_toucher 'dummy' do
  time 'minutely'
  path '/tmp/dummy.txt'
end
