name 'test'
version '0.0.0'

depends 'systemd'
depends 'yum'
depends 'apt'
depends 'debian'
depends 'chef-sugar'
