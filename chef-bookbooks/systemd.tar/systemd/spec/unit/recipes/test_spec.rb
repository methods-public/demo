require 'spec_helper'

describe 'test::default' do
  context 'default' do

  end
end
