default['test_kitchen_mssql_helpers']['chef_client_user_password'] = 'vagrant'
default['test_kitchen_mssql_helpers']['sa_password'] = 'Vagrant!'
