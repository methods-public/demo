default['spigot']['current_version'] = 'latest'
default['minecraft']['version'] = 'latest'
default['minecraft']['jar_source'] = ''