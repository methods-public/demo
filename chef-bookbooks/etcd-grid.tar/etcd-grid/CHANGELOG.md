# etcd-grid CHANGELOG

0.1.2
-----
- refactoring.

0.1.1
-----
- refactoring.
- adds data persistent volumes.

0.1.0
-----
- Initial release of etcd-grid
