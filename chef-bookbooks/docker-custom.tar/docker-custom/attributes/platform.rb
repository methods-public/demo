default['docker-compose']['url']='https://github.com/docker/compose/releases/download/1.16.1/docker-compose'
#Binary location of where it will be installed
default['docker-compose']['bin']='/usr/local/bin/docker-compose'
