# These attributes are here only to demonstrate using attributes for authentication.
# This also provides a mechanism for a drop-in use of the contained resource,
# if desired for local development.
default['pertino']['example']['username'] = nil
default['pertino']['example']['password'] = nil
