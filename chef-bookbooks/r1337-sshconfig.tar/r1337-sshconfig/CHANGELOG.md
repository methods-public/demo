SSH Configuration - Changelog
==============
A list of all the changes made to this cookbook

Version 0.1.5
------------

1. Added testing to verify Ubuntu 18.04 support
2. Documentation fixes

Version 0.1.4
------------

1. metadata.rb has been changed to set 13.6.4 as the minimum chef-client version instead of the only version

Version 0.1.3
------------

1. Kitchen is now locked to testing on the version of Chef we use in production

Version 0.1.2
------------

1. Bringing documentation in line with Chef Supermarket Foodcritic expectations

Version 0.1.1
------------

1. Set `AllowTcpForwarding no` on the Hardened configuration

Version 0.1.0
------------

1. Initial Release
