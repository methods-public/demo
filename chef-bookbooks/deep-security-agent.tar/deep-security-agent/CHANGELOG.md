# Change Log

Please refer to [GitHub Deep-Security-Agent cookbook releases](https://github.com/deep-security/chef/releases) for complete change log.