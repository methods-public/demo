## deep-security-agent-test

This cookbook is for Deep Security Agent verification. For an agent deployment in a production environment, please refer to <a href="https://github.com/deep-security/chef/tree/master/deep-security-agent">deep-security-agent cookbook</a>.

