name 'deep-security-agent-test'
maintainer       'Trend Micro'
maintainer_email 'deepsecurityopensource@trendmicro.com'
license          'All rights reserved'
description      'Installs/Configures the Deep Security Agent'
long_description 'Cookbook to prepare for testing deep-security-agent'
version          '1.0.0'

