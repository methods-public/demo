default['soa_qs-12c']['version'] = "12.1.3"
default['soa_qs-12c']['url'] = "file:///data/oracle-fmw/soa_qs-12c/fmw_#{node['soa_qs-12c']['version']}.0.0_soaqs_Disk1_1of1.zip"
default['soa_qs-12c']['checksum'] = "3867ae18b12c"
