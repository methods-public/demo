default['bpm_qs-12c']['version'] = "12.1.3"
default['bpm_qs-12c']['url'] = "file:///data/oracle-fmw/bpm_qs-12c/fmw_#{node['bpm_qs-12c']['version']}.0.0_bpmqs_Disk1_1of1.zip"
default['bpm_qs-12c']['checksum'] = "dc0270122d52"
