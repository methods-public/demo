default['osb-11g']['installer_file'] = "ofm_osb_generic_11.1.1.7.0_disk1_1of1.zip"
default['osb-11g']['home_directory'] = "oracle_osb"
default['osb-11g']['checksum'] = "4f2f967fc2e33259e3fd03f7d34e9f3ab99cf359f9722b43537592aa0217c990"
default['osb-11g']['url'] = "" #"file:///data/oracle-fmw/osb-11g/ofm_osb_generic_11.1.1.7.0_disk1_1of1.zip"

#TYPICAL or CUSTOM
default['osb-11g']['installation_option'] = "TYPICAL"
