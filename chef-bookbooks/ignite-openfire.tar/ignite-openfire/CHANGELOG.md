# Ignite-Openfire Changelog

## 0.1.1
- Added support for hazel-cast plugin & confugration
- Added support for external databases
