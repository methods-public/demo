sbp_emet CHANGELOG
==================

This file is used to list changes made in each version of the sbp_emet cookbook.

0.1.0
-----
- Matthijs Wijers - Initial release of sbp_emet

0.1.2
-----
- Increment to EMET 5.51
-- Modified use of node attributes to handle MS's discrepancy between the packages name and its install directory

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
