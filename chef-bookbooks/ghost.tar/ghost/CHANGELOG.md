# 0.1.1

  * Enable submodule support for content repos

# 0.1.0

## Initial Release

  * Configurable version installs
  * Optional remote repo for content/theme customization
  * SQLite as the database
  * Test coverage with ServerSpec
  * Verified with Ghost 0.4.1, 0.4.2 on Ubuntu 12.04, CentOS 6.5
