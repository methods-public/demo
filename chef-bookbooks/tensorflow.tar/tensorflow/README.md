### Tensorflow Cookbook
Author: Jim Dowling

OS support: Ubuntu 16+, Centos 7+


Requirements for Vagrant installation: chefdk


##Vagrant Usage

Install chefdk (https://downloads.chef.io/chef-dk)

./run-vagrant.sh


## Karamel Usages



