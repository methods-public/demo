actions :cuda, :cdnn, :tf

attribute :name, :kind_of => String, :name_attribute => true


