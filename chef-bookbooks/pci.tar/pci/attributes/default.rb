# Initialize the pci namespace
default['pci']
