name             'wlp_test'
license          'Apache 2.0'
description      'Test cookbook for Liberty profile cookbook'

depends "wlp"
