default['buildkite']['apt']['repo'] = 'https://apt.buildkite.com/buildkite-agent'
default['buildkite']['apt']['releases'] = %w(stable main)
default['buildkite']['apt']['key'] = '32A37959C2FA5C3C99EFBC32A79206696452D198'
