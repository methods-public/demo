
#APC Attributes
default['jolicode-php']['apc']['config']['enabled']       = "1"
default['jolicode-php']['apc']['config']['shm_segments']  = "1"
default['jolicode-php']['apc']['config']['shm_size']      = "64M"
default['jolicode-php']['apc']['config']['max_file_size'] = "10M"
default['jolicode-php']['apc']['config']['stat']          = "1"
default['jolicode-php']['apc']['version']                 = "3.1.9"