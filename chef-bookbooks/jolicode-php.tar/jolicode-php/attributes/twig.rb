default['jolicode-php']['twig']['version']    = "-sstable"
default['jolicode-php']['twig']['source_dir'] = "/tmp"
default['jolicode-php']['twig']['download']   = true