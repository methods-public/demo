default['jolicode-php']['zmq']['version'] = "1.0.5"
default['jolicode-php']['zmq']['lib']     = "/usr/local"