name 'osx-basic'
version '0.0.1'

depends 'vsts_agent'
depends 'build-essential'
