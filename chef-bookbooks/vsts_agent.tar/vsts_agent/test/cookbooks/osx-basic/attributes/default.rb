# set vsts attributes through test kitchen
default['vsts_agent_test']['vsts_url'] = nil
default['vsts_agent_test']['vsts_pool'] = nil
default['vsts_agent_test']['vsts_token'] = nil
default['vsts_agent_test']['username'] = 'vagrant'
