name 'linux-basic'
version '0.0.1'

depends 'vsts_agent'

depends 'apt'
depends 'build-essential'
