Baseserver CHANGELOG
====================
This is the Changelog for the Baseserver cookbook.

v0.8.0 (2015-04-30)
- Add databag: user groups to user additional groups

v0.7.8 (2014-08-15)
-------------------
- Fix mailutils
- Add waffle.io badge


v0.7.7 (2014-06-14)
-------------------
- test with stove (could not bump to 0.7.6)


v0.7.5 (2014-06-14)
-------------------
- Add changelog
- use of https://github.com/sethvargo/stove: $ bake 0.7.5 --no-community
- Update user databag
- Add locales databag


v0.7.4 (2014-06-11)
-------------------
- replaced fatal with warn in users recipe
- update README
