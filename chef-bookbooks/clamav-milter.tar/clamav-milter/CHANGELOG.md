clamav-milter CHANGELOG
=======================

0.3.3
-----
- Stanislav Voroniy - Fix RHEL issues

0.3.2
-----
- Stanislav Voroniy - Fix README

0.3.1
-----
- Stanislav Voroniy - Initial public release of clamav-milter
