default['mattermost']['database'] = {
  'address' => 'dockerhost',
  'port' => 3306,
  'name' => 'mattermost_test',
  'username' => 'mmuser',
  'password' => 'mostest',
}
