TODO
====

* [ ] Add ramfs support.
