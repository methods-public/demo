# Parameters:

## Configuration:
default['logdna']['conf_key'] = nil
default['logdna']['conf_logdir'] = nil
default['logdna']['conf_logfile'] = nil
default['logdna']['conf_exclude'] = nil
default['logdna']['conf_config'] = nil
default['logdna']['conf_hostname'] = nil
default['logdna']['conf_tags'] = nil
default['logdna']['conf_exclude_regex'] = nil

## Agent State:
default['logdna']['agent_install'] = true
default['logdna']['agent_configure'] = true
default['logdna']['agent_service'] = :start
