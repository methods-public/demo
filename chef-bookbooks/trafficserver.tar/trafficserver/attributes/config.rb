# storage.config
default['trafficserver']['config']['storage'] = []

# volume.config
default['trafficserver']['config']['volume'] = {}
