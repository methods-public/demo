name 'setup'

depends 'hekad'
