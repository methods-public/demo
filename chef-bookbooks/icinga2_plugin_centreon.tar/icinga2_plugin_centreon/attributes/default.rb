default['icinga2_plugin_centreon']['nagios']['nagios_plugin_dir'] = '/usr/lib/nagios/plugins'

default['icinga2_plugin_centreon']['git']['repo_path'] = '/usr/local/src/icinga2_plugin_centreon_chef'
default['icinga2_plugin_centreon']['git']['repo_src_url'] = 'https://github.com/centreon/centreon-plugins.git'
default['icinga2_plugin_centreon']['git']['tag'] = '20171013'