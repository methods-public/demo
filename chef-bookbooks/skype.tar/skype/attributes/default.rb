default[:skype][:install_dir] = "/opt/skype"
default[:skype][:url] = "http://www.skype.com/go/getskype-linux-beta-static"
default[:skype][:temp_dir] = "/tmp"
default[:skype][:filename] = "skype.tar.bz2"
