slack CHANGELOG
===============

0.1.0
-----
- [Jason Rohwedder] - Initial release of slack
