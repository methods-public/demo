default[:slack][:team]         = nil
default[:slack][:api_key]      = nil
