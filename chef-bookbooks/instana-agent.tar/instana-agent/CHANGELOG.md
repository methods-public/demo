# instana-agent CHANGELOG

This file is used to list changes made in each version of the instana-agent
cookbook.

## 1.0.11
- Release to chef supermarket using stove via Jenkins

## 1.0.6
- Release to chef supermarket using stove

## 1.0.3
- Fix configuration.yaml parse error

## 1.0.2
- Updated the cookbook to comply with all of our recent feature requests and operational workflows.

## 1.0.0
- We switched to our new lb-backed agent source.

## 0.1.0
- Initial release of instana-agent
