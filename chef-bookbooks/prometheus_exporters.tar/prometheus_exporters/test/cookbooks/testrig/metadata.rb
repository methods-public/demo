name 'testrig'
version '1.0.0'
depends 'prometheus_exporters'
