## TL;DR

To run standart tests for this code please run:

`foodcritic -f any . && rubocop . && kitchen test`