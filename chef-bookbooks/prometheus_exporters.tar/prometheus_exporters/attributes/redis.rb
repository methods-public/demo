default['prometheus_exporters']['redis']['url'] = 'https://github.com/oliver006/redis_exporter/releases/download/v0.15.0/redis_exporter-v0.15.0.linux-amd64.tar.gz'
default['prometheus_exporters']['redis']['checksum'] = '170458f8c9e1588861b1584451cfc636b1339b4cf495f82396f03e474d6e626f'
