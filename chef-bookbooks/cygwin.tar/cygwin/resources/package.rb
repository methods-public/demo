actions :install, :uninstall
default_action :install
