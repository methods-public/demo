# 0.1.0

 * Initial release of ec2configservice
 * Installation of the latest EC2 config service
 * Wallpaper Settings config
