# CHANGELOG for zookeeper

0.1.1
-----
- refactoring.

0.1.0
-----
- Initial release of zookeeper
