0.1.0 (2013-09-29)
-----
* Initial release of cookbook-ajenti

0.1.0 (2013-09-30)
-----
* Adding README
* No needsetup.rb anymore