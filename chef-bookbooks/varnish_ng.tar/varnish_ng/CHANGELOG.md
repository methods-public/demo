varnish_ng CHANGELOG
====================

This file is used to list changes made in each version of the varnish_ng cookbook.

0.1.4
-----

- Virender Khatri - fixed typo for varnishncsa service action

- Virender Khatri - create storage/log dirs recursively

0.1.2
-----

- Virender Khatri - possibly fixed varnish 3.0 package install on amazon linux

0.1.1
-----
- Virender Khatri - initial release of varnish_ng

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
