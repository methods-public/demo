Zabbix Ruby Client Cookbook CHANGELOG
=====================================

## 0.0.12 - 2014-08-25
- [mose] better attributes management. check the readme.

## 0.0.11 - 2014-08-25
- [mose] `breaking change` transform tasks list from array to hash to it can be merged easier
- [mose] fix kitchen tests

## 0.0.10 - 2014-08-24
- [mose] fix on the `zrc.enable` syntax

## 0.0.9 - 2014-08-24
- [mose] add a `zrc.enabled` attribute to inhibit cron job
- [mose] ass a `zrc.repo_url` for development so a fork can be used for zabbix-ruby-client
- [mose] ass a `zrc.repo_branch` for development so an arbitrary branch can be used for zabbix-ruby-client

## 0.0.8 - 2014-08-23
- [mose] write tests using kitchen-docker
- [mose] make tests work on mac when using docker-osx
- [mose] refactor for centos compatibility
- [mose] first publication on the Supermarket

## 0.0.1 - 2014-08-20
- [mose] Initial preparation of the cookbook
