## 1.0.1

* minitest fixes

## 1.0.0

* Recipes for correctly installing (via archive or package) C++, Java, or Python per platform, platform_version, or if `node['protobuf']['install_type']` is set
* Remove package recipe (split recipes do better job)

## 0.1.2

* Default to archive install_type for Ubuntu 12.04

## 0.1.1

* Notify ldconfig immediately on archive install

## 0.1.0

* Initial release
