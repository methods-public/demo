## chef-gflags Compatibility ##

### Installation Compatibility ###

Cookbook compatibility based on platform and installation type (`node['protobuf']['install_type']`)

#### Archive ####

Cookbook Compatibility

CentOS 6 | Ubuntu 12.04 | Ubuntu 12.10 | Ubuntu 13.04 | Ubuntu 13.10
---------|--------------|--------------|--------------|-------------
0.1+     | 0.1+         | 0.1+         | 0.1+         | 0.1+

Test Matrix

CentOS 6 | Ubuntu 12.04 | Ubuntu 12.10 | Ubuntu 13.04 | Ubuntu 13.10
---------|--------------|--------------|--------------|-------------
0.1+     | 0.1+         | 0.1+         | 0.1+         | 0.1+


#### Package ####

Cookbook Compatibility

CentOS 6 | Ubuntu 12.04 | Ubuntu 12.10 | Ubuntu 13.04 | Ubuntu 13.10
---------|--------------|--------------|--------------|-------------
0.1+     | 0.1+         | 0.1+         | 0.1+         | 0.1+

Test Matrix

CentOS 6 | Ubuntu 12.04 | Ubuntu 12.10 | Ubuntu 13.04 | Ubuntu 13.10
---------|--------------|--------------|--------------|-------------
0.1+     | 0.1+         | 0.1+         | 0.1+         | 0.1+
