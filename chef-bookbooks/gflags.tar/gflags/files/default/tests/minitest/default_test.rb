require File.expand_path('../support/helpers', __FILE__)

describe_recipe "gflags::default" do
  include Helpers::Gflags
  
end
