# 0.1.1

[#6](https://github.com/osuosl-cookbooks/yum-cron/pull/6) Fix output_width configuation typo


# 0.1.0

Initial release of yum-cron
