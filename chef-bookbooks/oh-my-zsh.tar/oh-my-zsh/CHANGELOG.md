## oh-my-zsh cookbook CHANGELOG

This file is used to list changes made in each version of the on-my-zsh cookbook.

v0.4.4
-----
* Update to latest oh-my-zsh template
* Only install for users that have a home directory
* Updates to test-kitchen configuration for better testing
* CONTRIBUTING, CHANGELOG and CONTRIBUTING documents

v0.4.3
-----
* Current version. Initial CHANGELOG.
