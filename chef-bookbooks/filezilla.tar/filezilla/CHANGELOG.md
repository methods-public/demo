filezilla Cookbook CHANGELOG
========================

v1.4.0
--------------------
- Bumped client version to the latest release '3.14.1'
- Added Server install recipe (pull request) and bumped version to 0.9.54 (windows only)
- Serverspec tests added (pull request)

v1.3.3 (2015-09-25)
--------------------
- Bump Windows version to the latest release '3.14'

v1.3.2 (2015-07-10)
--------------------
- Now supports installs for Ubuntu and RHEL/CentOS
- Bump Windows version to the latest release '3.12.0.2'
- Added a Changelog
- Updates for the readme