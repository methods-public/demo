name 'elasticsearch-curator-test'
version '0.0.1'

depends 'elasticsearch-curator'
