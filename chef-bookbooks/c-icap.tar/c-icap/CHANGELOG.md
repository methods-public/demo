# CHANGELOG for c-icap

This file is used to list changes made in each version of c-icap.

1.0.0
-----
- Initial release of c-icap cookbook
