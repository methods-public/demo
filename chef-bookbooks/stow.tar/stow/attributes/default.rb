default['stow']['path'] = '/usr/local/stow'
default['stow']['target'] = nil
default['stow']['version'] = '2.2.0'
default['stow']['src_url'] = 'http://ftp.gnu.org/gnu/stow/stow-2.2.0.tar.gz'
default['stow']['rpm_url'] = nil
default['stow']['deb_url'] = nil
default['stow']['profile.d']['mode'] = nil