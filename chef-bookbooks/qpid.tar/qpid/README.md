Apache Qpid™ makes messaging tools that speak AMQP and support many languages and platforms.

AMQP is an open internet protocol for reliably sending and receiving messages. It makes it possible for everyone to build a diverse, coherent messaging ecosystem.

Supported
---------
- CentOS 6 (Tested on CentOS 6.5)

Links
-----
- http://qpid.apache.org/
