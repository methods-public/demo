name             'sqlce'
maintainer       'Joe Fitzgerald'
maintainer_email 'joe.fitzgerald@emc.com'
license          'Apache 2.0'
description      'Installs/Configures SQL CE 4.0 SP1'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.0.0'
supports         "windows"
depends          'windows'