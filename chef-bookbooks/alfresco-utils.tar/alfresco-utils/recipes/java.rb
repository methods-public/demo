include_recipe 'java::default'
