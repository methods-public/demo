default['vsts_build_agent']['xplat']['package_name'] = 'vsoagent-installer'
default['vsts_build_agent']['xplat']['package_version'] = 'latest'
default['vsts_build_agent']['xplat']['skip_vsoagent_installer'] = false
