nagios-grid CHANGELOG
=====================

0.1.3
-----
- adds the Debian 9 (stretch) support.
- adds the Ubuntu 17.04 support.

0.1.2
-----
- adds the `check_mem.pl` plugin support.

0.1.1
-----
- metadata update (supported OSs).

0.1.0
-----
- Initial release of nagios-grid
