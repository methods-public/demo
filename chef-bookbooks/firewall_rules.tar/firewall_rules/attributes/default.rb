default['firewall']['rules'] = []
default['firewall']['allow_vrrp'] = false