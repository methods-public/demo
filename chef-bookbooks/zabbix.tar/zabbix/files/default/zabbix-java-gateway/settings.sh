# Please see /etc/zabbix/zabbix_java_gateway.conf for the 
# main Zabbix java gateway settings.
