Spotify Cookbook CHANGELOG
==========================

v1.0.0 (2016-03-03)
-------------------
- Update to new repo key used for Ubuntu/Debian installs
- Bump apt dependency from 2.x to 3.x
- Forcibly install the xdg-utils dependency on Debian platforms
- Convert everything to Chef 12.5 custom resources

v0.1.0 (2015-05-26)
-------------------
- Initial release! Supports OS X, Windows, and Ubuntu/Debian!

v0.0.1 (2015-05-23)
-------------------
- Development started
