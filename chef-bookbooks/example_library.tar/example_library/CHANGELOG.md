# Change log

This file tracks and describes changes to `example_library`.

This project adheres to [semantic versioning 2.0][semver].

v0.1.2 (05-11-2016)

- Updates project organization, urls, and metadata
- Add change log information for v0.1.1

v0.1.1 (04-04-2106)

- Updates readme for clarity

v0.1.0 (04-04-2016)

- Creates `example_library`, demonstrating a library cookbook subclassing LWRPBase for its resource declarations

[semver]: http://semver.org/
