Cookbook exposing a LWRP to manage Java keystores with the ```keytool``` utility.

# Usage
See the ```test``` recipe for examples.

# Author

Author:: Jean-Francois Theroux (<me@failshell.io>)
