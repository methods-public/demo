[![Build Status](https://travis-ci.org/lipro-cookbooks/test-helper.svg?branch=master)](https://travis-ci.org/lipro-cookbooks/test-helper)

This is a cookbook for dumping chef node attributes to specific location to json formated file.

For more details see: http://jakshi.com/blog/2014/05/12/accessing-chef-attributes-in-serverspec-tests/
