Test Helper CHANGELOG
=====================

This file is used to list changes made in each version of the Test Helper cookbook.

1.2.0
-----

- Stephan Linz - add source_url in metadata (fix FC065)
- Stephan Linz - add issues_url in metadata (fix FC064)
- Stephan Linz - add chef_gem compile time compatibility for activesupport
- Stephan Linz - support ChefDK 0.16.28, use chef client 12.12.15
- Patrick Connolly - pin `activesupport` to "< 5.0.0", otherwise
  requires Ruby v2.2.2.

1.1.0
-----
- Stephan Linz - support ChefDK 0.10
- Stephan Linz - run integration tests on Travis CI
- Patrick Connolly - support ohai/automatic attribute

1.0.0
-----
- Stephan Linz - Initial release of Test Helper

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax)
for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/)
describes the differences between markdown on github and standard markdown.
