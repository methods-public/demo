yum-updatesd CHANGELOG
======================

This file is used to list changes made in each version of the yum-updatesd cookbook.

0.1.1
-----
- David Hofmann - Fixed Template Error

0.1.0
-----
- David Hofmann - Initial release of yum-updatesd

