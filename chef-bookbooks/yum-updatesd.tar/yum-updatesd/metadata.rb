name             'yum-updatesd'
maintainer       'None'
maintainer_email 'elmic11111@gmail.com'
license          'All rights reserved'
description      'Installs/Configures yum-updatesd'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.1'

supports 'redhat'
supports 'centos'
supports 'scientific'
supports 'amazon'
supports 'fedora'