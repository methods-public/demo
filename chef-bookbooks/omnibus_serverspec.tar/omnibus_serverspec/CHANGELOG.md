omnibus_serverspec CHANGELOG
============================

This file is used to list changes made in each version of the omnibus_serverspec cookbook.

0.1.1
-----
- [sawanoboly] upgrade serverspec default version to 1.0.0

0.1.0
-----
- [sawanoboly] - Initial release of omnibus_serverspec

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
