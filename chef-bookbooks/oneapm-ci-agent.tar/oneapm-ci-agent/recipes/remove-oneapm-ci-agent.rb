# Run this recipe to completely remove the oneapm-ci-agent
package 'oneapm-ci-agent' do
  action :purge
end
