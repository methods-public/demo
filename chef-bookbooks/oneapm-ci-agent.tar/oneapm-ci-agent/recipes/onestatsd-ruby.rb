#
# Cookbook Name:: oneapm-ci-agent
# Recipe:: onestatsd-ruby
#


gem_package 'onestatsd-ruby'
