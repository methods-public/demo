#
# Cookbook Name:: oneapm-ci-agent
# Recipe:: onestatsd-python
#


easy_install_package 'onestatsd-python'
