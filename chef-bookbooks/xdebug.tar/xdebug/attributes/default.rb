#
# Cookbook Name:: xdebug
# Attributes:: default
#
# Copyright 2014, Escape Studios
#

default['xdebug']['version'] = 'latest'
default['xdebug']['config_file'] = nil
default['xdebug']['web_server']['service_name'] = 'apache2'
default['xdebug']['directives'] = {}
