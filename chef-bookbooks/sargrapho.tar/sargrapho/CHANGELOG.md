sargrapho cookbook CHANGELOG
============================

This file is used to list changes made in each version of the sargrapho cookbook.

1.0.0
-----
- Initial relase of the SarGraphO cookbook.
