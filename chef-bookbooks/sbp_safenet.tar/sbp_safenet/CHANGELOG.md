# sbp_safenet CHANGELOG

## 0.1.3

- Add timeout option to windows_package resource

## 0.1.2

- Make Safenet optional

## 0.1.1

- Adding package checksum to the windows_package resource

## 0.1.0

- Initial release of sbp_safenet
