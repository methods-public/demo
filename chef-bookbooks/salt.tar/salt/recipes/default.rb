#
# Cookbook Name:: chef-salt
# Recipe:: default
#
# Copyright (C) 2016, Grant Ridder
# Copyright (C) 2014, Daryl Robbins
#
#
#
