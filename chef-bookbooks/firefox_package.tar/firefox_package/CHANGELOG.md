# 0.2.0
 - Fixed Windows support to allow for multiple installations of Firefox.
 - Added Chef Audit Mode Support
 - Added Travis CI support for Pull Requests and development work.

# 0.1.0

Initial release of firefox_package
