# Poise-Hoist Changelog

## v1.2.1

* Fix a logic error if you aren't using the data bag support.

## v1.2.0

* Support for reading attributes from data bags when configured via `node['poise-hoist']['data_bag']`.

## v1.1.0

* Add `node.chef_environment` shim for older cookbooks.

## v1.0.0

* Initial release!
