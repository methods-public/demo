
action :gems_install do
 inifile_gem = "inifile-2.0.2.gem"
end
