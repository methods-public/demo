#!/bin/bash
rm -rf vagrant*
rm -rf d2016*
rm Berksfile.lock
rm nohup.out
