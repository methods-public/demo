zhuangbility CHANGELOG
======================

This file is used to list changes made in each version of the zhuangbility cookbook.

v0.4.0 (2015-04-30)
--------------------
- [rx007] - Updated platforms.

v0.3.0 (2015-04-30)
--------------------
- [rx007] - Updated metadata again and added license.

v0.2.0 (2015-04-30)
--------------------
- [rx007] - Updated metadata.

v0.1.0 (2015-04-30)
--------------------
- [rx007] - Initial release of zhuangbility.
