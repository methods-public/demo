#
# Cookbook Name:: zhuangbility
# Recipe:: default
#
# Copyright 2015, rx007
#
# All rights reserved - Do Not Redistribute
#

execute "echo zhuangbility" do
  command "echo zhuangbility"
end