# teleport-cookbook
[![Build Status](https://img.shields.io/travis/johnbellone/teleport-cookbook.svg)](https://travis-ci.org/johnbellone/teleport-cookbook)
[![Code Quality](https://img.shields.io/codeclimate/github/johnbellone/teleport-cookbook.svg)](https://codeclimate.com/github/johnbellone/teleport-cookbook)
[![Cookbook Version](https://img.shields.io/cookbook/v/teleport.svg)](https://supermarket.chef.io/cookbooks/teleport)
[![License](https://img.shields.io/badge/license-Apache_2-blue.svg)](https://www.apache.org/licenses/LICENSE-2.0)

## Basic Usage
