name			 "vc2013"
maintainer       "PayScale"
maintainer_email "pscore@payscale.com"
license          "Apache 2.0"
description      "Installs Microsoft Visual C++ 2013 Redistributable Package"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.0.0"
supports         "windows"
depends          "windows", ">= 1.2.6"
