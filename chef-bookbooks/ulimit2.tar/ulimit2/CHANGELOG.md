ulimit2 CHANGELOG
================

This file is used to list changes made in each version of the ulimit2 cookbook.

0.1.0
-----
- [michael.m.morris@gmail.com] - Initial release of ulimit2 cookbook

0.1.1
-----
- [michael.m.morris@gmail.com] - Migrated to Berks 3.x, changed packaging process from tar to 'knife cookbook site share'

0.2.0
-----
- [michael.m.morris@gmail.com] - Changes to enable Chef 12 (should still be Chef 11 compliant!)
