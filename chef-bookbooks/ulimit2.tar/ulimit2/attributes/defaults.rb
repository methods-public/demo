default['ulimit']['conf_dir'] = '/etc/security/limits.d'
default['ulimit']['conf_file'] = '999-chef-ulimit.conf'
