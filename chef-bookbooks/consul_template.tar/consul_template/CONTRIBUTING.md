# Development

## Versioning
This module uses [Semantic Versioning](http://semver.org/).

## Branching
Please adhere to the branching guidelines set out by Vincent Driessen in this [post](http://nvie.com/posts/a-successful-git-branching-model/).