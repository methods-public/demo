Description
===========

This cookbook installs the Karamel agent (kagent), impelemented in python, that is responsible
for monitoring and managing services installed on the node.

It also provides utilities used by Hops cookbooks.


Usage
=====

curl -k -u kagent@sics.se:kagent https://localhost:8090/execute/run/vagrant/HDFS/datanode/hdfs



## Contributing

1. Fork it
2. Create your feature branch (`git checkout -b my-new-feature`)
3. Commit your changes (`git commit -am 'Added some feature'`)
4. Push to the branch (`git push origin my-new-feature`)
5. Create new Pull Request
