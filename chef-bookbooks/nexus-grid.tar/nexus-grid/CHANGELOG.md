# nexus-grid CHANGELOG

0.1.4
-----
- improves server key pair deployment.

0.1.3
-----
- includes the `ssl_cert::server_key_pairs` recipe automatically.

0.1.2
-----
- adds the Nexus 2 support.
- adds Concourse pipeline configurations.

0.1.1
-----
- adds a reverse proxy (nginx) service to the `nexus-grid::docker-compose` recipe.
- adds the SSL configuration feature by reverse proxy.

0.1.0
-----
- Initial release of nexus-gird
