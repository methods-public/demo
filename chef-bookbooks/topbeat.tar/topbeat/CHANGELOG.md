topbeat CHANGELOG
=================

This file is used to list changes made in each version of the topbeat cookbook.

0.1.7
-----

- Virender Khatri - #19, include yum-plugin-versionlock only for rhel

- Virender Khatri - updated kitchen spec

- Virender Khatri - updated beats version to 1.3.1

- Virender Khatri - restart topbeat service on package upgrade

0.1.6
-----

- Virender Khatri - fix for #18, failed to install pinned version on version change

0.1.5
-----

- Paul Morton - support version pinning in deb and yum repos

- Virender Khatri - updated travis to use ruby v2.2.2

- Virender Khatri - remove powershell cookbook dependency

- Virender Khatri - updated topbeat version to v1.3.0

- Virender Khatri - use cookbook yum-plugin-versionlock instead

0.1.3
-----

- Bob - adding support for windows

- Bob - add serverpec integration tests for all platforms

- Virender Khatri - bump beats version to v1.2.3

0.1.2
-----

- Virender Khatri - Fixed README typo

0.1.1
-----

- Jose Alberto - bump version to 1.0.0-rc2 adn new defult config

- Virender Khatri - #3, added travis ci

- Virender Khatri - #5, update package download url to auto

- Virender Khatri - #8, fix kitchen test

- Virender Khatri - #4, added specs

- Virender Khatri - #9, added source url. issue url, platforms metadata

- Virender Khatri - #7, added repository package install


0.1.0
-----
- Virender Khatri - Initial release of topbeat

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
