#
# Cookbook: blp-nrpe
# License: Apache 2.0
#
# Copyright 2015-2017, Bloomberg Finance L.P.
#

class FalseClass; def to_i; 0; end end
class TrueClass; def to_i; 1; end end
