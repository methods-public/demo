# Changelog

## 2.0.0 - 2016-10-01

- Drop support for Chef 11
- Add support for proxy

## 1.2.2 - 2016/08/16

- Fix #6 Updated chromedriver_powershell_version to access stdout property

## 1.2.1 - 2016/01/29

- Fix #3 Chef::Exceptions::InvalidRemoteFileURI

## 1.2.0 - 2015/11/30

- Default ChromeDriver version to LATEST_RELEASE

## 1.1.0 - 2015/10/15

- ChromeDriver release 2.20

## 1.0.0 - 2015/09/12

- Initial release
