# hello world attributes
default[:hello_world][:name] = "World"