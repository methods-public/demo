## 1.0.0 (June 22, 2016)
  - Add support for Winlogbeat version 5.x.x.

## 0.1.1 (June 14, 2016)
  - Fix package full path to Windows style.

## 0.1.0 (June 7, 2016)
  - Initial version of cookbook. See `README.md`.
