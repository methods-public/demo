node.default['hprest']['http_proxy'] = nil
node.default['hprest']['https_proxy'] = nil