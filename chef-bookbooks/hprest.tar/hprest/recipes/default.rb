#
# Cookbook Name:: hprest
# Recipe:: default
#
# Copyright (c) 2016 All Rights Reserved.

include_recipe "hprest::install"
include_recipe "hprest::service"