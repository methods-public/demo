# Author:: Philip Oliva (<philoliva8@gmail.com>)
# Cookbook Name:: zabbix-agent
# Recipe:: install_skip
#
# Apache 2.0

log 'Skip the installation of zabbix agent' do
  level :info
end
