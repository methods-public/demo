## 0.1.1 / 2013-06-17
Depend on yum cookbook.

## 0.1 / 2013-06-12
Initial release.
