# Description

This cookbook installs [Siege](http://www.joedog.org/siege-home/).

# Requirements

This cookbook is compatible with CentOS, RedHat, Ubuntu and Gentoo.
On CentOS and RedHat, it requires the [yum](https://github.com/opscode-cookbooks/yum) cookbook.


# Usage

Just include `recipe[siege]` in your run_list.

# License

Copyright:: Locomote Pty Ltd.

Licensed under BSD license.

    http://opensource.org/licenses/BSD-2-Clause
