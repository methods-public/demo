actions :merge
default_action :merge

attribute :options, 
  kind_of: Hash,
  required: true

