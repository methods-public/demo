# CHANGELOG for beaver

This file is used to list changes made in each version of beaver.

## 1.1.0:

* Jeff Ramnani added a great LWRP for tail logs
* The whole configuration changed to a way more flexible approach that will allow future configuration options in the cookbook without any adjustments (that is the reason for the major version bump too)

## 0.1.0:

* Initial release of beaver

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
