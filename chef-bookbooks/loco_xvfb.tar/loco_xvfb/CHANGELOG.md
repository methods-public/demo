## 0.3.0 / 2013-06-11

Implement test-kitchen shpec tests, release as `loco_xvfb`.
