twindb-agent Cookbook CHANGELOG
===============================
This file is used to list changes made in each version of the twindb-agent cookbook.

v0.3.0
------
- Updated to support the new repository and the TwinDB agent v1.0.2-1

v0.2.6
------
- Fix issues reported by foodcritic

v0.2.5
------
- First release
