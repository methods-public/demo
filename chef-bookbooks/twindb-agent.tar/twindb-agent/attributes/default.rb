#
# Cookbook Name:: twindb-agent
# Attributes:: default
#

# Production registration code for agent
default["twindb_agent"]["registration_code"] = nil

# Production dispatcher
default["twindb_agent"]["dispatcher"] = "dispatcher.twindb.com"

# Staging dispatcher
# default["twindb_agent"]["dispatcher"] = "dispatcher.staging.twindb.com"
