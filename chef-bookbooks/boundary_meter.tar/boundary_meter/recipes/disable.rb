service 'boundary-meter' do
  action [:stop, :disable]
end
