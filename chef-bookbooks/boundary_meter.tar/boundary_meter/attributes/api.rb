default[:boundary][:api][:hostname] = "api.boundary.com"
default[:boundary][:api][:org_id] = "org_id"
default[:boundary][:api][:key] = "api_key"
default[:boundary][:hostname] = node[:fqdn]
