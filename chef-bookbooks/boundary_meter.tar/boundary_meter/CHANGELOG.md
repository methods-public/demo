v0.2.3
------
- Fixed bug that caused install_linux.rb to crash if tag attrib is blank

v0.2.2
------
- Cleaned up metadata.rb and changed license

v0.2.1
------
- Added rest of attributes to README

v0.2.0
------
- Initial release
