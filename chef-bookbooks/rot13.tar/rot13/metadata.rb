name              "rot13"
version           "1.0.0"

maintainer        "Fletcher Nichol"
maintainer_email  "fnichol@nichol.ca"
license           "Apache 2.0"
description       "A super secure rot13 Chef cookbook, you know, cause it had to be done."

supports "ubuntu"
supports "centos"
