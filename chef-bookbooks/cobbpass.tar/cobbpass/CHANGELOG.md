cobbpass CHANGELOG
==================

This file is used to list changes made in each version of the cobbpass cookbook.

1.0.1
-----
- manage\_home enabled on user, for creating a home using skel

1.0.0
-----
- Initial release of cobbpass
