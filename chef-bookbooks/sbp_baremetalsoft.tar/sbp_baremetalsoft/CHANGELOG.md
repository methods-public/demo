sbp_baremetalsoft CHANGELOG
===========================



0.1.0
-----
- Sander van Harmelen / Ane van Straten - Initial release of baremetalsoft
