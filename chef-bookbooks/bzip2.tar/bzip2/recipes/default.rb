#
# Cookbook Name:: bzip2
# Recipe:: default
# License:: Apache 2.0 (see http://www.apache.org/licenses/LICENSE-2.0)
#
package 'bzip2'
