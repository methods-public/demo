# Encoding: utf-8
#
# Cookbook Name:: gpg
# Recipe:: default
#
# Copyright 2014, YOUR_COMPANY_NAME
#
package 'gnupg2'
