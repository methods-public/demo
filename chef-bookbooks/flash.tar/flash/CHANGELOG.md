# CHANGELOG

## 2.0.0

- Enable Internet Explorer Flash Player on Windows Server

## 1.0.0

- Initial release
