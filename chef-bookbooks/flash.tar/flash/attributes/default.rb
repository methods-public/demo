default['flash']['download_url'] = 'https://fpdownload.adobe.com/get/flashplayer/pdc'
default['flash']['version'] = '20.0.0.267'

default['flash']['ie'] = true
default['flash']['npapi'] = true
default['flash']['ppapi'] = true

default['flash']['trust'] = []
default['flash']['mms_cfg'] = {}
