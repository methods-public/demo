# Changelog for Atom cookbook

## 0.2.0
* Add support for Mac OS X
* On Debian/Ubuntu install package instead of just setting up Atom apt ppa repo
* On Windows, install package directly instead of using Chocolatey
* Add specs and integration tests
