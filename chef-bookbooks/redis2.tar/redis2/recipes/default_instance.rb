# Default instance of redis.
#
include_recipe "redis2"
redis_instance "prime"
