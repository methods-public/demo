default["redis2"]["source"]["url"] = "http://download.redis.io/releases/redis-2.8.6.tar.gz"
default["redis2"]["source"]["checksum"] = "efd0c9cb8d2696db44d8cb8309fed96607f68b93bb126615e64bff364e716658"
default["redis2"]["source"]["version"] = "2.8.6"
