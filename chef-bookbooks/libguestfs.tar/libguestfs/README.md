# libguestfs cookbook

Installs libguestfs and optionally development libraries and various language
bindings.

# Recipes

## default

Installs guestfs libraries and tools

## dev

Installs guestfs development libraries

## erlang

Installs guestfs erlang bindings

## python

Installs guestfs python bindings

## ruby

Installs guestfs ruby bindings

# Author

Author:: Engine Yard, Inc. (<cookbooks@engineyard.com>)
