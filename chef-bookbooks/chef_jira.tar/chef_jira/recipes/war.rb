jira_war node['jira']['install_path']
