jira_war node['jira']['install_path'] do
  action :build
end
