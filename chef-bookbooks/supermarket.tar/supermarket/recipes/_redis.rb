# Redis is required for Sidekiq

include_recipe 'redisio'
include_recipe 'redisio::enable'
