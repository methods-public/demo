#
# Cookbook Name:: corosync
# Recipe:: default
#
# Copyright (c) 2016 Petr Belyaev <upcfrost@gmail.com>
#

# Install package
package 'corosync'
