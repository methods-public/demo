Contribution Guidelines
-----------------------

Feel free to

 * open issues 
 * fork
 * send pull request (based on a custom branch, not master)!

Please 

 * for bug reports: provide sufficient information about how to reproduce troubles.
 * for pull request: All test-kitchen integration tests should pass

