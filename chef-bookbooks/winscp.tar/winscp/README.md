# winscp'

Chef cookbook for downloading and installing WinSCP
