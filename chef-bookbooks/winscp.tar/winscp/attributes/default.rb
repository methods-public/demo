default['winscp']['version'] = '575'
default['winscp']['url'] = "http://prdownloads.sourceforge.net/winscp/winscp#{default['winscp']['version']}setup.exe?download"
default['winscp']['package_name'] = "WinScp version #{default['winscp']['version']}"
default['winscp']['install_path'] = 'C:\\WinScp'
default['winscp']['log_path'] = 'C:\\Temp'

