package 'mksh' do
  action :upgrade
end
