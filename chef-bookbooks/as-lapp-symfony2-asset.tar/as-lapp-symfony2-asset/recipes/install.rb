
include_recipe '::default'
include_recipe 'as-symfony2::install'
include_recipe 'as-asset::install'
