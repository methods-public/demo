#
# Cookbook Name:: as_lapp_symfony2_asset
# Recipe:: default
#
# Copyright 2015, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#

# include_recipe 'as-lapp::default'


include_recipe 'as-apache2::default'
include_recipe 'as-php::default'
include_recipe 'as-postgresql::default'
# include_recipe 'as-symfony2::create'
# include_recipe 'as-asset::create'
