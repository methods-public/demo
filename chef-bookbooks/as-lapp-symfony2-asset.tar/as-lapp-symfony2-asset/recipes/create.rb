
include_recipe '::default'
include_recipe 'as-symfony2::create'
include_recipe 'as-asset::create'
