jolokia-jvm-agent CHANGELOG
===========================

This file is used to list changes made in each version of the jolokia-jvm-agent cookbook.

0.1.0
-----
- [hirocaster] - Initial release of jolokia-jvm-agent

0.1.1
-----
- [fishnix] - Add basic unit and integration tests
- [fishnix] - Minor style fixes, add Berksfile, .gitignore
- [fishnix] - Upgrade to 1.3.2
- [hirocaster] - Add license

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
