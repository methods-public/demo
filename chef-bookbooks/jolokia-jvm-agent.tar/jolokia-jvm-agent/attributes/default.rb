default['jolokia-jvm-agent']['version'] = '1.3.2'
default['jolokia-jvm-agent']['dir'] = '/opt/jolokia'
