# CHANGELOG

--------------------------------------------------------------------------------

## v1.0.0
Initial release of artifactory_pro by Monkeylittle
