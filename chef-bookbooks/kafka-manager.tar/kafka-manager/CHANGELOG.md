# 0.1.3
Fixes bug where wouldn't restart service

# 0.1.2
Manages init script to work around issue https://github.com/yahoo/kafka-manager/issues/13#issuecomment-160996849

# 0.1.1
Updates metadata for supermarket

# 0.1.0
Initial Release
