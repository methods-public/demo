Box Sync Cookbook CHANGELOG
===========================

v1.0.0 (2015-12-10)
-------------------
- Convert to Chef custom resources (breaking compatibility with Chef < 12.5)
- Update package download URLs

v0.1.0 (2015-06-07)
-------------------
- Initial release! Supports OS X and Windows!

v0.0.1 (2015-06-01)
-------------------
- Development started
