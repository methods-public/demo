default['aws-ec2-snapshot']['instance_uses_iam_role'] = true
default['aws-ec2-snapshot']['aws_access_key_id'] = nil
default['aws-ec2-snapshot']['aws_secret_access_key'] = nil
default['aws-ec2-snapshot']['region'] = nil
default['aws-ec2-snapshot']['days_to_keep_snapshot'] = 7
