aws-ec2-snapshot CHANGELOG
==========================

1.0.0
-----
- Jason Boeshart - Initial release of aws-ec2-snapshot

1.0.1
-----
- Jason Boeshart - Added details for Chef Supermarket in metadata.rb
