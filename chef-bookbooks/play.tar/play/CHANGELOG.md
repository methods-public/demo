# Changelog

## 2.0.0 2016-08-15

- Change resource_name default from servicename to source 
- Default servicename to project_name when not defined 
- Create user and group using servicename when not defined
- Remove default recipe
- Support systemd
- Update upstart script
- Update systemv script
- Remove ark cookbook dependency

## 1.0.2 2016-04-01

- Fix #2 Exploded standalone distribution results in undefined method '[]' for nil:NilClass error 

## 1.0.1 2015-12-11

- Suppress FC021: Resource condition in provider may not behave as expected

## 1.0.0 2015-12-07

- Initial release
