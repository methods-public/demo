TODO
====

* [ ] Complete the **dovecot-dict-auth.conf.ext.erb** template.
* [ ] Add unit tests for libraries.
* [ ] Install from sources.
* [ ] Integrate with `ssl_certificate` cookbook?
