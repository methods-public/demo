name             'windows_network'
maintainer       'Proxmea BV'
maintainer_email 'chris@proxmea.com'
license          'Apache license v2.0'
description      'Configures windows network interfaces'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.3.0'

supports 'windows'
