# 1.0.4
* fixed serverspec OS detection
* getting md5 hash of user password moved to library

# 1.0.3
* fixed tests to run against serverspec v2

# 1.0.2
* changed url where to download poweradmin
* added support for centos7 and debian6

# 1.0.1
* added apache port selection via attributes
* added digitalocean support for API v2
* fixed critical php5 dependency
* fixing foodcritic FC002 warning
* added travis-ci integration

# 1.0.0
Initial release of poweradmin
