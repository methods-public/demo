default['yum-ius']['repos'] = %w(
  ius
  ius-debuginfo
  ius-source
  ius-archive
  ius-archive-debuginfo
  ius-archive-source
  ius-testing
  ius-testing-debuginfo
  ius-testing-source
  ius-dev
  ius-dev-debuginfo
  ius-dev-source
)
