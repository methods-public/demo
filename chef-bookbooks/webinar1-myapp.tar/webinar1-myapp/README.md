# Chef Webinar #1

Setup the sample application hosted on Google Cloud Platform.

For complete details visit [Chef Webinar #1 - Getting Started][webinar1-site].

If you would like to use local development with this please look at the [Developer doc][developer].


[webinar1-site]: https://github.com/nelsonjr/chef-webinars/tree/master/getting-started
[developer]: ./DEVELOPER.md
