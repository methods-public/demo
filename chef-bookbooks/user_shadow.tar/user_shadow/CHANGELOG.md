user_shadow CHANGELOG
==================
0.1.5
-----
- Fixed Rubocop errors
- Fixed circleci ssh key issue
- Added Gemfile.lock to repo
- Changed CentOS 6.6 to 6.7 in unit tests

0.1.4
-----
- CentOS support on 6.7 instead of 6.6

0.1.3
-----
- Fix for Rubocop tests

0.1.2
-----
- Updated README

0.1.1
-----
- Corrected the cookbook description

0.1.0
-----
- Converted the resource to HWRP

0.0.1
-----
- First version
