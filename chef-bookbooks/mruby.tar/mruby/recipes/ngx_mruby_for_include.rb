## This recipe should use with nginx cookbook(chef_community)
## add this to run_list and set to 'mruby::ngx_mruby' node['nginx']['source']['modules'] for include ngx_mruby module.
