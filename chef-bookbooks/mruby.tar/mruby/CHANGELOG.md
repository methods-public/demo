mruby CHANGELOG
===============

This file is used to list changes made in each version of the mruby cookbook.

0.4.1
----

- use run_state for nginx_mruby

0.4.0
----

- add cookbook depends nginx, apache2.
- support mod_mruby

0.3.2
-----

- Bugfix: forget install ngx_mruby...

0.3.1
-----

- feature: ngx_mruby module helper

0.3.0
-----

- feature: support user gems
- feature: support force_rebuild

0.2.1
-----

- bug: use system ruby crash by \n

0.2.0
-----

- Feature: Support CentOS
- add link mirb, mrbc
- flag: use ruby which includes omnibus-chef

0.1.0
-----

- Initial release of mruby cookbook

