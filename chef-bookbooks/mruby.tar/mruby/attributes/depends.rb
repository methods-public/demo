default[:mruby][:depend_pkgs] = [
  'git',
  'rsync'
]
