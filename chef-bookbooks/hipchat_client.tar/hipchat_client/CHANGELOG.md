CHANGELOG
=========

This file is used to list changes made in each version of the hipchat_client cookbook.

1.3.0
-----
- Update installation source URLs

1.1.4
-----
- Upgrade HipChat version on Mac to 2.5.4

1.1.2
-----
- Upgrade HipChat version on Mac

1.1.0
-----
- Added Linux client support

1.0.0
-----
- Initial release
