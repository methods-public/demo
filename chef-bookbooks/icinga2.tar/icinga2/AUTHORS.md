icinga2 Cookbook Contributors
=================

This file is used to maintain a list of Contributors.

- Andrei Scopenco <AScopenco@parallels.com>
- Frederik Thuysbaert & Steven De Coeyer <pair@openminds.be>
- Gerhard Sulzbe <ges@runtastic.com>
- Jörg Herzinger <joerg.herzinger@bytesource.net>
- Jannik Zinkl
- Marcel Beck <fo3nik5@gmail.com>
- Martin Stiborsky <martin.stiborsky@gmail.com>
- Steven De Coeyer <git@stevendecoeyer.be>
- Virender Khatri <vir.khatri@gmail.com>
