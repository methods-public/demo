# Encoding: utf-8
default['logstash']['source']['repo'] = 'git://github.com/logstash/logstash.git'
default['logstash']['source']['sha'] = nil
default['logstash']['source']['java_home'] = '/usr/lib/jvm/java-6-openjdk/' # openjdk6 on ubuntu
