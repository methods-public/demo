# Encoding: utf-8
#
# Cookbook Name:: logstash
# Recipe:: default
#
