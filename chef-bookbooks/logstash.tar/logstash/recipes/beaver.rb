# Encoding: utf-8
#
# Cookbook Name:: logstash
# Recipe:: beaver
#
#

include_recipe 'poise-python::default'
include_recipe 'beaver::default'
