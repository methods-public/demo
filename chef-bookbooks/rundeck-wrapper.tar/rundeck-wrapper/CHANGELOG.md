Changelog
=========

1.1.0
-----

Main:

- disable useless "api check" that execute at each run
- do not create user without rundeck password

1.0.0
-----

- Initial version with centos support
