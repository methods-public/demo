{
  id: 'user1',
  rundeck_password: {
    encrypted_data: "f6YoM5GvJ45yfCKaw6D9vIumEjC1+N/H8l+iZA==\n",
    iv: "UF9vG8ep0+qF+HVg\n",
    auth_tag: "9DvgOk+4E0L9GYtAtTNSuQ==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  },
  groups: {
    encrypted_data: "NoW5koDfClXEMZXFjjTTF7TAp9u3fiAme5/t\n",
    iv: "NBwkHTuU1LY0J78R\n",
    auth_tag: "YiRJYmw2c3XU7EQBe5KJqA==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  }
}
