{
  id: 'admin',
  rundeck_password: {
    encrypted_data: "7u8t0/PxXsYs6elA4hkHgnv3v4o9a091FKVQ\n",
    iv: "k5nZU8mZMTtvQE5L\n",
    auth_tag: "oiEaD8czoe1MiaQ2SuADTA==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  },
  groups: {
    encrypted_data: "OlZr0CW4lvo6WDu8fhDXkZoFtEbVT8G1hfg=\n",
    iv: "w0f1tOqFqO2yO83k\n",
    auth_tag: "Xn83vzb3uEbggg7rsnCBTA==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  }
}
