{
  id: 'user2',
  rundeck_password: {
    encrypted_data: "c9CqM7lILogPEVe2igq9b8Pi9Vujlx4ghAZw4g==\n",
    iv: "hhc4tAsCamTCMfm4\n",
    auth_tag: "rw7UUfofBJ4hEylEUuwEkQ==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  },
  groups: {
    encrypted_data: "6p2hsimVGDwe84eDpmX8QIOtzVAxTgjiqgxJ\n",
    iv: "Hr+C8b9B0d7DvUYK\n",
    auth_tag: "UbzQw6gizHrdDWrWnaAugw==\n",
    version: 3,
    cipher: 'aes-256-gcm'
  }
}
