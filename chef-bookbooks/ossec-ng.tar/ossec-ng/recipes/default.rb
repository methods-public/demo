#
# Cookbook Name:: ossec
# Recipe:: default
#
include_recipe "ossec-ng::agent"

