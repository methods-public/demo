# 1.0.2

Update a LICENSE file to `Apache 2.0` as it should be.

# 1.0.1

Resolve Foodcritic Error `FC002`

# 1.0.0

Initial release of suhosin