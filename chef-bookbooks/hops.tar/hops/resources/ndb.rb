actions :install_hops, :install_ndb_hops

attribute :base_filename, :kind_of => String

default_action :install_hops


