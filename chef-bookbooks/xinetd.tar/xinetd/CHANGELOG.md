# 1.0.1

* Load template from xinetd cookbook unless explicitly overridden.
* Fix foodcritic errors and add basic TravisCI configuration
