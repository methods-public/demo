default['sysctl']['conf_dir'] = '/etc/sysctl.d'
default['sysctl']['conf_file'] = '999-chef-sysctl.conf'
