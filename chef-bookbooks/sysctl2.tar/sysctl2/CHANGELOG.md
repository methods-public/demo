sysctl2 CHANGELOG
=====================

This file is used to list changes made in each version of the sysctl2 cookbook.

0.1.0
-----
- [michael.m.morris@gmail.com] - Initial release of sysctl2 cookbook

0.1.1
-----
- [michael.m.morris@gmail.com] - Moved bundle process from tar to 'knife cookbook site share'

0.2.0
-----
- [michael.m.morris@gmail.com] - Updates to enable Chef 12 support (should still be Chef 11 compliant!)
