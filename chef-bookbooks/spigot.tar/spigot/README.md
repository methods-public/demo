# Spigot Cookbook

A cookbook for Spigot that goes beyond traditional Minecraft server configuration and adds support for deploying and configuring various mods.

Simply clone the repository, edit the node `attributes` to your liking, and run `vagrant up` to get a working Spigot server without the hassle of configuration.

Remember to either bridge the connection or forward port 25565 to let other players join.
