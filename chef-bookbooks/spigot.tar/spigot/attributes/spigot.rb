
node.default['spigot']['directory'] = "/srv/minecraft"
node.default['spigot']['download'] = "http://getspigot.org/spigot18/spigot_server.jar"

node.default['ops'] = [
  {
    "name" => "",
    "UUID" => ""
  }
]

node.default['white-list'] = [
  {
    "username" => "",
    "UUID" => ""
  }
]

node.default['banned-players'] = [
  {
    "username" => "",
    "UUID" => ""
  }
]

node.default['banned-ips'] = [
  {
    "username" => "",
    "UUID" => ""
  }
]
