#
# Cookbook Name:: maven
# Recipe:: default
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'chef-maven::install'
