# chef-maven CHANGELOG

This file is used to list changes made in each version of the maven cookbook.

## 0.2.6
- Add travis tests

## 0.2.5
- Fix FC066

## 0.2.4
- added TESTING.md file

## 0.2.3
- added test cases, code cleanup

## 0.2.2
- added license, Contributiion details

## 0.2.1
- code cleanup

## 0.2.0
- Added support for Centos

## 0.1.0
- Initial release
