rrdtool CHANGELOG
=================

This file is used to list changes made in each version of the rrdtool cookbook.

0.2.0
-----

- Virender Khatri - added rrdcached init scripts for debian platform family

- Virender Khatri - added node attribute for packages install

- Virender Khatri - added rrdcached package

0.1.7
-----

- Virender Khatri - rrdcached setup is optional now

- Virender Khatri - disabled knife temporarily in favour of travis


0.1.4
-----

- Virender Khatri - added deb family packages

- Virender Khatri - corrected typo for rrdcached -j option

- Virender Khatri - added service notify for files / templates

- Virender Khatri - added travis files


0.1.0
-----

- Virender Khatri - Initial release of rrdtool


- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
