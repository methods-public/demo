Changelog
=========

1.0.0
-----

Main:

- Initial version with Centos support
  + Manage both server and client configuration
