# frozen_string_literal: true

{
  id: 'user2',
  vpn: true
}
