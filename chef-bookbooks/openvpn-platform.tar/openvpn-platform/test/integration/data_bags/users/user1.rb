{
  id: 'user1',
  vpn: true
}
