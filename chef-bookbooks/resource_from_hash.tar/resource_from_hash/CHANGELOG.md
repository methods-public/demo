# 0.1.5
[#10](https://github.com/osuosl-cookbooks/resource_from_hash/pull/10) Add support
for hash attributes


# 0.1.0

Initial release of resource_from_hash
