#
# Cookbook: opentsdb
# License: Apache 2.0
#
# Copyright 2015-2016, Bloomberg Finance L.P.
#

default['opentsdb']['service_name'] = 'default'
