auditbeat CHANGELOG
==================

This file is used to list changes made in each version of the filebeat cookbook.

0.0.2
-----

- Virender Khatri - first commit

0.0.1
-----

- Unreleased
