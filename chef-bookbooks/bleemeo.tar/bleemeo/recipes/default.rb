#
# Cookbook Name:: bleemeo
# Recipe:: default
#

include_recipe 'bleemeo::install'
