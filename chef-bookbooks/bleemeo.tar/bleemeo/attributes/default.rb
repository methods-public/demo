default['bleemeo']['account'] = nil
default['bleemeo']['key'] = nil

default['bleemeo']['auto-upgrade'] = false

default['bleemeo']['tags'] = ['chef-client']

default['bleemeo']['stack'] = nil
