ssl\_helper Cookbook
===========
This cookbook designed to work with certificates/keyfiles in encrypted data bags/

Requirements
------------
No additional requirements

Attributes
----------
* ssl\_helper::default
<table>
  <tr>
    <th>Key</th>
    <th>Type</th>
    <th>Description</th>
    <th>Default</th>
  </tr>
  <tr>
    <td><tt>default[:ssl][:certificates][:data_bag] = "certificates"</tt></td>
    <td>String/td>
    <td>Choose which data bag to use</td>
    <td><tt>certificate</tt></td>
  </tr>
</table>

Usage
-----
* ssl\_helper::default

`
This resource will install secret.pem with contents from encrypted data_bag : certificates/security.com
ssl_helper_ssl_pem "/etc/secret.pem" do
  owner "root"
  group "root"
  mode 0400
  cn "security.com"
end

This entry will install ca.crt with contents from encrypted data_bag : certificates/authority.com
ssl_helper_ssl_ca_certificate "/etc/ca.crt" do
  owner "root"
  group "root"
  mode 0644
  authority "authority.com"
end

This entry will install secret.crt with contents from encrypted data_bag : certificates/mycert.com to /etc/secret.crt.
Also it will install secret.com.key to /etc/secret.com.key with content from encrypted data_bag : certificates/mycert.com
ssl_helper_ssl_ca_certificate "/etc/secret.crt" do
  owner "root"
  group "root"
  mode 0644
  cn "mycert.com"
  key "/etc/secret.com.key"
end

This entry will install security.crt with contents from encrypted data_bag : certificates/security.com to /etc/security.crt
ssl_helper_ssl_ca_certificate "/etc/security.crt" do
  owner "root"
  group "root"
  mode 0644
  cn "security.com"
end

`

Contributing
------------
1. Fork the repository on Github
2. Create a named feature branch (like `add_component_x`)
3. Write you change
4. Write tests for your change (if applicable)
5. Run the tests, ensuring they all pass
6. Submit a Pull Request using Github

License and Authors
-------------------
Authors:
sanicheev@tacitknowledge.com
