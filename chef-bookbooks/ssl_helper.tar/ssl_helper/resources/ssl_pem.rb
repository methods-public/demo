actions :process

default_action :process

attribute :name, :regex => /^\w+$/, :kind_of => String, :name_attribute => true, :required => true
attribute :cn, :kind_of => String, :required => true
attribute :owner, :kind_of => String, :default => "root"
attribute :group, :kind_of => String, :default => "root"
attribute :mode, :kind_of => Integer, :default => 0400
