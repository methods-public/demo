#
# Cookbook Name:: percona-tools
# Recipe:: default

# Setup Percona repo and tools
include_recipe "percona-tools::percona_tools"