# CHANGELOG for autopatch_ii

## 1.0.3 (5/31/2017)

- [Corey Hemminger] - fixed typo in windows template

## 1.0.2 (5/9/2017)

- [Corey Hemminger] - updated firstrun_patches recipe to use attributes for yum options and exclude packages

## 1.0.1 (4/20/2017)

- [Corey Hemminger] - Fixed bugs and tested to be working

## 1.0.0 (4/18/2017)

- [Corey Hemminger] - Initial commit
