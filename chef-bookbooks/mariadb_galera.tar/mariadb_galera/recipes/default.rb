#
# Cookbook Name:: mariadb_galera
# Recipe:: default
#
# Copyright (c) 2016 Robert Ressl, All Rights Reserved.
