# mariadb_galera Cookbook

## Scope



## Requirements

- Chef 12.5 or higher

## Cookbook Dependencies

There are no hard coupled dependencies.
However, there is a loose dependency on `firewall` for firewall recipe.
