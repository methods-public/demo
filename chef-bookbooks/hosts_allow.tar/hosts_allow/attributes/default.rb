#
# Cookbook: hosts_allow-cookbook
# License: Apache 2.0
#
# Copyright (C) 2016 Bloomberg Finance L.P.
#

default['hosts_allow']['path'] = '/etc/hosts.allow'
