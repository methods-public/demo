name 'test'
version '0.0.0'

depends 'fluent'
