Description
===========
Installs the editor mg, a micro emacs clone, for when full blown emacs might be undesired.

Usage
=====
recipe[mg]

