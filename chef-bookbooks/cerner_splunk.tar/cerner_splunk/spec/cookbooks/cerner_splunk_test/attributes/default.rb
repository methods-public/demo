default[:splunk][:groups] = ['vagrant']
