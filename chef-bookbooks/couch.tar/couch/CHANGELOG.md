Couch Cookbook CHANGELOG
========================

v0.2.0
------
- Added support for installing from package on Ubuntu
- Removed from_source and added from_package attribute

v0.1.0
------
- Initial release
