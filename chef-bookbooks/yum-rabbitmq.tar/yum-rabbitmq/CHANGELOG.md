## v0.1.2
- removing yum dependency

## v0.1.1
- adding support for rabbitmq-erlang

## v0.1.0
- initial release
