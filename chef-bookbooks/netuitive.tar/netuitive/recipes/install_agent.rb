netuitive_install 'netuitive-agent'
