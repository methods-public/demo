netuitive_configure 'netuitive'

netuitive_collector 'netuitive'
