default['enterprise']['name'] = 'private_chef'
