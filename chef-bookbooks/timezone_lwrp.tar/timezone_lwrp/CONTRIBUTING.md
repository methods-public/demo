If you wish to contribute, please follow these steps:

1. Fork this repository on GitHub.
2. Create a new branch.
3. Write your code.
4. Write new tests.
5. Run `foodcritic -f any . && rubocop . && rspec && kitchen test`.
6. If everythig is Ok, commit and create a pull request.

Thank you!