default['dnsmasq']['group'] = 'root'
default['dnsmasq']['user'] = 'root'
default['dnsmasq']['packages'] = ['dnsmasq']
default['dnsmasq']['conf']['conf_file'] = '/etc/dnsmasq.conf'
default['dnsmasq']['conf']['conf_dir'] = '/etc/dnsmasq.d'
default['dnsmasq']['service'] = 'dnsmasq'
