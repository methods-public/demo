ntpd CHANGELOG
==============

This file is used to list changes made in each version of the ntpd cookbook.

0.1.0
-----
- RD - Initial release of ntpd cookbook

0.1.1
-----
- RD - Updating platforms and readme files

0.2.0
-----
- RD - Added Unit Tests

0.2.1
-----
- RD - Updated Dependencies 
     - Added Dependencies badge to README
     
     