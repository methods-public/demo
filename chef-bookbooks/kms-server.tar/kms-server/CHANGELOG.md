kms-server CHANGELOG
====================

This file is used to list changes made in each version of the kms-server cookbook.

## Version 0.3.0
- Annih - Properly compare installed product key
- Annih - Improve guard clause to avoid warning

## Version 0.2.0
- Annih - Fix windows feature name for dism provider

## Version 0.1.0
- Annih - Default recipe - attribute driven - to configure a KMS host
- Annih - Automatic deployment to Supermarket using travi-ci/dpl

## Version 0.0.0
- Annih - Initial commit
