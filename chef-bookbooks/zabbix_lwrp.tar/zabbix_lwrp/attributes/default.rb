default['zabbix']['version'] = '3.2'
default['zabbix']['api-version'] = '3.1.0'
