
default['shadowsocks_ng']['server_port'] = '8388'
default['shadowsocks_ng']['method'] = 'aes-256-cfb'
default['shadowsocks_ng']['password'] = 'pass'
default['shadowsocks_ng']['version'] = '2.8.2'
default['shadowsocks_ng']['package'] = 'shadowsocks'
default['shadowsocks_ng']['config'] = '/etc/shadowsocks.json'
