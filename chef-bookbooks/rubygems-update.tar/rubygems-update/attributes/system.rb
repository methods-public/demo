
default['rubgems-update']['system']['skip'] = false
default['rubygems-update']['system']['gem']['bin'] = '/usr/bin/gem'
