
default['rubygems-update']['chef-client']['skip'] = false
default['rubygems-update']['chef-client']['gem']['bin'] = '/opt/chef/embedded/bin/gem'
