To test this cookbook run:

```shell

foodcritic -f any ./ && rubocop ./ && kitchen test
```