# rubygems-update

## 0.1.1 (06-03-2018)

* TESTING.md was added.
* Tiny CHANGELOG fixes.

## 0.1.0 (06-03-2018)

* Initial release.