Kindle Cookbook CHANGELOG
=========================

v1.0.0 (2016-05-25)
-------------------
- Convert to custom resources, breaking compatibility with Chef < 12
- Update to use mac-app-store cookbook 2.x

v0.1.0 (2015-05-11)
-------------------
- Initial release! OS X (App Store or direct) and Windows (direct) support!

v0.0.1 (2015-04-26)
-------------------
- Development started
