# rubocop:disable Style/LeadingCommentSpace
# Default recipe
default["rubyenv"]["rubies"] = [
  '1.9.3-p551' => false,
  '2.1.5' => false,
  '2.2.3' => true
]
