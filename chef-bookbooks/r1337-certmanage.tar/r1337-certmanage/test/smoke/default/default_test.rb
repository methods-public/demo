#
# Cookbook Name:: r1337-certmanage
# Spec:: default
# Copyright 2018, Route 1337, LLC, All Rights Reserved.
#
# Maintainers:
# - Matthew Ahrenstein: matthew@route1337.com
#
# See LICENSE
#

# # encoding: utf-8

# Inspec test for recipe r1337-certmanage::default

# No tests are performed here.