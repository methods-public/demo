require 'chefspec'
require 'chefspec/berkshelf'
require 'coveralls'

Coveralls.wear!
