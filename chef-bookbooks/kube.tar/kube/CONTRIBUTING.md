# Contributing

This is a cookbook maintained by a single person so processes maybe written in an
adhoc basic.  Please open issues or pull requests and I will try to accommodate
or think about your request.

* *Tests*: Please see TESTING.md on how to run the unit tests.
