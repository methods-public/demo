Steam Cookbook CHANGELOG
========================

v2.1.0 (2016-03-04)
-------------------
- Bump apt dependency from 2.x to 3.x

v2.0.0 (2015-12-20)
-------------------
- Convert to custom resources (making the compat_resource cookbook a
  requirement for Chef < 12.5

v1.0.0 (2015-12-13)
-------------------
- Use Chef 12-style provider resolution (breaking compatibility with Chef 11)
- Fix issue with Steam .dmg package failing on OS X

v0.1.0 (2015-06-02)
-------------------
- Initial release! Supports OS X, Windows, and Ubuntu/Debian!

v0.0.1 (2015-05-27)
-------------------
- Development started
