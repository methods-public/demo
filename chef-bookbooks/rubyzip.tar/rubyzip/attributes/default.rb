#
# Cookbook: rubyzip
# License: Apache 2.0
#
# Copyright 2016, Bloomberg Finance L.P.
#
default['rubyzip']['version'] = '1.2.0'
