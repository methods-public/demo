# rubyzip cookbook
Library cookbook which provides custom resources for managing zip
archives.

## Integration Testing

``` bash
~/Projects/rubyzip-cookbook % chef install test/fixtures/policies/default
~/Projects/rubyzip-cookbook % kitchen converge ubuntu-1404
```
