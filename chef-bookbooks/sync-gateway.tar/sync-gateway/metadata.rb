name 'sync-gateway'
maintainer 'Simon Bang Terkildsen'
maintainer_email 'terkildsen@monsenso.com'
license 'MIT'
description 'Installs and configures sync-gateway'
long_description 'Installs and configures sync-gateway'
version '0.1.0'

supports 'windows'

depends 'nssm'
