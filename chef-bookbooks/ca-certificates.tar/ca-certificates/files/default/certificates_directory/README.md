certificates_directory
======================

This is a placeholder for additional certificates.

### How to use

Add individual certificates that you would like to trust to this directory.

The certificates must have the `.pem` suffix in order to work and they should
be PEM formatted.
