ca-certificates CHANGELOG
=========================

This file is used to list changes made in each version of the ca-certificates cookbook.

0.1.0
-----
- Jason Barnett - Initial release of ca-certificates

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
