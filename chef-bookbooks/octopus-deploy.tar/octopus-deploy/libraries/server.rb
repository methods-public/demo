# frozen_string_literal: true
#
# Author:: Brent Montague (<bmontague@cvent.com>)
# Cookbook Name:: octopus-deploy
# Library:: server
#
# Copyright:: Copyright (c) 2015 Cvent, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

require_relative 'shared'

module OctopusDeploy
  # A container to hold the server values instead of attributes
  module Server
    include OctopusDeploy::Shared

    def display_name
      'Octopus Deploy Server'
    end

    def service_name
      'OctopusDeploy'
    end

    def server_install_location
      'C:\Program Files\Octopus Deploy\Octopus'
    end

    def installer_url(version)
      "https://download.octopusdeploy.com/octopus/Octopus.#{version}-x64.msi"
    end
  end
end
