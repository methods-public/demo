hana-client CHANGELOG
===================

This file is used to list changes made in each version of the hana-client cookbook.

1.0.1
-----
- Dan-Joe - Fix for issue with slashes in the path when running on chef-server.
- Dan-Joe - Added issues and source urls in metadata.
- Dan-Joe - Improvements for remote file resource OS agnosticity.

1.0.0
-----
- Dan-Joe - Initial public release of hana-client.

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
