# frozen_string_literal: true

default['ama']['ssh-private-keys']['data-bag'] = 'ssh-private-keys'
