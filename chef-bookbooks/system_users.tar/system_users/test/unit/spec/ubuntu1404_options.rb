UBUNTU1404_SERVICE_OPTS = {
  log_level: LOG_LEVEL,
  platform: 'ubuntu',
  version: '14.04'
}.freeze
