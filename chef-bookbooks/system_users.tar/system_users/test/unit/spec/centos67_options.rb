CENTOS67_SERVICE_OPTS = {
  log_level: LOG_LEVEL,
  platform: 'centos',
  version: '6.7'
}.freeze
