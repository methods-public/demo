UBUNTU1204_SERVICE_OPTS = {
  log_level: LOG_LEVEL,
  platform: 'ubuntu',
  version: '12.04'
}.freeze
