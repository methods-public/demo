require 'spec_helper'

describe 'shared tests' do
  it_behaves_like 'users'
end
