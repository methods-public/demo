#
# Cookbook Name:: newrelic
# Recipe:: infrastructure_agent
#
# Copyright (c) 2017, David Joos
#

newrelic_agent_infrastructure 'Install'
