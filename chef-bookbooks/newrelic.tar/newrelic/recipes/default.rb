#
# Cookbook Name:: newrelic
# Recipe:: default
#
# Copyright (c) 2016, David Joos
#

include_recipe 'newrelic::server_monitor_agent'
