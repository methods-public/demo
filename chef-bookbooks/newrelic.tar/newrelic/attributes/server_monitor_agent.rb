#
# Cookbook Name:: newrelic
# Attributes:: server_monitor_agent
#
# Copyright (c) 2016, David Joos
#

default['newrelic']['server_monitor_agent']['agent_action'] = nil

default['newrelic']['server_monitor_agent']['service_notify_action'] = nil
default['newrelic']['server_monitor_agent']['service_actions'] = nil
default['newrelic']['server_monitor_agent']['config_file_user'] = nil
default['newrelic']['server_monitor_agent']['windows_version'] = nil
default['newrelic']['server_monitor_agent']['windows64_checksum'] = nil
default['newrelic']['server_monitor_agent']['windows32_checksum'] = nil
default['newrelic']['server_monitor_agent']['template']['cookbook'] = nil
default['newrelic']['server_monitor_agent']['template']['source'] = nil
