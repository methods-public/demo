#
# Cookbook Name:: newrelic
# Attributes:: dotnet_agent
#
# Copyright (c) 2016, David Joos
#

default['newrelic']['dotnet_agent']['https_download'] = nil
default['newrelic']['dotnet_agent']['install_level'] = nil
