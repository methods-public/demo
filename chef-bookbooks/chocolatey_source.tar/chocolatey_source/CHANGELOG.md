# chocolatey_source Cookbook CHANGELOG

This file is used to list changes made in each version of the chocolatey_source cookbook.

## 1.1.0 (2018-05-01)

- Add support for priority and bypassproxy
- Use the full path to the choco CLI so we don't have to worry about the path

1.0.0 (2018-04-30)

- Initial release
