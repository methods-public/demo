## v0.4.0

* Add a recipe for Ubuntu 14.04
* Fix level two check to correct block in CentOS 7 recipe

## v0.3.3

* Fix a typo in 3.9
* Check if postfix is installed, and adjust how to check whether the node listens on localhost:25 or not all all

## v0.3.2

* Remove the guards around the metadata URLs

## v0.3.1

* Use anchored regexp for gpgcheck

## v0.3.0

* Implementation of audit mode control groups for all sections of CIS Benchmark for CentOS 7
