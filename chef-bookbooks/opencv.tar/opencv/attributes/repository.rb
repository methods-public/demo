default['opencv']['repository_ppa'] = 'stable' # can be "daily" and "backports"
