default['opencv']['package']['version'] = '2.3'
