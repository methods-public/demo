mongo_chef_gem CHANGELOG
========================

0.2.2 (2017-10-01)
------------------
- Switch to Cookstyle

0.2.0 (2015-11-15)
------------------
- add bson_ext gem

0.1.1 (2015-11-14)
------------------
- update vestion for gem mongo, allow to install latest gem

0.1.0 (2015-11-13)
------------------
- Initial release
