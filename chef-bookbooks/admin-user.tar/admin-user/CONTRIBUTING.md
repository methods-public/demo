Contributing
============

Process
-------
1. Fork the project
2. Make your changes - bonus points for topic branches and descriptive commit messages
3. Make sure that `bundle exec rake cookbook:full_test` returns no errors
4. **Do not version bump**
5. Submit a PR
