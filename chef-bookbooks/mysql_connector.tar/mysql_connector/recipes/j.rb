node['mysql_connector']['j']['install_paths'].each do |path|
  mysql_connector_j path
end
