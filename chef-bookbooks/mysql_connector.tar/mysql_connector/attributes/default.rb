default['mysql_connector']['j']['install_paths'] = []
default['mysql_connector']['j']['version'] = '5.1.36'

# Attributes auto-detected in provider, but available for override
default['mysql_connector']['j']['checksum'] = nil
default['mysql_connector']['j']['jar_file'] = nil
default['mysql_connector']['j']['tar_file'] = nil
default['mysql_connector']['j']['url'] = nil
