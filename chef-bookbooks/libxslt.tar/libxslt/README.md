# libxslt-cookbook
Chef cookbook to install [libxslt](http://xmlsoft.org/libxslt/).
