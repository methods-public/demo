# hypercontainer CHANGELOG

0.3.1
-----
- improves guard condition of installation.

0.3.0
-----
- adds the `['hypercontainer']['config']` attribute.

0.2.1
-----
- bug fix.

0.2.0
-----
- bumps up hypercontainer version.
- adds the `['hypercontainer']['daemon_extra_options']` attribute.

0.1.1
-----
- improves install method.

0.1.0
-----
- Initial release of hypercontainer
