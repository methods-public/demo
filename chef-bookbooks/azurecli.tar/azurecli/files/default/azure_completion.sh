# Enable tab completion
# Reference https://docs.microsoft.com/en-us/azure/xplat-cli-install
azure --completion > /dev/null 2>&1
