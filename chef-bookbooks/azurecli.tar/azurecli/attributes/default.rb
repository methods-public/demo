default['azurecli']['azure']['virtualenv'] = nil
default['azurecli']['azure']['version'] = '2'
default['azurecli']['azure']['cli_version'] = nil
default['azurecli']['azure']['python']['version'] = '2'
default['azurecli']['azure']['python']['provider'] = :system
