# azurecli CHANGELOG

This file is used to list changes made in each version of the azurecli cookbook.
## 0.1.2
- [Alex Tu] - correct typo

## 0.1.1
- [Alex Tu] - add changes

## 0.1.0
- [Alex Tu] - Initial release of azurecli

