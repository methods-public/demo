default['jumpcloud']['connect_key'] = nil
default['jumpcloud']['prepare_for_image'] = false
