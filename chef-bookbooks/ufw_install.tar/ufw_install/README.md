ufw_install Cookbook
====================

This cookbook installs ufw to centos.

Supports
------------

- CentOS

Requirements
------------

- python


Attributes
----------

Nothing.

Usage
-----

#### ufw_install::default

Just include `ufw_install` in your node's `run_list`:

```json
{
  "name":"my_node",
  "run_list": [
    "recipe[ufw_install]"
  ]
}
```

Contributing
------------

1. Fork the repository on Github
2. Create a named feature branch (like `add_component_x`)
3. Write your change
4. Write tests for your change (if applicable)
5. Run the tests, ensuring they all pass
6. Submit a Pull Request using Github

License and Authors
-------------------

# Author

Author:: HiganWorks LLC (<sawanoboriyu@higanworks.com>)

