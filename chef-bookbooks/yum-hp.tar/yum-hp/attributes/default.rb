default['yum-hp']['repositories'] = %w(hp-spp)
