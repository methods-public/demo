yum-HP Cookbook CHANGELOG
======================
v0.0.3 (2017-08-24)
------
Changed public key url

v0.0.2 (2015-07-25)
------
Changed hp-spp repo baseurl

v0.0.1 (2015-07-25)
------
initial release
