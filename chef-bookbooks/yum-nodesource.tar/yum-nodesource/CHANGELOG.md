yum-nodesource CHANGELOG
========================

This file is used to list changes made in each version of the yum-nodesource cookbook.

1.0.0
-----
- Release to the public

0.1.0
-----
- Initial release of yum-nodesource
