#
# Cookbook Name:: yum-nodesource
# Recipe:: default
#
# Copyright 2016, Movile.com
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'yum-nodesource::4x'
