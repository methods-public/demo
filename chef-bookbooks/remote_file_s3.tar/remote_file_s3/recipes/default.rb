# frozen_string_literal: true

#
# Cookbook:: remote_file_s3
# Recipe:: default
#
# Copyright:: 2018, Matt Kulka
