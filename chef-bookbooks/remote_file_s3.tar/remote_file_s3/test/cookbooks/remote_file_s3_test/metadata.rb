# frozen_string_literal: true

name 'remote_file_s3_test'

depends 'remote_file_s3'
