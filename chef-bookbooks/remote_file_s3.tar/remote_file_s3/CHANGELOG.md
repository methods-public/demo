# remote_file_s3 CHANGELOG

This file is used to list changes made in each version of the remote_file_s3 cookbook.

## 1.0.5
- [mattlqx] - Don't throw an exception if group or user doesn't exist at compilation.

## 1.0.4
- [mattlqx] - Rearrange some statements to better accomodate Windows.

## 1.0.3
- [mattlqx] - Use node for current user.

## 1.0.2
- [mattlqx] - Fix issue with nil for owner, group or mode.

## 1.0.1
- [mattlqx] - Fix lint and move default for aws region ahead in code.

## 1.0.0
- [mattlqx] - Initial release! 🕺

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
