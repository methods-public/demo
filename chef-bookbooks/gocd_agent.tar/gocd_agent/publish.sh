#!/bin/bash

knife supermarket share gocd_agent "Process Management"
