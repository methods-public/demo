default['nokogiri']['gem_binary'] = nil
default['nokogiri']['options'] = nil
default['nokogiri']['version'] = nil
