default['nokogiri']['options'] = nil
default['nokogiri']['version'] = nil
default['build-essential']['compile_time'] = true
default['libxml2']['compile_time'] = true
default['apt']['compiletime'] = true
default['apt']['compile_time_update'] = true
