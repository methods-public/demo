Chef::Log.warn('The libarchive::default recipe is no longer needed and should not be included on runlists')
