service 'looker' do
  action :start
end
