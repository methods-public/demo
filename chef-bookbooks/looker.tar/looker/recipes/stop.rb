service 'looker' do
  action :stop
end
