require 'ilo-sdk'

ilo1 = ILO_SDK::Client.new(
  host: '16.85.179.199',
  user: 'Admin',
  password: 'admin123',
  ssl_enabled: false
)
# NOTE: The ILO_SDK::Client class is required here instead of a hash because we'll be calling the #get_csr method on it.

# Get the current SSL Certificate and check to see if expires within 24 hours
expiration = ilo1.get_certificate.not_after.to_datetime
tomorrow = DateTime.now + 1

valid = expiration > tomorrow
ilo_https_cert 'generate CSR' do
  ilo ilo1
  country 'USA'
  state 'Texas'
  city 'Houston'
  orgName 'Example Company'
  orgUnit 'Example'
  commonName 'example.com'
  action :generate_csr
  # not_if { valid || ilo1.get_csr } # Only generate if the cert is expiring soon and the CSR has not already been generated
end

# ilo_https_cert 'dump CSR to file' do
  # ilo ilo1
  # file_path '~/certs/CSR.cert'
  # action :dump_csr
  # not_if { valid || ilo1.get_csr.nil? } # Don't dump the CSR file if the cert is still valid or the csr is not finished being generated
# end

# Here you'll need to have a step that submits the CSR to a certificate authority
# (or self-signs it) and gets back the signed certificate. It will look something like:
# -----BEGIN CERTIFICATE-----
# lines_of_secret_text
# -----END CERTIFICATE-----
# For this example, we're assuming we've read in the content of the certificate to the
# "cert" variable (as a string).

# ilo_https_cert 'import certificate' do
  # ilo ilo1
  # certificate cert
  # action :import
  # not_if { valid || cert.nil? }
# end
