ilos = [
  {
    host: '16.85.179.199',
    user: 'Admin',
    password: 'admin123',
    ssl_enabled: false
  }
]

ilo_secure_boot 'enable secure boot' do
  ilos ilos
  enable true # Optional: Defaults to false
end
