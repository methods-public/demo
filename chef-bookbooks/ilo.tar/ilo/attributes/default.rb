#
# Cookbook Name:: ilo
# Attributes:: default
#

default['ilo']['ruby_sdk_version'] = '~> 1.2'
