
default['seq']['source'] = 'https://getseq.blob.core.windows.net/releases/Seq-3.1.17.msi'
default['seq']['checksum'] = '68822a804f4eddc709d49231c4e0b393db8fe7c5919c2277ee436a6d87a5fd9f'

default['seq']['license'] = nil
