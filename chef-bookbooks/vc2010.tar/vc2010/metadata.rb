maintainer       "Webtrends Inc."
maintainer_email "david.dvorak@webtrends.com"
license          "All rights reserved"
description      "Installs Microsoft Visual C++ 2010 Redistributable Package"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "1.0.1"
supports         "windows"
depends          "windows", ">= 1.2.6"
