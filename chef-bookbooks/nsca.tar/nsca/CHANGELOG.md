nsca CHANGELOG
========================

0.1.3 (2017-10-08)
------------------
- Update travis settings

0.1.2 (2015-11-21)
------------------
- add bson_ext gem
