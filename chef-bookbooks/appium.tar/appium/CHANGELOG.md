# Changelog

## 0.2.0 

- Add nodejs_home and npm_options attributes for managing executing options

## 0.1.0 

- Initial release
