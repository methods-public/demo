default['appium']['nodejs_home'] = nil
default['appium']['npm_options'] = []
default['appium']['version'] = '1.4.6'
default['appium']['user'] = nil
