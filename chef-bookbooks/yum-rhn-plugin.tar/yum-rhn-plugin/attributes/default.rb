default['yum-rhn']['source'] = nil
default['yum-rhn']['main']['enabled'] = '1'
default['yum-rhn']['main']['gpg-check'] = '1'
default['yum-rhn']['data_bag'] = nil
