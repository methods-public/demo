Openvpn_Duo Cookbook CHANGELOG
==============================

v0.1.0 (2016-10-11)
-------------------
- Initial release

v0.0.1 (2016-09-19)
-------------------
- Development started
