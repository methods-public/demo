node.default['postgresql']['server']['packages'] = ['postgresql-9.3', 'pg_config']
