default['winbox']['editor'] = :vscode
