default['winbox']['debugger_install_path'] = ENV['ProgramData']
