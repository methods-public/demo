Please refer to the (Official Chef contributing guide)[https://github.com/chef-cookbooks/community_cookbook_documentation/blob/master/CONTRIBUTING.MD]
