# Encoding: UTF-8
# NXLog - Smoke Test

require_relative '../spec_helper'

# => Verify NXLog Installation
check_nxlog
