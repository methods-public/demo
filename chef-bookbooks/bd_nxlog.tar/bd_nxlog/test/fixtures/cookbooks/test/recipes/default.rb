# Encoding: UTF-8

include_recipe 'bd_nxlog::default'
