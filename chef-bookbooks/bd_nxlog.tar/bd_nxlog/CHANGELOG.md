BD-NXLog Changelog
=========================
This file is used to list changes made in each version of the `bd_nxlog` cookbook.

v0.1.3 (2017-08-02)
-------------------
### Fixes
- Update download URL's

v0.1.2 (2017-04-24)
-------------------
### Enhancements
- Add ability to add NXLog to groups with an attribute

### Fixes
- Ensure correct permissions on NXLog log directory so logrotate does not complain
- Add missing checksum

v0.1.1 (2017-04-05)
-------------------
### Enhancements
- Add a boolean attribute to easily enable/disable NXLog in its entirety
- Add log rotation for NXLog

v0.1.0 (2017-04-03)
-------------------
- Initial Release
