#!/bin/bash
# Release to Supermarket

knife cookbook site share bd_nxlog other -k ${CHEF_HOSTED_KEY}
