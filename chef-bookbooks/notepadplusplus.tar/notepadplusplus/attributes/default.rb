default['notepadplusplus']['url']          = "http://download.tuxfamily.org/notepadplus/5.9.8/npp.5.9.8.Installer.exe"
default['notepadplusplus']['package_name'] = "Notepad++"
