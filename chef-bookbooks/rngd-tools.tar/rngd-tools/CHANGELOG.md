## v1.3.0:

* Add RHEL/CentOS 5 Support

## v1.2.0:

* Rename cookbook to rngd-tools
* Add RHEL/CentOS 7 Support
* Add Debian 7 and 8 Support
* Add Ubuntu 12 and 14 Support
* Add Amazon Linux Support

## v1.1.0:

* Issue #1: Add RHEL Support

## v1.0.0:

* Initial release
