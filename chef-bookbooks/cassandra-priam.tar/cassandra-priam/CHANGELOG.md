# CHANGELOG for cassandra-mdsol

This file is used to list changes made in each version of cassandra-mdsol.

## 0.0.1:

* Initial release of cassandra-mdsol

- - - 
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
