## v0.0.3

    Remove platform_version 5 constraints 

## v0.0.2

    Add support for other platforms

## v0.0.1

    Public release of Marshall University common cookbooks for Enterprise Linux
