name 'test'
version '0.0.0'

depends 'docker'
depends 'nomad'
