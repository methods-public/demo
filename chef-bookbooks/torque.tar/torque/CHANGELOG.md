torque CHANGELOG
================
This file is used to list changes made in each version of the torque cookbook.

v0.2.2-3
-----
- Sandor Acs - Fixed typos.

v0.2.1
-----
- Sandor Acs - Node search aims recipes instead of roles 

v0.2.0
-----
- Sandor Acs - RHEL family support added 

v0.1.0
-----
- Sandor Acs - Initial release of torque

