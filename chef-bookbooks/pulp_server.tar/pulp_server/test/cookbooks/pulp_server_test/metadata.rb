name 'pulp_server_test'
version '0.0.1'
depends 'pulp_server'
