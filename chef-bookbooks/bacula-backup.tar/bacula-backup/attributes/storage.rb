default['bacula']['sd']['address'] = node['ipaddress']
default['bacula']['sd']['backup_dir'] = "/backup"

default['bacula']['sd']['remote_connection'] = nil
default['bacula']['sd']['remote_password'] = nil

default['bacula']['sd']['file_max_net_buffer'] = "32768"
