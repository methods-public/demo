default['bacula']['mysql_user'] = "bacula"

default['bacula']['dir']['address'] = nil

default['bacula']['volume_size'] = "1G"
default['bacula']['volume_max'] = 50
default['bacula']['label_format'] = "BaculaFile"

default['bacula']['dir']['max_concurrent_jobs'] = "1"

default['bacula']['dir']['file_storage_device'] = "File"
default['bacula']['dir']['file_storage_pool'] = "File"
