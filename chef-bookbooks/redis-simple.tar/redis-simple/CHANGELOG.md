redis-simple CHANGELOG
========================

0.1.2 (2018-04-03)
------------------
- Add service name to attr

0.1.0 (2018-01-31)
------------------
- Initial release
