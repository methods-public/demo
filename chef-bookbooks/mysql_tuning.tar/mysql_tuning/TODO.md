TODO
====

* [ ] Check for maximum variable values.
* [ ] Implement and test more interpolation algorithms.
* [ ] Review [MySQL cookbook providers](https://github.com/opscode-cookbooks/mysql/tree/master/libraries) to add support for more platforms.
* [ ] Refactor *CookbookHelpers* library.
 * [ ] Create a gem with configuration interpolation logic?
* [ ] Add ChefSpec tests for dynamic configuration updates.
* [ ] Add more unit tests for libraries.
* [ ] Document the libraries code.
