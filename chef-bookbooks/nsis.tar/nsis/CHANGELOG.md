NSIS CHANGELOG
======================

This file is used to list changes made in each version of the NSIS cookbook.

v0.4.0 (2016-04-25)
-------------------

* Update the repository URL

v0.3.0 (2016-01-20)
-------------------

* Minor cleanups to the cookbook

v0.2.0 (2016-01-07)
-------------------

* Allow choosing of a version using ```node['nsis']['version']```

v0.1.0 (2015-10-02)
-------------------
* Initial commit
