default['nsis']['version'] = 'latest'
