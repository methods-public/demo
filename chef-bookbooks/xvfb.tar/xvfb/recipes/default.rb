include_recipe 'xvfb::package'
include_recipe 'xvfb::service'
