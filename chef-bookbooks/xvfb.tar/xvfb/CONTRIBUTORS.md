* Dennis Hoer <dennis.hoer@gmail.com>
* Maciej Pasternacki <maciej@3ofcoins.net>
* Miguel Ferreira <miguelferreira@me.com>
* Vasily Mikhaylichenko <vaskas@lxmx.com.au>
