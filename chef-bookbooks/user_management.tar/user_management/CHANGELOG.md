# 1.0.1

Edit README for better readability.

# 1.0.0

Initial release of user_management
