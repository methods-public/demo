yum-atomic cookbook CHANGELOG
======================

This file is used to list changes made in each version of the yum-atomic cookbook.

0.2.0
-----
- Fix node.set deprecation warnings
- Update kitchen platforms
- Depend on compat_resource instead of yum
- Thanks for the PR https://github.com/chewi

0.1.2
-----
- Broader platform support

0.1.1
-----
- Add Scientific Linux to attribute files

0.1.0
-----
- Initial release
