To contribute please

* Checkout the repository

`git clone git@github.com:sbp-cookbooks/mercury.git`

* Create a branch descibing your feature

`git checkout -b f-my-feature`

* Add your commit

`git commit <files>`

* Run the test suite
`bundle exec kitchen`

* Submit a pull request

