To do testing run:

`bundle exec kitchen`
