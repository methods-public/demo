# 0.8.7

* Prevent installation of package config from .deb packages

# 0.8.6

* Update nokogiri gem due to security alert

# 0.8.5

* Point nxlog base URL at mirror, as nxlog keep taking down old versions and breaking the cookbook
* Add cookbook attribute to allow different base URLs

# 0.8.4

* Nxlog version bump
* Fix integration tests for Chef 12.5

# 0.8.3

* Added json extension module

# 0.8.2

* Added checksum validation to nxlog remote_file packages

# 0.8.1

* Remove input_type equal_to validation

# 0.8.0

* Add syslog recipe

# 0.7.2

* Add support for the FlowControl directive in input modules

# 0.7.1

* Update documentation to link to github page, as it looks better than on the supermarket

# 0.7.0

* Add support for creating log resources from node attributes

# 0.6.0

* Fix issue with LWRPs not working in other recipes

# 0.5.0

* Initial release of nxlog cookbook
