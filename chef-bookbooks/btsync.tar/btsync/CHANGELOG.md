btsync CHANGELOG
================

This file is used to list changes made in each version of the btsync cookbook.
0.1.25 &amp 0.1.26
- [Nitecon] - Upgraded versions to a working version that appears to be working across many different linux distros.
- [Nitecon] - Incremented from 0.1.25 to 0.1.26 for documentation update.

0.1.5
- [Nitecon] - Fixed issues with search not working correctly on hosted chef.

0.1.4
- [Nitecon] - Starting integration of LWRP

0.1.3
-----
- [Nitecon] - Updated attributes to be more generic
- [Nitecon] - Added inititial LWRP for shared folders

0.1.2
-----
- [Nitecon] - Options files and init scripts have been updated with corresponding attributes

0.1.1
-----
- [Nitecon] - Added initial documentation to the readme for btsync

0.1.0
-----
- [Nitecon] - Initial WIP upload of btsync

