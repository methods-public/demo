# develop

# 1.0.0
  * API stability
  * Unlock build-essential dependency for wider compatability

# 0.2.0
  * Support CentOS
  * Use updated PocketSphinx

# 0.1.0
  * First release
