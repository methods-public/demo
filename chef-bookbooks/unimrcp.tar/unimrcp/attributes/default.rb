default['unimrcp']['version'] = '1.1.0'
default['unimrcp']['install_dir'] = '/usr/local/unimrcp'
default['unimrcp']['install_flite'] = false
default['unimrcp']['install_pocketsphinx'] = false
