service 'apache2' do
  action :restart
end
