#
# Cookbook: lockrun
# License: Apache 2.0
#
# Copyright (C) 2014, 2015 Bloomberg Finance L.P.
#
default['lockrun']['install_method'] = 'source'
default['lockrun']['package_name'] = 'lockrun'
