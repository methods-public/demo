node.default[:rbenv_install_rubies][:global_version] = '2.0.0-p247'
node.default[:rbenv_install_rubies][:gems] = ['bundler', 'rbenv-rehash', 'pry']
node.default[:rbenv_install_rubies][:other_versions] = []
node.default[:rbenv_install_rubies][:lib_packages] = []
