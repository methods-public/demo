devenv CHANGELOG
================

0.2.0
-----
- [akahigeg] - Add keep group write feature by cron.
- [akahigeg] - Add specs.

0.1.0
-----
- [akahigeg] - Initial release of rbenv-install-rubies.

