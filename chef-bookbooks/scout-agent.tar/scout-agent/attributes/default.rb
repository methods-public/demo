default["scout_agent"]["key"]         = ""
default["scout_agent"]["user"]        = "scout"
default["scout_agent"]["group"]       = "scout"
default["scout_agent"]["version"]     = "5.5.4"
default["scout_agent"]["rvm_ruby"]    = "ruby-1.9.3-p194"
default["scout_agent"]["rvm_gemset"]  = "scout"
default["scout_agent"]["plugin_gems"] = []
default["scout_agent"]["node_name"]   = ""
