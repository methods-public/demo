# 0.1.0

Initial release of confluent-cookbook

# 0.1.1

fixed some renaming

# 0.2.0

Added Schema-Registry service and configuration.

# 0.3.0

Added Kafka REST service and configuration.
