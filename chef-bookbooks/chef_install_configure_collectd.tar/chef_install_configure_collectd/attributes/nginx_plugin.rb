default['nginx']['url'] = 'http://localhost:80/nginx_status'
