default['elasticsearch']['clustername'] = 'elasticsearch'
default['elasticsearch']['indexes'] = '_all'
default['elasticsearch']['python_folder'] = '/usr/share/collectd/python/'
default['elasticsearch']['config'] = {}
