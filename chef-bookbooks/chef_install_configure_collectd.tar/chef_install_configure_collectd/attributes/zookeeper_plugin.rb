default['zookeeper']['hostname'] = 'localhost'
default['zookeeper']['port'] = '2181'
default['zookeeper']['python_folder'] = '/usr/share/collectd/python/'
