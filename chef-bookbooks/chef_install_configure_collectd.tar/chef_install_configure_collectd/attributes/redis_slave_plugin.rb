default['redis_slave']['hostname'] = 'localhost'
default['redis_slave']['port'] = '9999'

default['redis_slave']['python_folder'] = '/usr/share/collectd/python/'
