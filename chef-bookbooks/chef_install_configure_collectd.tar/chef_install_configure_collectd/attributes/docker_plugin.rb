default['docker']['dbfile_folder'] = '/usr/share/collectd/docker-collectd-plugin'
default['docker']['python_folder'] = '/usr/share/collectd/docker-collectd-plugin'
default['docker']['base_url'] = 'unix://var/run/docker.sock'
