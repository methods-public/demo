default['postgresql']['hostname'] = 'localhost'
default['postgresql']['user'] = 'perf_mon'
default['postgresql']['password'] = 'testpw'
