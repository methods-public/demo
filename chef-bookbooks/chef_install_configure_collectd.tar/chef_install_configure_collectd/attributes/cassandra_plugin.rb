default['cassandra']['serviceurl'] = 'service:jmx:rmi:///jndi/rmi://localhost:7199/jmxrmi'
