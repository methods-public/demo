default['kafka']['serviceurl'] = 'service:jmx:rmi:///jndi/rmi://localhost:7099/jmxrmi'
