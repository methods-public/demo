default['apache']['instanceName'] = 'myapacheinstance'
default['apache']['url'] = 'http://localhost/mod_status?auto'
