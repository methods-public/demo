default['redis_master']['hostname'] = 'localhost'
default['redis_master']['port'] = '2181'

default['redis_master']['python_folder'] = '/usr/share/collectd/python/'
