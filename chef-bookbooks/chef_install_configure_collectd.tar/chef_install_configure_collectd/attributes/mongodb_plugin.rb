default['mongodb']['dbfile_folder'] = '/usr/share/collectd/mongodb-collectd-plugin'
default['mongodb']['python_folder'] = '/usr/share/collectd/mongodb-collectd-plugin'
default['mongodb']['hostname'] = 'localhost'
default['mongodb']['port'] = '27017'
default['mongodb']['user'] = ''
default['mongodb']['password'] = 'password'
default['mongodb']['database'] = ['admin', 'db-prod', 'db-dev']
