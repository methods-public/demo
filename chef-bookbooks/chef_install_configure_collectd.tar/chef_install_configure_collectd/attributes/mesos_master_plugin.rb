default['mesos']['master']['python_folder'] = '/usr/share/collectd/mesos-collectd-plugin'
default['mesos']['master']['cluster'] = 'cluster-0'
default['mesos']['master']['instance'] = 'master-0'
default['mesos']['master']['binary_path'] = '/usr/bin'
default['mesos']['master']['hostname'] = 'localhost'
default['mesos']['master']['port'] = '5050'

