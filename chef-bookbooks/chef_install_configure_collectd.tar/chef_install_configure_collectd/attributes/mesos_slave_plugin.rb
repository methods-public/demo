default['mesos']['slave']['python_folder'] = '/usr/share/collectd/mesos-collectd-plugin'
default['mesos']['slave']['cluster'] = 'cluster-0'
default['mesos']['slave']['instance'] = 'slave-0'
default['mesos']['slave']['binary_path'] = '/usr/bin'
default['mesos']['slave']['hostname'] = 'localhost'
default['mesos']['slave']['port'] = '5050'

