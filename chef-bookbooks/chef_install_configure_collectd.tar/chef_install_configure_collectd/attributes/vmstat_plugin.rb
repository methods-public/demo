default['vmstat']['path'] = '/usr/bin/vmstat'
default['vmstat']['verbose'] = 'false'
default['vmstat']['python_folder'] = '/usr/share/collectd/python/'
default['vmstat']['include'] = '["r", "b", "swpd", "free", "buff", "cache", "inact", "active", "si", "so", "bi", "bo", "in", "cs", "us", "sy", "id", "wa", "st"]'
