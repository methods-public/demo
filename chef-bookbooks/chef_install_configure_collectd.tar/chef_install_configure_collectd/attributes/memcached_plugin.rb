default['memcached']['hostname'] = '127.0.0.1'
default['memcached']['port'] = '11211'
