nginx-pkg CHANGELOG
=====================

This file is used to list changes made in each version of the nginx-pkg
cookbook.

0.1.0
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - Initial release of nginx-pkg
