#
# Cookbook Name:: percona
# Recipe:: default
#

include_recipe "percona::client"
