Webhook Cookbook CHANGELOG
==========================

v0.2.0 (2014-10-07)
-------------------
- Add support for the Windows and OS X GUI apps

v0.1.0 (2014-08-25)
-------------------
- Initial release!

v0.0.1 (2014-08-22)
-------------------
- Development started
