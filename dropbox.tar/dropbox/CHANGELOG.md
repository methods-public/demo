Dropbox Cookbook CHANGELOG
==========================

v0.1.0 (2014-12-27)
-------------------
- Initial release (installation only; OS X and Windows only)

v0.0.1 (2014-12-14)
-------------------
- Development started
