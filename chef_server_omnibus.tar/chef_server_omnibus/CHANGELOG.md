# Changelog

0.3.0
---------
- Update `poise` dependency to `~> 2.0`. This is not a breaking change, *unless*
  this cookbook is used in conjunction with another cookbook that has a conflicting
  dependency on `poise`.

0.2.0
---------
- Feature: Install add-ons `opscode-manage`, `opscode-push-jobs-server`, `opscode-reporting`, `opscode-analytics`,
and `chef-sync` (replication).

0.1.0
---------
- Initial release
