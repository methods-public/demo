default['giraffe']['git_repository'] = "https://github.com/kenhub/giraffe.git"
default['giraffe']['git_revision'] = "1.1.0"
