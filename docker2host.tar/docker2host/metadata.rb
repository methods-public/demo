name 'docker2host'
maintainer 'lorieri'
maintainer_email 'lorieri@gmail.com'
license 'Apache 2.0'
description 'docker2host'

version '0.0.1'

supports 'amazon'
supports 'redhat'
supports 'centos'
supports 'debian'
supports 'ubuntu'

depends "docker"
