# How to contribute

Thanks for interest in contributing! Just fork and submit a pull request.

Make sure the tests pass and write some new ones for new functionality. See the [TESTING.md](https://github.com/greglu/dropwizard-cookbook/blob/master/TESTING.md) file for more information.
