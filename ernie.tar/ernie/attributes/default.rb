default.ernie.gem_binary = nil
