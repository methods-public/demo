Changelog
=========

1.0.0
-----

- Initial version with Centos 7 support, verified for kernel 4.9.62
