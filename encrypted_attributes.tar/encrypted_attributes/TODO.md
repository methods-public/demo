TODO
====

* [ ] Update year.
* [ ] README: Update mysql example.
* [ ] README: Fix RuboCop offenses in examples.
* [ ] Fix FreeBSD 10 support: `gcc: Command not found`.
* [ ] Be able to use them from attribute files.
* [ ] Install `chef-encrypted-attributes` [verifying the gem signature](http://onddo.github.io/chef-encrypted-attributes/#using-signed-gems).
