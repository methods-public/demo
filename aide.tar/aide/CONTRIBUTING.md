# Contributing

1. Fork this repository
2. `bundle install`
3. Create a named feature branch (`git checkout -b add-new-recipe`)
4. `bundle exec rake` must pass
5. Commit your changes (`git commit -am ‘Add some feature’`)
6. Push to the branch (`git push origin my-new-feature`)
7. Create new Pull Request
