#
# Cookbook:: delphix
# Recipe:: redhat
#
# Copyright:: 2018, The Authors, All Rights Reserved.

package 'nfs-utils'
