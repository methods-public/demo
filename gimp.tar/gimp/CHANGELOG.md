Gimp Cookbook CHANGELOG
=======================

v1.1.0 (2016-03-02)
-------------------
- Bump apt dependency from 2.x to 3.x

v1.0.1 (2016-02-22)
-------------------
- Fix OS X installation on case-sensitive filesystems

v1.0.0 (2015-12-07)
-------------------
- Update provider resolution to adhere to the most recent standards set by e.g.
  the [httpd cookbook](https://github.com/chef-cookbooks/httpd).
- Rewrite OS X/Windows helper methods to account for all versions not always
  being released simultaneously for all platforms.

v0.1.0 (2015-06-28)
-------------------
- Initial release, w/ support for OS X, Windows, Ubuntu/Debian, FreeBSD,
  RHEL/etc., OpenSUSE.

v0.0.1 (2015-06-24)
-------------------
- Development started
