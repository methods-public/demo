1.4.2 (2017-07-20)
------------------
- Don't set default settings for instance-image

1.4.1 (2017-07-13)
------------------
- Don't manage ganeti-cron

1.4.0 (2017-07-13)
------------------
- instance_image_hook resource

1.3.1 (2017-07-13)
------------------
- Update lvm.conf and split by platform versions

1.3.0 (2017-07-13)
------------------
- Split out kvm code into its own recipe

1.2.1 (2017-07-13)
------------------
- Standardize kvm and ganeti attributes using case statements

1.2.0 (2017-07-13)
------------------
- Separate drbd into it's own recipe

1.1.1 (2017-07-12)
------------------
- Refactor yum/apt repository support

1.1.0 (2017-07-12)
------------------
- instance_image recipe imported from ganeti-instance-image

1.0.1 (2017-07-07)
------------------
- CentOS 7 support

1.0.0 (2017-07-05)
------------------
- Standards update and cleanup

# 0.1.0

Initial release of ganeti

* Enhancements
  * an enhancement

* Bug Fixes
  * a bug fix
