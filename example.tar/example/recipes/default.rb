example_resource 'my example resource' do
  example_property '¡Buenas noches! ¡Este mensaje viene de `example` cookbook!'
end
