#
# Cookbook Name:: configure_and_deploy_ssc
# Recipe:: default
#

Chef::Log.warn('The default configure_and_deploy_ssc recipe does nothing. See the readme for information.')
