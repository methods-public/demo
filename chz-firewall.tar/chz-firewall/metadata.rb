name             "chz-firewall"
maintainer       "Cheezburger Inc"
maintainer_email "joey@cheezburger.com"
license          "New BSD License"
description      "Installs/Configures firewalls"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.2.3"
supports         "ubuntu"
supports         "windows"
