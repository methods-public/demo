# CHANGELOG for cloudwatch_monitoring

This file is used to list changes made in each version of cloudwatch_monitoring.

## 1.2.0:
* query instance metadata to get instance role instead of EC2 Ohai attribute.

## 1.1.2:
* fix credentials path. Thanks @(sepetov](https://github.com/sepetrov)

## 1.1.1:
* add missing dependency on cron cookbook

## 1.1.0:
* support for RHEL

## 1.0.0
* initial relase
