# win_proxy

This is a fixture cookbook to setup Windows system proxy settings.

'Chefdk_bootstrap' fails to download Chocolatey packages _behind a proxy_ without the
Windows System proxy settings set correctly.
