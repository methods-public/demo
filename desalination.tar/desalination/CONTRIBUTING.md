# CONTRIBUTING

Contrbutions are welcome, please fork the repo on GitHub and then open
a pull request, please do make sure that your PR will pass on CircleCI
and also `kitchen test` passes locally too.
