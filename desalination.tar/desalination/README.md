# chef-desalination
A Chef cookbook to remove SaltStack from a server
