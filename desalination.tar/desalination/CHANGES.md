# CHANGES

## v0.1.2
- Fix `issues_url` and `source_url` in `metadata.rb`.
- Fix creating kitchen image on Centos 6.

## v0.1.1
- Add `CONTRIBUTING.md` and `TESTING.md` files.
- Improve the `description` and `long_description`.

## v0.1.0
- First release
- Supports salt-minion removal on Ubuntu, Centos & Redhat.
