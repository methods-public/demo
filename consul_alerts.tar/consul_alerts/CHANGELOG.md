# Consul-Alerts Cookbook Change Log

## v1.0.0 (Nov 9, 2014)
* Initial Release
