default['fish-shell']['extra_packages'] = []
default['fish-shell']['install_method'] = 'package'
