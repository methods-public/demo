default['fish-shell']['source']['version']      = '2.1.2'
default['fish-shell']['source']['checksum']     = 'c6c20d5ca3a2a0168461de8abfe85f9e6b255132698ea0109998d4ab68f9f6dd'
