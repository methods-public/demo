# CHANGELOG for accel-ppp

This file is used to list changes made in each version of accel-ppp.

1.0.1
-----
- Style change and addition of checkinstall cookbook dependency

1.0.0
-----
- Initial release of accel-ppp cookbook
