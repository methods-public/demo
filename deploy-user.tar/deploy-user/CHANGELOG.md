## 0.1.0 (04 May 2016)

* Initial release forked from config-driven-helper::capistrano
