default['capistrano']['user_data_bag'] = 'users'
default['capistrano']['user_data_bag_encrypted'] = true
default['capistrano']['group'] = 'deploy'
default['capistrano']['known_hosts'] = %w( github.com )
