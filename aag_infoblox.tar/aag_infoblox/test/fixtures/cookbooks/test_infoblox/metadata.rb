name 'test_infoblox'
version '0.1.0'

depends 'aag_infoblox'
