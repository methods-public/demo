# Cronic Cookbook CHANGELOG

This file is used to list changes made in each version of the cronic cookbook.

## 1.1.1 (2018-04-25)

- Start testing against Ubuntu 18.04 and Chef 14
- Inherit test configs from a central repo where possible
- Run integration tests with Microwave

## 1.1.0 (2018-01-10)

- Re-add missing time, environment, mailto, path, shell, and home properties

## 1.0.0 (2018-01-08)

- Pull in v3 of the cronic script
- Convert the cronic resource into a modern custom resource

## 0.5.0 (2013-04-10)

- Initial release!
