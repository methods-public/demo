#
# Cookbook Name:: dotnetconfig
# Recipe:: default
#
# Copyright 2017, Altis Partners
#
# All rights reserved - Do Not Redistribute
#
