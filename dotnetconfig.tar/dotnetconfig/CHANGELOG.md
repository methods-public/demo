# dotnetconfig CHANGELOG

This file is used to list changes made in each version of the dotnetconfig cookbook.

## 0.1.0 - 0.1.x
- jerseyfoxcom - Initial release of dotnetconfig, contains structural pre-release uploads to test functionality of the Supermarket before checking in any working code.

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
