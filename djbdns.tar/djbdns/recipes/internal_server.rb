#
# Author:: Joshua Timberman (<joshua@chef.io>)
# Cookbook:: djbdns
# Recipe:: internal_server
#
# Copyright:: 2009-2016, Chef Software, Inc
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'djbdns::default'

execute "#{node['djbdns']['bin_dir']}/tinydns-conf tinydns dnslog #{node['djbdns']['tinydns_internal_dir']} #{node['djbdns']['tinydns_ipaddress']}" do
  not_if { ::File.directory?(node['djbdns']['tinydns_internal_dir']) }
end

execute 'build-tinydns-internal-data' do
  cwd "#{node['djbdns']['tinydns_internal_dir']}/root"
  command 'make'
  action :nothing
end

begin

  dns = data_bag_item('djbdns', node['djbdns']['domain'].tr('.', '_'))

  file "#{node['djbdns']['tinydns_internal_dir']}/root/data" do
    action :create
  end

  %w(ns host alias).each do |type|
    dns[type].each do |record|
      record.each do |fqdn, ip|
        djbdns_rr fqdn do
          cwd "#{node['djbdns']['tinydns_internal_dir']}/root"
          ip ip
          type type
          action :add
          notifies :run, 'execute[build-tinydns-internal-data]'
        end
      end
    end
  end

rescue

  template "#{node['djbdns']['tinydns_internal_dir']}/root/data" do
    source 'tinydns-internal-data.erb'
    mode '0644'
    notifies :run, 'execute[build-tinydns-internal-data]'
  end

end

directory node['runit']['sv_dir'] do
  recursive true
end

link "#{node['runit']['sv_dir']}/tinydns-internal" do
  to node['djbdns']['tinydns_internal_dir']
end

runit_service 'tinydns-internal' do
  env('ROOT' => "#{node['djbdns']['tinydns_internal_dir']}/root",
      'IP' => node['djbdns']['tinydns_ipaddress'])
end
