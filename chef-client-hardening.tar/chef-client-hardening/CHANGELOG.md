# chef-client-hardening CHANGELOG

This file is used to list changes made in each version of the chef-client-hardening cookbook.

## 2.0.0
- Files and directories are automatically set from /etc/chef and /var/chef directories
- Removed default attributes for extra files and dirs

## 1.0.0
- Initial release of chef-client-hardening
