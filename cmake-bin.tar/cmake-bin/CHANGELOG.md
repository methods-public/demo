# 0.1.0

Initial release of cmake-bin
