fedora-mock CHANGELOG
=====================

This file is used to list changes made in each version of the fedora-mock
cookbook.

0.1.1
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - add '--extended-metadata' option for stove rake publish task
  - add pessimistic version constraint for minor version of yum-epel
  - fix README.md to address rendering issues in Chef Supermarket
  - reorder attributes in metadata.rb for consistency across repos
  - remove boilerplate text & change format of CHANGELOG.md

0.1.0
-----
- St. Isidore de Seville (st.isidore.de.seville@gmail.com)
  - Initial release of fedora-mock
