#
# Cookbook Name:: conjur
# Recipe:: default
#
# Copyright (c) 2015 Conjur Inc, All Rights Reserved.

include_recipe "conjur::install"
include_recipe "conjur::configure"
