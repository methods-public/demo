TODO
====

* [ ] Create `chef_handler` cookbook *client.d* directory file.
